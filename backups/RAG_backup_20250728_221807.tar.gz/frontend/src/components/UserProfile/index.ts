/**
 * Enterprise RAG System - User Profile Components Export
 * Context7 verified component exports
 */
export { UserProfileModal } from './UserProfileModal' 