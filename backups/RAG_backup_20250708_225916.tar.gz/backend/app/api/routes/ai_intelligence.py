"""
Enterprise RAG System - AI Intelligence API Routes (Context7 Verified)
New intelligent features that enhance existing conversation system

Features:
- Auto-generate conversation titles
- Conversation summarization
- Related question suggestions  
- Smart document recommendations
"""
from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from sqlmodel import Session

from app.core.db import get_session
from app.services.ai_intelligence_service import ai_intelligence_service
from app.models import Conversation, ConversationMessage

router = APIRouter(prefix="/ai-intelligence", tags=["AI Intelligence"])

# Request/Response Models (Context7 verified)
class GenerateTitleRequest(BaseModel):
    conversation_id: str = Field(..., description="Conversation ID to generate title for")

class GenerateTitleResponse(BaseModel):
    success: bool
    title: Optional[str] = None
    conversation_id: str
    message: str

class SummarizeConversationRequest(BaseModel):
    conversation_id: str = Field(..., description="Conversation ID to summarize")

class SummarizeConversationResponse(BaseModel):
    success: bool
    summary: Optional[str] = None
    conversation_id: str
    message: str

class RelatedQuestionsRequest(BaseModel):
    last_user_message: str = Field(..., description="Last user message")
    last_ai_response: str = Field(..., description="Last AI response")
    context_documents: Optional[List[str]] = Field(default=[], description="Available document names")

class RelatedQuestionsResponse(BaseModel):
    success: bool
    questions: List[str] = []
    count: int = 0

class DocumentRecommendationRequest(BaseModel):
    conversation_id: str = Field(..., description="Conversation ID for context")
    max_recommendations: int = Field(default=3, ge=1, le=5, description="Max recommendations to return")

class DocumentRecommendation(BaseModel):
    id: str
    title: str
    file_type: str
    content_preview: Optional[str] = None
    relevance_reason: str

class DocumentRecommendationResponse(BaseModel):
    success: bool
    recommendations: List[DocumentRecommendation] = []
    count: int = 0
    conversation_id: str

class UpdateIntelligenceRequest(BaseModel):
    conversation_id: str = Field(..., description="Conversation ID to update")
    force_update: bool = Field(default=False, description="Force regeneration of title/summary")

class UpdateIntelligenceResponse(BaseModel):
    success: bool
    updates: Dict[str, str] = {}
    conversation_id: str
    message: str

@router.post("/generate-title", response_model=GenerateTitleResponse)
async def generate_conversation_title(
    request: GenerateTitleRequest,
    session: Session = Depends(get_session)
):
    """
    Context7 verified: Auto-generate meaningful conversation title
    Based on first few messages in the conversation
    """
    try:
        # Verify conversation exists
        conversation = session.get(Conversation, request.conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        # Generate title using AI Intelligence service
        title = await ai_intelligence_service.generate_conversation_title(
            request.conversation_id, 
            session
        )
        
        if title:
            # Update conversation with new title
            conversation.title = title
            session.add(conversation)
            session.commit()
            session.refresh(conversation)
            
            return GenerateTitleResponse(
                success=True,
                title=title,
                conversation_id=request.conversation_id,
                message="Konuşma başlığı başarıyla oluşturuldu"
            )
        else:
            return GenerateTitleResponse(
                success=False,
                title=None,
                conversation_id=request.conversation_id,
                message="Başlık oluşturulamadı - yetersiz konuşma içeriği"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Title generation API error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Başlık oluşturulurken hata oluştu"
        )

@router.post("/summarize-conversation", response_model=SummarizeConversationResponse)
async def summarize_conversation(
    request: SummarizeConversationRequest,
    session: Session = Depends(get_session)
):
    """
    Context7 verified: Generate conversation summary
    Using AI to create meaningful summary of conversation
    """
    try:
        # Verify conversation exists
        conversation = session.get(Conversation, request.conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        # Generate summary using AI Intelligence service
        summary = await ai_intelligence_service.summarize_conversation(
            request.conversation_id,
            session
        )
        
        if summary:
            # Update conversation with new summary
            conversation.summary = summary
            session.add(conversation)
            session.commit()
            session.refresh(conversation)
            
            return SummarizeConversationResponse(
                success=True,
                summary=summary,
                conversation_id=request.conversation_id,
                message="Konuşma özeti başarıyla oluşturuldu"
            )
        else:
            return SummarizeConversationResponse(
                success=False,
                summary=None,
                conversation_id=request.conversation_id,
                message="Özet oluşturulamadı - yetersiz konuşma içeriği"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Summarization API error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Özet oluşturulurken hata oluştu"
        )

@router.post("/related-questions", response_model=RelatedQuestionsResponse)
async def generate_related_questions(request: RelatedQuestionsRequest):
    """
    Context7 verified: Generate related follow-up questions
    Based on current conversation context
    """
    try:
        # Generate related questions using AI Intelligence service
        questions = await ai_intelligence_service.generate_related_questions(
            request.last_user_message,
            request.last_ai_response,
            request.context_documents
        )
        
        return RelatedQuestionsResponse(
            success=True,
            questions=questions,
            count=len(questions)
        )
        
    except Exception as e:
        print(f"❌ Related questions API error: {e}")
        return RelatedQuestionsResponse(
            success=False,
            questions=[],
            count=0
        )

@router.post("/recommend-documents", response_model=DocumentRecommendationResponse)
async def recommend_documents(
    request: DocumentRecommendationRequest,
    session: Session = Depends(get_session)
):
    """
    Context7 verified: Smart document recommendations
    Based on conversation context and available documents
    """
    try:
        # Verify conversation exists
        conversation = session.get(Conversation, request.conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        # Get conversation messages for context
        from sqlmodel import select
        query = select(ConversationMessage).where(
            ConversationMessage.conversation_id == request.conversation_id
        )
        
        all_messages = session.exec(query).all()
        # Sort by message order and get last 5 messages for context
        sorted_messages = sorted(all_messages, key=lambda x: x.message_order)
        conversation_messages = [msg.content for msg in sorted_messages[-5:]]
        
        # Generate document recommendations using AI Intelligence service
        recommendations_data = await ai_intelligence_service.recommend_documents(
            conversation_messages,
            session,
            request.max_recommendations
        )
        
        # Convert to response model
        recommendations = [
            DocumentRecommendation(**rec) for rec in recommendations_data
        ]
        
        return DocumentRecommendationResponse(
            success=True,
            recommendations=recommendations,
            count=len(recommendations),
            conversation_id=request.conversation_id
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Document recommendation API error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Doküman önerileri oluşturulurken hata oluştu"
        )

@router.post("/update-intelligence", response_model=UpdateIntelligenceResponse)
async def update_conversation_intelligence(
    request: UpdateIntelligenceRequest,
    session: Session = Depends(get_session)
):
    """
    Context7 verified: Update conversation with all AI intelligence features
    Auto-generates title and summary when needed
    """
    try:
        # Update conversation intelligence using service
        result = await ai_intelligence_service.update_conversation_intelligence(
            request.conversation_id,
            session,
            request.force_update
        )
        
        if result["success"]:
            updates_message = []
            if "title" in result["updates"]:
                updates_message.append("başlık")
            if "summary" in result["updates"]:
                updates_message.append("özet")
            
            message = f"Güncellenen öğeler: {', '.join(updates_message)}" if updates_message else "Güncelleme gerekmedi"
            
            return UpdateIntelligenceResponse(
                success=True,
                updates=result["updates"],
                conversation_id=request.conversation_id,
                message=message
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result.get("error", "Intelligence update failed")
            )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Intelligence update API error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Intelligence güncellemesi sırasında hata oluştu"
        )

@router.get("/health")
async def ai_intelligence_health_check():
    """Health check for AI Intelligence service"""
    try:
        # Simple health check
        service_status = "healthy"
        return {
            "status": "ok",
            "service": "ai-intelligence",
            "message": f"AI Intelligence service is {service_status}",
            "features": [
                "auto-title-generation",
                "conversation-summarization", 
                "related-questions",
                "document-recommendations"
            ]
        }
    except Exception as e:
        print(f"❌ AI Intelligence health check error: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="AI Intelligence service unavailable"
        ) 