"""
Context7-verified WebSocket API Routes
Enterprise RAG System - Phase 3 Implementation
"""
from fastapi import APIRouter
from typing import Dict, Any

from app.services.websocket_service import websocket_service, websocket_health_check

router = APIRouter(tags=["websocket"])

@router.get("/health", summary="WebSocket Service Health Check")
async def get_websocket_health() -> Dict[str, Any]:
    """
    Get WebSocket service health and status
    
    Returns:
        WebSocket service health information including:
        - Service status
        - Active connections count
        - Active users count
        - Available channels
        - Supported features
    """
    return await websocket_health_check()

@router.get("/status", summary="WebSocket Service Status")
async def get_websocket_status() -> Dict[str, Any]:
    """
    Get detailed WebSocket service status
    
    Returns:
        Detailed status information for monitoring and debugging
    """
    return {
        "service": "websocket",
        "status": "operational",
        "connections": {
            "active_connections": len(websocket_service.active_connections),
            "active_users": len(websocket_service.user_sessions),
            "user_sessions": {
                user_id: len(sessions) 
                for user_id, sessions in websocket_service.user_sessions.items()
            }
        },
        "channels": websocket_service.channels,
        "endpoints": [
            "/ws/pubsub - PubSub WebSocket endpoint",
            "/ws/connect - Connection management endpoint"
        ],
        "features": {
            "real_time_chat": True,
            "document_notifications": True,
            "user_presence": True,
            "analytics_updates": True,
            "multi_user_support": True
        }
    }

@router.get("/channels", summary="WebSocket Channels Information")
async def get_websocket_channels() -> Dict[str, Any]:
    """
    Get information about available WebSocket channels
    
    Returns:
        List of available channels and their purposes
    """
    return {
        "channels": {
            "chat_events": {
                "description": "Real-time chat messaging and typing indicators",
                "events": ["chat_message", "chat_typing", "message_sent", "message_received"]
            },
            "document_events": {
                "description": "Document processing status updates",
                "events": ["document_status", "processing", "completed", "failed"]
            },
            "notification_events": {
                "description": "System notifications and alerts",
                "events": ["notification", "info", "warning", "error", "success"]
            },
            "user_presence": {
                "description": "User online/offline status and activity",
                "events": ["user_presence", "online", "offline", "away", "busy"]
            },
            "analytics_updates": {
                "description": "Real-time analytics and metrics updates",
                "events": ["analytics_update", "metric_update", "dashboard_refresh"]
            },
            "system_events": {
                "description": "System-wide events and maintenance notifications",
                "events": ["system_event", "maintenance", "update", "announcement"]
            }
        },
        "usage": {
            "client_connection": "/ws/connect",
            "pubsub_endpoint": "/ws/pubsub",
            "authentication": "Required - send session_id and user_id on connect"
        }
    } 