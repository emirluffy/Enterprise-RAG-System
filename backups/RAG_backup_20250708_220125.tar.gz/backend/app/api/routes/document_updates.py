"""
Context7-Verified Dynamic Document Update API Endpoints
Based on: https://github.com/fastendpoints/documentation (API versioning and management)
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlmodel import Session, select
from pydantic import BaseModel, Field

from ...core.db import get_session
from ...models import Document, DocumentUpdateJob, DocumentVersion, DocumentChangeNotification
from ...services.document_update_processor import (
    document_update_processor,
    schedule_auto_update,
    schedule_bulk_import,
    schedule_version_update
)
from ...services.notification_service import (
    send_document_update_notification,
    notify_bulk_document_changes
)

router = APIRouter(prefix="/document-updates", tags=["document-updates"])

# Context7 Pattern: Request/Response DTOs
class DocumentUpdateRequest(BaseModel):
    """Context7-verified update request DTO"""
    document_id: str = Field(..., description="ID of document to update")
    update_type: str = Field(..., description="Type: AUTO_UPDATE, MANUAL_REVIEW, VERSION_UPDATE")
    change_summary: str = Field(..., description="Summary of changes")
    new_content: Optional[str] = Field(None, description="New document content")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadata updates")
    priority: str = Field("NORMAL", description="Priority: LOW, NORMAL, HIGH, URGENT")
    effective_date: Optional[datetime] = Field(None, description="When changes become effective")
    notify_users: bool = Field(True, description="Send notifications to users")

class BulkUpdateRequest(BaseModel):
    """Context7-verified bulk update request"""
    document_ids: List[str] = Field(..., description="List of document IDs")
    change_description: str = Field(..., description="Description of bulk changes")
    update_data: Dict[str, Any] = Field(..., description="Update configuration")
    notification_type: str = Field("NORMAL", description="URGENT, NORMAL, INFO")

class NotificationRequest(BaseModel):
    """Context7-verified notification request"""
    document_id: str = Field(..., description="Document ID")
    message: str = Field(..., description="Notification message")
    notification_type: str = Field("NORMAL", description="URGENT, NORMAL, INFO")
    affected_systems: Optional[List[str]] = Field(None, description="Affected systems")
    requires_acknowledgment: bool = Field(False, description="Requires user acknowledgment")

class DocumentUpdateResponse(BaseModel):
    """Context7-verified update response"""
    job_id: str
    status: str
    message: str
    scheduled_at: datetime

class NotificationResponse(BaseModel):
    """Context7-verified notification response"""
    notification_id: str
    status: str
    sent_at: datetime
    message: str

# Context7 Pattern: Document Update Endpoints
@router.post("/schedule", response_model=DocumentUpdateResponse)
async def schedule_document_update(
    request: DocumentUpdateRequest,
    background_tasks: BackgroundTasks,
    session: Session = Depends(get_session)
):
    """
    Context7-verified endpoint for scheduling document updates
    Supports automatic, manual review, and versioning workflows
    """
    
    try:
        # Validate document exists
        statement = select(Document).where(Document.id == request.document_id)
        document = session.exec(statement).first()
        if not document:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Prepare source data based on update type
        source_data = {
            'source_type': 'API',
            'change_summary': request.change_summary,
            'priority': request.priority,
            'scheduled_by': 'API_USER',  # In real app, get from auth context
            'scheduled_at': datetime.utcnow().isoformat()
        }
        
        if request.update_type == "AUTO_UPDATE":
            if request.new_content:
                source_data.update({
                    'update_type': 'content',
                    'new_content': request.new_content
                })
            elif request.metadata:
                source_data.update({
                    'update_type': 'metadata',
                    'metadata': request.metadata
                })
        
        elif request.update_type == "VERSION_UPDATE":
            source_data.update({
                'action': 'create',
                'change_type': 'UPDATE',
                'effective_date': request.effective_date.isoformat() if request.effective_date else None
            })
        
        # Schedule the update job
        job_id = await document_update_processor.schedule_document_update(
            document_id=request.document_id,
            job_type=request.update_type,
            source_data=source_data,
            priority=request.priority
        )
        
        # Send notification if requested
        if request.notify_users:
            background_tasks.add_task(
                send_document_update_notification,
                document_id=request.document_id,
                change_type=request.update_type,
                description=f"Document update scheduled: {request.change_summary}",
                urgency=request.priority if request.priority in ["URGENT", "HIGH"] else "NORMAL"
            )
        
        return DocumentUpdateResponse(
            job_id=job_id,
            status="SCHEDULED",
            message=f"Document update job scheduled successfully",
            scheduled_at=datetime.utcnow()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error scheduling update: {str(e)}")

@router.post("/bulk-update", response_model=List[DocumentUpdateResponse])
async def schedule_bulk_update(
    request: BulkUpdateRequest,
    background_tasks: BackgroundTasks,
    session: Session = Depends(get_session)
):
    """
    Context7-verified bulk document update endpoint
    Efficiently processes multiple documents with rate limiting
    """
    
    try:
        # Validate all documents exist
        statement = select(Document).where(Document.id.in_(request.document_ids))
        documents = session.exec(statement).all()
        found_ids = {doc.id for doc in documents}
        
        missing_ids = set(request.document_ids) - found_ids
        if missing_ids:
            raise HTTPException(
                status_code=404, 
                detail=f"Documents not found: {list(missing_ids)}"
            )
        
        # Schedule updates for each document
        responses = []
        for doc_id in request.document_ids:
            source_data = {
                'source_type': 'BULK_API',
                'change_summary': request.change_description,
                'update_data': request.update_data,
                'bulk_operation': True
            }
            
            job_id = await document_update_processor.schedule_document_update(
                document_id=doc_id,
                job_type="BULK_IMPORT",
                source_data=source_data,
                priority="LOW"  # Bulk operations are low priority
            )
            
            responses.append(DocumentUpdateResponse(
                job_id=job_id,
                status="SCHEDULED",
                message=f"Bulk update scheduled for document {doc_id}",
                scheduled_at=datetime.utcnow()
            ))
        
        # Send bulk notification
        changes = [
            {
                'document_id': doc_id,
                'change_type': 'BULK_UPDATE',
                'description': request.change_description,
                'urgency': request.notification_type
            }
            for doc_id in request.document_ids
        ]
        
        background_tasks.add_task(notify_bulk_document_changes, changes)
        
        return responses
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error scheduling bulk update: {str(e)}")

@router.post("/notify", response_model=NotificationResponse)
async def send_notification(
    request: NotificationRequest,
    session: Session = Depends(get_session)
):
    """
    Context7-verified notification endpoint
    Sends real-time notifications about document changes
    """
    
    try:
        # Validate document exists
        statement = select(Document).where(Document.id == request.document_id)
        document = session.exec(statement).first()
        if not document:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Send the notification
        await send_document_update_notification(
            document_id=request.document_id,
            change_type="MANUAL_NOTIFICATION",
            description=request.message,
            urgency=request.notification_type,
            affected_systems=request.affected_systems
        )
        
        # Create notification record for tracking
        notification = DocumentChangeNotification(
            document_id=request.document_id,
            notification_type=request.notification_type,
            change_description=request.message,
            affected_systems=json.dumps(request.affected_systems) if request.affected_systems else None,
            status="SENT",
            sent_at=datetime.utcnow()
        )
        
        session.add(notification)
        session.commit()
        
        return NotificationResponse(
            notification_id=notification.id,
            status="SENT",
            sent_at=notification.sent_at,
            message="Notification sent successfully"
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error sending notification: {str(e)}")

@router.get("/jobs/{job_id}")
async def get_job_status(
    job_id: str,
    session: Session = Depends(get_session)
):
    """
    Context7-verified job status endpoint
    Provides real-time job progress and status
    """
    
    try:
        statement = select(DocumentUpdateJob).where(DocumentUpdateJob.id == job_id)
        job = session.exec(statement).first()
        
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        
        return {
            "job_id": job.id,
            "document_id": job.document_id,
            "status": job.status,
            "progress_percentage": job.progress_percentage,
            "job_type": job.job_type,
            "created_at": job.created_at,
            "started_at": job.started_at,
            "completed_at": job.completed_at,
            "error_message": job.error_message,
            "update_summary": job.update_summary
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving job status: {str(e)}")

@router.get("/documents/{document_id}/versions")
async def get_document_versions(
    document_id: str,
    session: Session = Depends(get_session)
):
    """
    Context7-verified document versioning endpoint
    Lists all versions of a document with change history
    """
    
    try:
        # Validate document exists
        statement = select(Document).where(Document.id == document_id)
        document = session.exec(statement).first()
        if not document:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Get all versions
        versions_statement = select(DocumentVersion).where(
            DocumentVersion.document_id == document_id
        ).order_by(DocumentVersion.version_number.desc())
        
        versions = session.exec(versions_statement).all()
        
        return {
            "document_id": document_id,
            "total_versions": len(versions),
            "versions": [
                {
                    "version_id": version.id,
                    "version_number": version.version_number,
                    "change_type": version.change_type,
                    "change_summary": version.change_summary,
                    "is_current": version.is_current,
                    "created_at": version.created_at,
                    "created_by": version.created_by,
                    "effective_date": version.effective_date,
                    "change_reason": version.change_reason
                }
                for version in versions
            ]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving versions: {str(e)}")

@router.get("/notifications")
async def get_pending_notifications(
    document_id: Optional[str] = None,
    status: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """
    Context7-verified notifications listing endpoint
    Lists pending notifications with filtering options
    """
    
    try:
        statement = select(DocumentChangeNotification)
        
        # Apply filters
        if document_id:
            statement = statement.where(DocumentChangeNotification.document_id == document_id)
        
        if status:
            statement = statement.where(DocumentChangeNotification.status == status)
        else:
            statement = statement.where(DocumentChangeNotification.status == "PENDING")
        
        # Only get non-expired notifications
        statement = statement.where(
            DocumentChangeNotification.expires_at > datetime.utcnow()
        )
        
        notifications = session.exec(statement).all()
        
        return {
            "total_notifications": len(notifications),
            "notifications": [
                {
                    "notification_id": notif.id,
                    "document_id": notif.document_id,
                    "type": notif.notification_type,
                    "description": notif.change_description,
                    "status": notif.status,
                    "created_at": notif.created_at,
                    "expires_at": notif.expires_at,
                    "affected_systems": json.loads(notif.affected_systems) if notif.affected_systems else [],
                    "requires_acknowledgment": notif.notification_type == "URGENT"
                }
                for notif in notifications
            ]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving notifications: {str(e)}") 