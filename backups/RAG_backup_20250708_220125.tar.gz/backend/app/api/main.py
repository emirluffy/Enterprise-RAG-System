from fastapi import APIRouter

from app.api.routes import items, login, private, users, utils, documents, chat, local_rag, analytics, learning
from app.core.config import settings
from .routes.document_updates import router as document_updates_router
from .routes.email_updates import router as email_updates_router
from .routes.ai_intelligence import router as ai_intelligence_router
from .routes.auth import router as auth_router  # Context7 verified JWT authentication
from ..services.notification_service import notification_manager

api_router = APIRouter()
# Context7 verified JWT authentication system
api_router.include_router(auth_router)  # /auth/* endpoints
api_router.include_router(login.router)  # Keep legacy login for backward compatibility
api_router.include_router(users.router)
api_router.include_router(utils.router)
api_router.include_router(items.router)
api_router.include_router(documents.router)
api_router.include_router(chat.router)
# api_router.include_router(conversations.router)  # Real conversation management - DISABLED
api_router.include_router(local_rag.router)
api_router.include_router(learning.router, prefix="/learning")  # Dynamic Learning RAG System
api_router.include_router(analytics.router, prefix="/analytics")  # Context7 verified analytics dashboard
api_router.include_router(ai_intelligence_router, prefix="/ai-intelligence")  # AI Intelligence features
api_router.include_router(document_updates_router)
api_router.include_router(email_updates_router, prefix="/email-updates")

if settings.ENVIRONMENT == "local":
    api_router.include_router(private.router)
