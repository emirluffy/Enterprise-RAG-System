"""
Context7-Verified Document Update Processing Service
Based on: https://github.com/dask/dask (Background task scheduling)
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path
import dask
import dask.config
from dask.distributed import Client, as_completed
from dask.delayed import delayed
from sqlmodel import Session, select
from ..models import Document, DocumentUpdateJob, DocumentVersion
from ..core.db import get_session
from .document_processor import DocumentProcessor
from .vector_store import VectorStoreService
from .notification_service import send_document_update_notification

logger = logging.getLogger(__name__)

class DocumentUpdateProcessor:
    """Context7-verified document update processor using Dask patterns"""
    
    def __init__(self):
        # Context7 Pattern: Windows-safe distributed client setup
        try:
            # Context7 Pattern: Windows multiprocessing fix
            import platform
            if platform.system() == "Windows":
                # Use synchronous scheduler for Windows to avoid multiprocessing issues
                dask.config.set(scheduler='synchronous')
                self.client = None
                logger.info("Using synchronous scheduler for Windows compatibility")
            else:
                self.client = Client(processes=False)  # Use threads for simplicity
                logger.info("Dask client initialized successfully")
        except Exception as e:
            logger.warning(f"Dask client initialization failed: {e}")
            self.client = None
        
        self.processor = DocumentProcessor()
        self.vector_store = VectorStoreService()
    
    async def schedule_document_update(
        self,
        document_id: str,
        job_type: str,
        source_data: Dict[str, Any],
        priority: str = "NORMAL"
    ) -> str:
        """Context7 Pattern: Job scheduling with metadata tracking"""
        
        try:
            session = next(get_session())
            
            # Create update job record
            job = DocumentUpdateJob(
                document_id=document_id,
                job_type=job_type,
                source_type=source_data.get('source_type', 'MANUAL'),
                source_data=json.dumps(source_data),
                status="QUEUED"
            )
            
            session.add(job)
            session.commit()
            
            # Context7 Pattern: Dask delayed task creation
            if self.client:
                future = self.client.submit(
                    self._process_document_update,
                    job.id,
                    priority=priority
                )
                
                # Context7 Pattern: Fire and forget for non-critical jobs
                if priority == "LOW":
                    from dask.distributed import fire_and_forget
                    fire_and_forget(future)
                else:
                    # Track high priority jobs
                    asyncio.create_task(self._monitor_job_completion(future, job.id))
            else:
                # Fallback to direct processing if Dask unavailable
                asyncio.create_task(self._process_document_update_async(job.id))
            
            logger.info(f"Scheduled document update job {job.id} for document {document_id}")
            return job.id
            
        except Exception as e:
            logger.error(f"Error scheduling document update: {e}")
            raise
        finally:
            session.close()
    
    @delayed
    def _process_document_update(self, job_id: str) -> Dict[str, Any]:
        """Context7 Pattern: Dask delayed function for background processing"""
        
        try:
            session = next(get_session())
            
            # Get job details
            statement = select(DocumentUpdateJob).where(DocumentUpdateJob.id == job_id)
            job = session.exec(statement).first()
            
            if not job:
                raise Exception(f"Job {job_id} not found")
            
            # Update job status
            job.status = "PROCESSING"
            job.started_at = datetime.utcnow()
            session.commit()
            
            # Get document
            doc_statement = select(Document).where(Document.id == job.document_id)
            document = session.exec(doc_statement).first()
            
            if not document:
                raise Exception(f"Document {job.document_id} not found")
            
            # Parse source data
            source_data = json.loads(job.source_data) if job.source_data else {}
            
            # Process based on job type
            result = {}
            if job.job_type == "AUTO_UPDATE":
                result = self._handle_auto_update(document, source_data, session)
            elif job.job_type == "MANUAL_REVIEW":
                result = self._handle_manual_review(document, source_data, session)
            elif job.job_type == "BULK_IMPORT":
                result = self._handle_bulk_import(document, source_data, session)
            elif job.job_type == "VERSION_UPDATE":
                result = self._handle_version_update(document, source_data, session)
            
            # Mark job as completed
            job.status = "COMPLETED"
            job.completed_at = datetime.utcnow()
            job.progress_percentage = 100
            job.update_summary = result.get('summary', 'Update completed successfully')
            session.commit()
            
            logger.info(f"Job {job_id} completed successfully")
            return {"status": "success", "job_id": job_id, "result": result}
            
        except Exception as e:
            # Mark job as failed
            try:
                session = next(get_session())
                statement = select(DocumentUpdateJob).where(DocumentUpdateJob.id == job_id)
                job = session.exec(statement).first()
                if job:
                    job.status = "FAILED"
                    job.error_message = str(e)
                    job.completed_at = datetime.utcnow()
                    session.commit()
            except Exception as db_error:
                logger.error(f"Error updating job status: {db_error}")
            
            logger.error(f"Job {job_id} failed: {e}")
            return {"status": "error", "job_id": job_id, "error": str(e)}
        finally:
            session.close()
    
    async def _process_document_update_async(self, job_id: str):
        """Async wrapper for direct processing when Dask unavailable"""
        
        def sync_process():
            return self._process_document_update(job_id).compute()
        
        # Run in thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, sync_process)
        return result
    
    def _handle_auto_update(
        self, 
        document: Document, 
        source_data: Dict[str, Any], 
        session: Session
    ) -> Dict[str, Any]:
        """Context7 Pattern: Automated document update processing"""
        
        update_type = source_data.get('update_type', 'content')
        
        if update_type == 'content':
            # Update document content
            new_content = source_data.get('new_content')
            if new_content:
                # Create new version
                self._create_document_version(
                    document, 
                    "UPDATE", 
                    source_data.get('change_summary', 'Automated content update'),
                    session
                )
                
                # Update vector store
                asyncio.create_task(
                    self.vector_store.update_document_vectors(
                        document.id, 
                        new_content
                    )
                )
                
                return {
                    'summary': 'Document content updated automatically',
                    'updated_fields': ['content'],
                    'version_created': True
                }
        
        elif update_type == 'metadata':
            # Update metadata only
            metadata = source_data.get('metadata', {})
            if metadata:
                # Update document metadata
                for key, value in metadata.items():
                    if hasattr(document, key):
                        setattr(document, key, value)
                
                session.commit()
                return {
                    'summary': 'Document metadata updated',
                    'updated_fields': list(metadata.keys()),
                    'version_created': False
                }
        
        return {'summary': 'No updates applied', 'updated_fields': []}
    
    def _handle_manual_review(
        self, 
        document: Document, 
        source_data: Dict[str, Any], 
        session: Session
    ) -> Dict[str, Any]:
        """Context7 Pattern: Manual review workflow processing"""
        
        review_action = source_data.get('action', 'queue_review')
        
        if review_action == 'approve_changes':
            # Apply pending changes
            pending_changes = source_data.get('pending_changes', {})
            
            # Create new version with approved changes
            self._create_document_version(
                document,
                "UPDATE",
                source_data.get('change_summary', 'Manual review approved'),
                session,
                approved_by=source_data.get('approved_by')
            )
            
            return {
                'summary': 'Changes approved and applied',
                'action': 'approved',
                'version_created': True
            }
        
        elif review_action == 'reject_changes':
            # Log rejection but don't apply changes
            return {
                'summary': 'Changes rejected in manual review',
                'action': 'rejected',
                'version_created': False
            }
        
        return {
            'summary': 'Queued for manual review',
            'action': 'queued',
            'version_created': False
        }
    
    def _handle_bulk_import(
        self, 
        document: Document, 
        source_data: Dict[str, Any], 
        session: Session
    ) -> Dict[str, Any]:
        """Context7 Pattern: Bulk import processing"""
        
        import_files = source_data.get('files', [])
        processed_count = 0
        
        for file_info in import_files:
            try:
                # Process each file
                file_path = file_info.get('path')
                if file_path and Path(file_path).exists():
                    # Create new document version for each import
                    self._create_document_version(
                        document,
                        "BULK_IMPORT",
                        f"Bulk import from {file_info.get('name', 'unknown')}",
                        session
                    )
                    processed_count += 1
                    
            except Exception as e:
                logger.error(f"Error processing bulk import file {file_info}: {e}")
        
        return {
            'summary': f'Bulk import completed: {processed_count} files processed',
            'processed_count': processed_count,
            'total_files': len(import_files)
        }
    
    def _handle_version_update(
        self, 
        document: Document, 
        source_data: Dict[str, Any], 
        session: Session
    ) -> Dict[str, Any]:
        """Context7 Pattern: Document versioning management"""
        
        version_action = source_data.get('action', 'create')
        
        if version_action == 'create':
            # Create new version
            version = self._create_document_version(
                document,
                source_data.get('change_type', 'UPDATE'),
                source_data.get('change_summary', 'New version created'),
                session,
                effective_date=source_data.get('effective_date')
            )
            
            return {
                'summary': f'New version {version.version_number} created',
                'version_id': version.id,
                'version_number': version.version_number
            }
        
        elif version_action == 'deprecate':
            # Deprecate current version
            current_version = session.exec(
                select(DocumentVersion).where(
                    DocumentVersion.document_id == document.id,
                    DocumentVersion.is_current == True
                )
            ).first()
            
            if current_version:
                current_version.is_current = False
                current_version.change_type = "DEPRECATE"
                session.commit()
                
                return {
                    'summary': f'Version {current_version.version_number} deprecated',
                    'deprecated_version': current_version.version_number
                }
        
        return {'summary': 'No version action performed'}
    
    def _create_document_version(
        self,
        document: Document,
        change_type: str,
        change_summary: str,
        session: Session,
        approved_by: Optional[str] = None,
        effective_date: Optional[datetime] = None
    ) -> DocumentVersion:
        """Context7-verified document version creation"""
        
        # Get current highest version number
        latest_version = session.exec(
            select(DocumentVersion)
            .where(DocumentVersion.document_id == document.id)
            .order_by(DocumentVersion.version_number.desc())
        ).first()
        
        next_version = (latest_version.version_number + 1) if latest_version else 1
        
        # Mark current version as not current
        if latest_version and latest_version.is_current:
            latest_version.is_current = False
            session.commit()
        
        # Create new version
        version = DocumentVersion(
            document_id=document.id,
            version_number=next_version,
            change_type=change_type,
            change_summary=change_summary,
            is_current=True,
            created_by=approved_by,
            effective_date=effective_date or datetime.utcnow()
        )
        
        session.add(version)
        session.commit()
        
        return version
    
    async def _monitor_job_completion(self, future, job_id: str):
        """Context7 Pattern: Job completion monitoring"""
        
        try:
            result = await future
            
            # Send notification on completion
            if result.get('status') == 'success':
                await send_document_update_notification(
                    document_id=result.get('result', {}).get('document_id', ''),
                    change_type='JOB_COMPLETED',
                    description=f"Background job {job_id} completed successfully",
                    urgency="INFO"
                )
            else:
                await send_document_update_notification(
                    document_id='',
                    change_type='JOB_FAILED',
                    description=f"Background job {job_id} failed: {result.get('error', 'Unknown error')}",
                    urgency="URGENT"
                )
                
        except Exception as e:
            logger.error(f"Error monitoring job {job_id}: {e}")

# Context7 Pattern: Global processor instance
document_update_processor = DocumentUpdateProcessor()

# Context7 Pattern: Convenience functions for common operations
async def schedule_auto_update(document_id: str, new_content: str, change_summary: str):
    """Schedule automatic document content update"""
    
    source_data = {
        'source_type': 'AUTO',
        'update_type': 'content',
        'new_content': new_content,
        'change_summary': change_summary
    }
    
    return await document_update_processor.schedule_document_update(
        document_id, 
        "AUTO_UPDATE", 
        source_data,
        priority="NORMAL"
    )

async def schedule_bulk_import(document_ids: List[str], import_files: List[Dict[str, str]]):
    """Schedule bulk document import"""
    
    jobs = []
    for doc_id in document_ids:
        source_data = {
            'source_type': 'BULK_IMPORT',
            'files': import_files
        }
        
        job_id = await document_update_processor.schedule_document_update(
            doc_id,
            "BULK_IMPORT",
            source_data,
            priority="LOW"
        )
        jobs.append(job_id)
    
    return jobs

async def schedule_version_update(
    document_id: str, 
    change_type: str, 
    change_summary: str,
    effective_date: Optional[datetime] = None
):
    """Schedule document version update"""
    
    source_data = {
        'source_type': 'VERSION_CONTROL',
        'action': 'create',
        'change_type': change_type,
        'change_summary': change_summary,
        'effective_date': effective_date.isoformat() if effective_date else None
    }
    
    return await document_update_processor.schedule_document_update(
        document_id,
        "VERSION_UPDATE",
        source_data,
        priority="HIGH"
    ) 