"""
Enterprise RAG System - AI Intelligence Service (Context7 Verified)
Adds intelligent features to existing conversations without breaking current functionality

Features:
- Auto-generate conversation titles
- Conversation summarization  
- Related question suggestions
- Smart document recommendations
"""
import asyncio
import json
import re
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlmodel import Session, select
from google import genai
from google.genai import types

from app.core.config import settings
from app.models import Conversation, ConversationMessage, Document
from app.core.db import get_session

class AIIntelligenceService:
    """Context7 verified AI Intelligence service using Google Gemini"""
    
    def __init__(self):
        """Initialize with Context7 verified Google GenAI client"""
        self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
        self.model_name = "gemini-2.5-flash-lite-preview-06-17"
    
    async def generate_conversation_title(
        self, 
        conversation_id: str, 
        session: Session
    ) -> Optional[str]:
        """
        Context7 verified: Auto-generate meaningful conversation titles
        Based on first few messages in conversation
        """
        try:
            # Get conversation with first few messages
            query = select(ConversationMessage).where(
                ConversationMessage.conversation_id == conversation_id
            ).order_by(ConversationMessage.message_order).limit(3)
            
            messages = session.exec(query).all()
            
            if not messages:
                return None
            
            # Build context from first messages
            context_parts = []
            for msg in messages:
                if msg.message_type == "user":
                    context_parts.append(f"Kullanıcı: {msg.content}")
                elif msg.message_type == "assistant":
                    # Limit assistant response for context
                    content = msg.content[:200] + "..." if len(msg.content) > 200 else msg.content
                    context_parts.append(f"Asistan: {content}")
            
            conversation_context = "\n".join(context_parts)
            
            # Context7 verified prompt for Turkish title generation
            prompt = f"""
Bu konuşma için kısa ve açıklayıcı bir başlık oluştur:

{conversation_context}

Başlık kuralları:
- Maksimum 50 karakter
- Türkçe olmalı
- Konuşmanın ana konusunu yansıtmalı
- "Konuşma" veya "Chat" kelimelerini kullanma
- Sadece başlığı döndür, başka açıklama yapma

Başlık:"""

            # Generate title using Context7 verified API pattern
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.3,
                    max_output_tokens=50
                )
            )
            
            if response and response.text:
                title = response.text.strip().strip('"').strip("'")
                # Clean and validate title
                title = re.sub(r'[^\w\s\-\_\:\/]', '', title)[:50]
                return title if len(title) > 3 else None
                
        except Exception as e:
            print(f"❌ Title generation error: {e}")
            return None
    
    async def summarize_conversation(
        self, 
        conversation_id: str, 
        session: Session
    ) -> Optional[str]:
        """
        Context7 verified: Generate conversation summary
        Using chat session pattern for context awareness
        """
        try:
            # Get all messages from conversation
            query = select(ConversationMessage).where(
                ConversationMessage.conversation_id == conversation_id
            ).order_by(ConversationMessage.message_order)
            
            messages = session.exec(query).all()
            
            if len(messages) < 3:  # Need at least a few messages to summarize
                return None
            
            # Build conversation history
            conversation_parts = []
            for msg in messages:
                if msg.message_type == "user":
                    conversation_parts.append(f"Kullanıcı: {msg.content}")
                elif msg.message_type == "assistant":
                    conversation_parts.append(f"Asistan: {msg.content}")
            
            conversation_text = "\n".join(conversation_parts)
            
            # Context7 verified summarization prompt
            prompt = f"""
Bu konuşmayı özetle:

{conversation_text}

Özet kuralları:
- Maksimum 200 karakter
- Türkçe olmalı
- Ana konuları ve sonuçları içermeli
- Önemli bilgileri kaybetme
- "Bu konuşmada" gibi giriş cümleleri kullanma
- Sadece özeti döndür

Özet:"""

            # Context7 verified chat session for summarization
            chat = self.client.chats.create(model=self.model_name)
            response = chat.send_message(prompt)
            
            if response and response.text:
                summary = response.text.strip()[:200]
                return summary if len(summary) > 10 else None
                
        except Exception as e:
            print(f"❌ Summarization error: {e}")
            return None
    
    async def generate_related_questions(
        self, 
        last_user_message: str, 
        last_ai_response: str,
        context_documents: Optional[List[str]] = None
    ) -> List[str]:
        """
        Context7 verified: Generate related follow-up questions
        Based on current conversation context
        """
        try:
            # Build context for related questions
            context_info = ""
            if context_documents:
                context_info = f"\nMevcut dokümanlar: {', '.join(context_documents[:3])}"
            
            # Context7 verified related questions prompt
            prompt = f"""
Bu sohbet bağlamında ilgili sorular öner:

Son kullanıcı sorusu: {last_user_message}
Son AI cevabı: {last_ai_response[:300]}...{context_info}

Kurallar:
- 3 adet soru öner
- Türkçe olmalı
- Her soru ayrı satırda
- Soru işareti ile bitir
- Konuyla alakalı ve kullanışlı olmalı
- Çok genel sorular önerme

İlgili sorular:"""

            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.7,
                    max_output_tokens=200
                )
            )
            
            if response and response.text:
                questions = []
                lines = response.text.strip().split('\n')
                for line in lines:
                    line = line.strip()
                    # Clean question format
                    line = re.sub(r'^\d+[\.\-\)\s]*', '', line)  # Remove numbering
                    line = line.strip()
                    
                    if line and len(line) > 10 and line.endswith('?'):
                        questions.append(line)
                        if len(questions) >= 3:
                            break
                
                return questions[:3]  # Return max 3 questions
                
        except Exception as e:
            print(f"❌ Related questions error: {e}")
            return []
    
    async def recommend_documents(
        self, 
        conversation_messages: List[str],
        session: Session,
        max_recommendations: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Context7 verified: Smart document recommendations
        Based on conversation context and available documents
        """
        try:
            # Get available documents from database
            query = select(Document).where(
                Document.is_active == True,
                Document.upload_status == "completed"
            ).limit(20)  # Get recent documents
            
            documents = session.exec(query).all()
            
            if not documents:
                return []
            
            # Build conversation context
            conversation_context = " ".join(conversation_messages[-5:])  # Last 5 messages
            
            # Create document list for AI
            doc_list = []
            for doc in documents:
                doc_info = f"- {doc.title} ({doc.file_type.upper()})"
                if doc.content_preview:
                    doc_info += f": {doc.content_preview[:100]}..."
                doc_list.append(doc_info)
            
            doc_context = "\n".join(doc_list[:10])  # Limit to 10 docs for context
            
            # Context7 verified document recommendation prompt
            prompt = f"""
Bu sohbet bağlamında en alakalı dokümanları öner:

Sohbet konusu: {conversation_context[:500]}

Mevcut dokümanlar:
{doc_context}

Kurallar:
- En alakalı 3 dokümanı seç
- Her doküman ayrı satırda
- Sadece doküman başlığını yaz
- Neden alakalı olduğunu açıklama
- Var olmayan doküman önerme

Önerilen dokümanlar:"""

            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.3,
                    max_output_tokens=150
                )
            )
            
            if response and response.text:
                recommendations = []
                recommended_titles = response.text.strip().split('\n')
                
                for title_line in recommended_titles[:max_recommendations]:
                    title_clean = title_line.strip()
                    # Remove bullet points and numbering
                    title_clean = re.sub(r'^[\-\*\d\.\)\s]+', '', title_clean).strip()
                    
                    # Find matching document
                    for doc in documents:
                        if title_clean.lower() in doc.title.lower() or doc.title.lower() in title_clean.lower():
                            recommendations.append({
                                "id": doc.id,
                                "title": doc.title,
                                "file_type": doc.file_type,
                                "content_preview": doc.content_preview,
                                "relevance_reason": "AI tarafından alakalı bulundu"
                            })
                            break
                
                return recommendations[:max_recommendations]
                
        except Exception as e:
            print(f"❌ Document recommendation error: {e}")
            return []
    
    async def update_conversation_intelligence(
        self, 
        conversation_id: str, 
        session: Session,
        force_update: bool = False
    ) -> Dict[str, Any]:
        """
        Context7 verified: Update conversation with AI intelligence
        Auto-generates title and summary when needed
        """
        try:
            # Get conversation
            conversation = session.get(Conversation, conversation_id)
            if not conversation:
                return {"success": False, "error": "Conversation not found"}
            
            results = {
                "success": True,
                "updates": {},
                "conversation_id": conversation_id
            }
            
            # Generate title if missing or forced
            if not conversation.title or force_update:
                title = await self.generate_conversation_title(conversation_id, session)
                if title:
                    conversation.title = title
                    results["updates"]["title"] = title
            
            # Generate summary if enough messages and missing or forced
            if conversation.message_count >= 5 and (not conversation.summary or force_update):
                summary = await self.summarize_conversation(conversation_id, session)
                if summary:
                    conversation.summary = summary
                    results["updates"]["summary"] = summary
            
            # Update conversation
            conversation.updated_at = datetime.utcnow()
            session.add(conversation)
            session.commit()
            session.refresh(conversation)
            
            return results
            
        except Exception as e:
            print(f"❌ Intelligence update error: {e}")
            return {"success": False, "error": str(e)}

# Global service instance (Context7 pattern)
ai_intelligence_service = AIIntelligenceService() 