"""
Enterprise RAG System - Real Google Gemini Chat API with RAG Pipeline (Context7 Verified)
Now with Dynamic Learning Integration + Learned Knowledge Search
"""
import asyncio
import time
import uuid
import re
from datetime import datetime
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from sqlmodel import Session, select

# Request/Response Models (Context7 verified Pydantic v2 patterns)
class ChatQueryRequest(BaseModel):
    question: str = Field(..., description="User question")
    conversation_id: Optional[str] = Field(default="default", description="Conversation ID")

class SourceInfo(BaseModel):
    source: str
    page: str | int
    score: float
    chunk_id: str

class ChatQueryResponse(BaseModel):
    answer: str
    sources: List[SourceInfo] = []
    documents_found: int = 0
    has_context: bool = False
    confidence: float = 0.0
    response_time_ms: int = 0
    model_used: str = "gemini-2.5-flash-lite-preview-06-17"
    query_id: str
    rag_pipeline: Dict[str, Any] = {}
    # Learning fields
    is_learning_command: bool = False
    learned_knowledge_id: Optional[str] = None

# Learning Pattern Detection (Context7 verified) - ENHANCED
LEARNING_PATTERNS = [
    # Pattern: "subject + predicate + öğren + polite"
    r"(.+?)\s+öğren\s*(?:lütfen)?[.\s]*$",  # "benim adım koray öğren lütfen"
    r"(.+?)\s+öğren[:\s]*$",                # "benim adım koray öğren"
    
    # Pattern: "bunu öğren: content"
    r"bunu öğren[:\s]*(.+)",
    r"şunu öğren[:\s]*(.+)",
    r"bu bilgiyi öğren[:\s]*(.+)",
    
    # Pattern: "öğren: content" 
    r"öğren[:\s]+(.+)",
    
    # Pattern: "action commands"
    r"kaydet[:\s]*(.+)",
    r"hatırla[:\s]*(.+)",
    r"şunu bil[:\s]*(.+)",  
    r"not al[:\s]*(.+)",
    
    # Pattern: "learn please" variations
    r"(.+?)\s+öğren\s+lütfen",              # "X öğren lütfen"
    r"lütfen\s+(.+?)\s+öğren",              # "lütfen X öğren"
]

def detect_learning_command(text: str) -> Optional[str]:
    """Detect learning commands in user input with enhanced Turkish support"""
    text_clean = text.strip()
    text_lower = text_clean.lower()
    
    print(f"🔍 Learning detection for: '{text_clean}'")
    
    for i, pattern in enumerate(LEARNING_PATTERNS):
        match = re.search(pattern, text_lower)
        if match and match.group(1):
            content = match.group(1).strip()
            if content and len(content) > 1:  # Make sure we have meaningful content
                print(f"✅ Pattern {i+1} matched: '{pattern}' → content: '{content}'")
                return content
            else:
                print(f"⚠️ Pattern {i+1} matched but content too short: '{content}'")
    
    print(f"❌ No learning pattern detected")
    return None

# Import learning functionality
from app.api.routes.learning import LearnRequest, embeddings_service as learning_embeddings_service
from app.models import LearnedKnowledge
from app.core.db import get_session

# Learned Knowledge Search Function
async def search_learned_knowledge(
    query_embeddings: List[List[float]], 
    top_k: int = 3,
    session: Optional[Session] = None
) -> List[Dict]:
    """Search in learned knowledge database using embeddings"""
    if not session:
        return []
    
    try:
        # Get active learned knowledge with embeddings
        query = select(LearnedKnowledge).where(
            LearnedKnowledge.status == "active",
            LearnedKnowledge.embedding != None
        )
        
        learned_items = session.exec(query).all()
        
        if not learned_items:
            print("🎓 No learned knowledge found in database")
            return []
        
        print(f"🎓 Searching {len(learned_items)} learned knowledge items...")
        
        # Calculate similarity scores for each learned item
        knowledge_results = []
        
        for item in learned_items:
            if not item.embedding or "vector" not in item.embedding:
                continue
                
            item_embedding = item.embedding["vector"]
            
            # Calculate similarity with all query variations
            max_similarity = 0.0
            for query_embedding in query_embeddings:
                try:
                    # Simple cosine similarity calculation
                    import numpy as np
                    
                    a = np.array(query_embedding)
                    b = np.array(item_embedding)
                    
                    dot_product = np.dot(a, b)
                    norm_a = np.linalg.norm(a)
                    norm_b = np.linalg.norm(b)
                    
                    if norm_a == 0 or norm_b == 0:
                        similarity = 0.0
                    else:
                        similarity = dot_product / (norm_a * norm_b)
                    
                    max_similarity = max(max_similarity, similarity)
                    
                except Exception as e:
                    print(f"Similarity calculation failed: {e}")
                    continue
            
            # Priority boost based on knowledge type and verification
            priority_boost = 0.0
            if item.priority == "critical":
                priority_boost += 0.15
            elif item.priority == "high":
                priority_boost += 0.10
            elif item.priority == "normal":
                priority_boost += 0.05
            
            if item.is_verified:
                priority_boost += 0.10
            
            # Freshness boost (recent knowledge gets slight advantage)
            days_old = (datetime.utcnow() - item.created_at).days if item.created_at else 0
            freshness_boost = max(0, 0.05 - (days_old * 0.001))  # Slight boost for recent items
            
            final_score = min(1.0, max_similarity + priority_boost + freshness_boost)
            
            # Only include if similarity is reasonable
            if max_similarity > 0.3:  # Lower threshold for learned knowledge
                knowledge_results.append({
                    "id": f"learned_{item.id}",
                    "content": item.content,
                    "source": f"💡 Öğrenilen Bilgi: {item.title}",
                    "score": final_score,
                    "page": 0,
                    "metadata": {
                        "type": "learned_knowledge",
                        "knowledge_id": item.id,
                        "knowledge_type": item.knowledge_type,
                        "priority": item.priority,
                        "is_verified": item.is_verified,
                        "created_at": item.created_at.isoformat() if item.created_at else None,
                        "similarity": max_similarity,
                        "priority_boost": priority_boost,
                        "freshness_boost": freshness_boost
                    }
                })
        
        # Sort by final score and return top results
        knowledge_results.sort(key=lambda x: x["score"], reverse=True)
        top_results = knowledge_results[:top_k]
        
        print(f"✅ Found {len(top_results)} relevant learned knowledge items")
        for i, result in enumerate(top_results):
            metadata = result["metadata"]
            print(f"   🎓 {i+1}. {result['source']} (score: {result['score']:.3f}, "
                  f"verified: {metadata['is_verified']}, priority: {metadata['priority']})")
        
        return top_results
        
    except Exception as e:
        print(f"❌ Learned knowledge search failed: {e}")
        return []

# Google GenAI SDK integration (Context7 verified)
try:
    from google import genai
    from google.genai import types
    from app.core.config import settings
    from app.services.api_rotation import get_rotation_service, initialize_rotation_service
    
    # Initialize rotation service if multiple keys available
    if settings.USE_API_ROTATION and len(settings.parsed_gemini_api_keys) > 1:
        initialize_rotation_service(settings.parsed_gemini_api_keys)
        GEMINI_AVAILABLE = True
        USE_ROTATION = True
        print(f"[OK] Chat API rotation initialized with {len(settings.parsed_gemini_api_keys)} keys")
    else:
        # Create single client using API key
        client = genai.Client(api_key=settings.GEMINI_API_KEY)
        GEMINI_AVAILABLE = True
        USE_ROTATION = False
        print("[OK] Chat API single client initialized")
    
except ImportError:
    GEMINI_AVAILABLE = False
    USE_ROTATION = False
    print("Warning: google-genai not installed")

# RAG Services (Context7 verified)
from app.services.embeddings import embeddings_service
from app.services.vector_store import vector_store_service

# Context7 Hybrid Search Import
try:
    from app.services.hybrid_rag_service import hybrid_rag_service
    HYBRID_SEARCH_AVAILABLE = True
    print("✅ Context7: Hybrid RAG service available")
except ImportError:
    HYBRID_SEARCH_AVAILABLE = False
    print("⚠️ Hybrid RAG service not available, using standard search")

router = APIRouter(prefix="/chat", tags=["chat"])

@router.post("/query", response_model=ChatQueryResponse)
async def query_documents(request: ChatQueryRequest):
    """
    Real RAG Q&A endpoint using Google Gemini API + Vector Search (Context7 verified)
    Now with Dynamic Learning Integration - can learn new information and search learned knowledge
    
    Learning Commands:
    - "Bunu öğren: Yeni bilgi..."
    - "Öğren: Sistem bakımı Pazartesi günleri yapılır"
    - "Kaydet: Kredi faiz oranları %15'e çıktı"
    
    Search Enhancement:
    - Searches both documents AND learned knowledge
    - Priority-based scoring for verified knowledge
    - Freshness boost for recent learning
    """
    if not GEMINI_AVAILABLE:
        raise HTTPException(
            status_code=503,
            detail="AI service not available - google-genai package not installed"
        )
    
    question = request.question
    if not question:
        raise HTTPException(status_code=400, detail="Question is required")
    
    query_id = str(uuid.uuid4())
    start_time = time.time()
    
    # Step 0: Check for Learning Commands FIRST
    learning_content = detect_learning_command(question)
    if learning_content:
        print(f"🎓 LEARNING DETECTED: {learning_content}")
        
        try:
            # Process learning command
            from sqlmodel import Session
            with next(get_session()) as session:
                # Create learned knowledge
                knowledge = LearnedKnowledge(
                    id=str(uuid.uuid4()),
                    content=learning_content,
                    title=learning_content[:100] + "..." if len(learning_content) > 100 else learning_content,
                    summary=None,  # Auto-generate later
                    knowledge_type="instruction",
                    priority="normal",
                    language="tr",
                    source_type="chat_instruction",
                    source_reference=None,
                    learned_from_query=None,
                    is_verified=False,
                    verified_by=None,
                    verified_at=None,
                    access_count=0,
                    last_accessed=None,
                    status="active",
                    superseded_by=None,
                    department=None,
                    expires_at=None,
                    created_by=None,
                    session_id=request.conversation_id,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                
                session.add(knowledge)
                session.commit()
                session.refresh(knowledge)
                
                # Create embeddings using SAME service as queries for dimension consistency
                try:
                    print(f"🎓 Generating embeddings for learned content using main embeddings service...")
                    embedding_list = await embeddings_service.create_multi_query_embedding(learning_content)
                    if embedding_list and len(embedding_list) > 0:
                        # Use first embedding (they should all be similar anyway)
                        knowledge.embedding = {
                            "vector": embedding_list[0],
                            "model": "dimension-matched-embedding",
                            "dimensions": len(embedding_list[0]),
                            "generated_at": datetime.utcnow().isoformat()
                        }
                        knowledge.embedding_model = "dimension-matched-embedding"
                        session.add(knowledge)
                        session.commit()
                        print(f"✅ Embedding created for knowledge {knowledge.id} with {len(embedding_list[0])} dimensions")
                    else:
                        print(f"⚠️ No embeddings generated for content: {learning_content[:100]}")
                except Exception as e:
                    print(f"⚠️ Embedding creation failed: {e}")
                    import traceback
                    print(f"🔥 Embedding traceback: {traceback.format_exc()}")
                
                response_time_ms = int((time.time() - start_time) * 1000)
                
                return ChatQueryResponse(
                    answer=f"✅ **Bilgi başarıyla öğrenildi!**\n\n📝 **Öğrenilen:** {learning_content}\n\n🆔 **ID:** {knowledge.id}\n\nBu bilgi artık gelecekteki sorularınızda kullanılacak. Bilgiyi doğrulamak için `/learning/knowledge/{knowledge.id}/verify` endpoint'ini kullanabilirsiniz.",
                    sources=[],
                    documents_found=0,
                    has_context=True,
                    confidence=1.0,
                    response_time_ms=response_time_ms,
                    model_used="learning-system-v1.0",
                    query_id=query_id,
                    rag_pipeline={"type": "learning", "knowledge_id": str(knowledge.id)},
                    is_learning_command=True,
                    learned_knowledge_id=str(knowledge.id)
                )
        
        except Exception as e:
            print(f"❌ Learning failed: {e}")
            return ChatQueryResponse(
                answer=f"❌ **Öğrenme başarısız:** {str(e)}\n\nLütfen tekrar deneyin veya sistem yöneticisine başvurun.",
                sources=[],
                documents_found=0,
                has_context=False,
                confidence=0.0,
                response_time_ms=int((time.time() - start_time) * 1000),
                model_used="learning-system-v1.0",
                query_id=query_id,
                rag_pipeline={"type": "learning_failed", "error": str(e)},
                is_learning_command=True,
                learned_knowledge_id=None
            )
    
    # Continue with Enhanced RAG processing (Documents + Learned Knowledge)
    try:
        # RAG Pipeline Step 1: Create multi-query embeddings for better search
        print(f"Creating embeddings for query: {question}")
        query_embeddings = await embeddings_service.create_multi_query_embedding(question)
        print(f"Generated {len(query_embeddings)} query variations")
        
        # RAG Pipeline Step 2: ENHANCED SEARCH - Documents + Learned Knowledge
        print("🔍 Enhanced search in documents AND learned knowledge...")
        
        # Search in documents (existing logic)
        similar_docs = []
        if HYBRID_SEARCH_AVAILABLE:
            print("🔍 Using Context7 Hybrid Search (BM25 + Semantic + Re-ranking)")
            
            # Get all documents for hybrid indexing
            all_docs = await vector_store_service.get_all_documents()
            
            if all_docs:
                # Index documents for hybrid search
                hybrid_docs = [{"content": doc.get("content", ""), "id": doc.get("id", "")} for doc in all_docs]
                
                if hybrid_rag_service.index_documents(hybrid_docs):
                    # Perform hybrid search
                    hybrid_results = hybrid_rag_service.hybrid_search(
                        query=question,
                        top_k=settings.DEFAULT_TOP_K,
                        rerank=True
                    )
                    
                    # Convert hybrid results to standard format
                    for result in hybrid_results:
                        similar_docs.append({
                            "content": result["content"],
                            "source": result["document_id"],
                            "score": result.get("cross_score", result.get("hybrid_score", 0.0)),
                            "id": result["document_id"],
                            "page": 0,
                            "search_type": result.get("search_type", "hybrid")
                        })
                    
                    print(f"✅ Hybrid document search found {len(similar_docs)} results")
                else:
                    print("⚠️ Hybrid indexing failed, falling back to standard search")
                    similar_docs = await vector_store_service.search_similar_documents_multi_query(
                        query_embeddings=query_embeddings,
                        top_k=settings.DEFAULT_TOP_K,
                        filter_metadata=None
                    )
            else:
                print("⚠️ No documents found for hybrid search, using standard search")
                similar_docs = await vector_store_service.search_similar_documents_multi_query(
                    query_embeddings=query_embeddings,
                    top_k=settings.DEFAULT_TOP_K,
                    filter_metadata=None
                )
        else:
            # Fallback to standard search
            print("🔍 Using standard semantic search")
            similar_docs = await vector_store_service.search_similar_documents_multi_query(
                query_embeddings=query_embeddings,
                top_k=settings.DEFAULT_TOP_K,
                filter_metadata=None
            )
        
        # RAG Pipeline Step 2.5: NEW - Search in Learned Knowledge
        learned_knowledge = []
        try:
            print("🎓 STEP 2.5: Searching learned knowledge...")
            print(f"🔍 Query embeddings count: {len(query_embeddings)}")
            try:
                first_dim = len(query_embeddings[0]) if query_embeddings and len(query_embeddings) > 0 else 0
            except (TypeError, IndexError):
                first_dim = 0
            print(f"📏 First embedding dimension: {first_dim}")
            
            with next(get_session()) as session:
                print("📁 Database session created, calling search function...")
                learned_knowledge = await search_learned_knowledge(
                    query_embeddings=query_embeddings,
                    top_k=3,  # Get top 3 learned items
                    session=session
                )
                print(f"✅ Learned knowledge search returned {len(learned_knowledge)} items")
                for i, item in enumerate(learned_knowledge):
                    print(f"   🎯 {i+1}. {item.get('source', 'Unknown')}: {item.get('content', '')[:100]}...")
        except Exception as e:
            print(f"❌ ERROR in learned knowledge search: {str(e)}")
            import traceback
            print(f"🔥 Full traceback: {traceback.format_exc()}")
            learned_knowledge = []  # Continue with empty learned knowledge
        
        # RAG Pipeline Step 3: Combine Documents + Learned Knowledge
        print(f"STEP 3: Combining {len(similar_docs)} documents + {len(learned_knowledge)} learned knowledge")
        all_sources = similar_docs + learned_knowledge
        all_sources.sort(key=lambda x: x["score"], reverse=True)
        
        # Take top results (mix of documents and learned knowledge)
        top_sources = all_sources[:settings.DEFAULT_TOP_K]
        
        print(f"Combined search results: {len(similar_docs)} documents + {len(learned_knowledge)} learned items = {len(top_sources)} total")
        
        # RAG Pipeline Step 4: Use retrieved sources if available
        if top_sources:
            # Build context from retrieved chunks
            context_parts = []
            sources = []
            
            for i, doc in enumerate(top_sources):
                source_info = SourceInfo(
                    source=doc.get("source", ""),
                    page=doc.get("page", 0),
                    score=round(doc.get("score", 0), 3),
                    chunk_id=doc.get("id", "")
                )
                sources.append(source_info)
                
                # Format context
                context_parts.append(f"[Kaynak {i+1}] {doc.get('content', '')}")
            
            context = "\n\n".join(context_parts)
            
            # Enhanced debug output
            print(f"🔍 DEBUG - Context being sent to AI:")
            print("="*50)
            for i, doc in enumerate(top_sources[:5]):  # Show first 5 for debugging
                content = doc.get("content", "")
                source = doc.get("source", "unknown")
                print(f"[Kaynak {i+1}] {content}")
            print("="*50)
            print(f"🔍 DEBUG - User question: {question}")
            print("="*50)
            
            # *** ADDITIONAL DEBUG: Show the exact full content ***
            print(f"🔍 FULL CONTEXT DEBUG:")
            print("-"*50)
            for i, doc in enumerate(top_sources):
                content = doc.get("content", "")
                source = doc.get("source", "unknown")
                print(f"FULL CHUNK {i+1} from {source}:")
                print(f"Content: '{content}'")
                print(f"Length: {len(content)} chars")
                print("-"*30)
            print("-"*50)
            
            # Also write to file for debugging
            with open("debug_context.txt", "w", encoding="utf-8") as f:
                f.write(f"USER QUESTION: {question}\n")
                f.write("=" * 50 + "\n")
                f.write("CONTEXT SENT TO AI:\n")
                f.write(context)
                f.write("\n" + "=" * 50 + "\n")
            
            # RAG Pipeline Step 5: Create enhanced prompt with context
            prompt = f"""Sen bir profesyonel Türk bankacılık uzmanısın. Verilen belgelerden bilgileri analiz ederek kullanıcı sorularını yanıtlıyorsun.

BELGELERDEKİ KAYNAK BİLGİLER:
{context}

KULLANICI SORUSU: {question}

GÖREVİN:
1. Yukarıdaki kaynak belgelerden soruyla ilgili bilgileri bul ve kullan
2. Belgelerde benzer konularla ilgili bilgiler varsa onları kullanarak soruyu yanıtla
3. "Kurye", "şikayet", "davranış", "tutum", "tavır" gibi anahtar kelimelerle eşleşen bilgileri ara
4. Hangi kaynaktan aldığın bilgiyi belirt ([Kaynak 1], [Kaynak 2] formatında)
5. Belgelerde direkt cevap yoksa, alakalı bilgilerden mantıklı çıkarım yap

ARAMA STRATEJİSİ:
- "Kurye personeli" + "şikayet" → MBS kategorilerini ara
- "Davranış", "tutum", "tavır" → kurye ile ilgili prosedürleri ara
- Benzer durumlar için verilen çözümleri kullan

ÖNEMLİ: Belgelerde alakalı bilgiler varsa mutlaka kullan. Sadece tam eşleşme arama, konuyla ilgili her bilgiyi değerlendir.

CEVAP:"""

        else:
            # No relevant documents found
            print("No relevant documents found, using general knowledge")
            sources = []
            prompt = f"""Sen bir profesyonel Türk bankacılık uzmanısın.

⚠️ DURUM: Sisteme yüklenmiş belgeler arasında bu soruyla doğrudan ilgili spesifik bir belge bulunamadı.

KULLANICI SORUSU: {question}

GÖREVİN:
1. Genel bankacılık bilginle soruya kısa ve faydalı bir cevap ver
2. Daha kesin bilgi için ilgili belgelerin sisteme yüklenmesi gerektiğini belirt
3. Mümkünse genel prosedürler hakkında bilgi ver
4. Türkçe olarak yanıtla

ÖNEMLİ: Genel bilgi verirken, spesifik kurum politikaları için belge yüklenmesi gerektiğini hatırlat.

CEVAP:"""

        # RAG Pipeline Step 6: Generate response using Gemini 2.5 Flash-Lite Preview
        if USE_ROTATION:
            # Use rotation service for content generation
            rotation_service = get_rotation_service()
            if rotation_service:
                response_text = await rotation_service.generate_content_with_rotation(
                    contents=prompt,
                    model=settings.GEMINI_MODEL,
                    config=types.GenerateContentConfig(
                        temperature=settings.DEFAULT_TEMPERATURE,
                        max_output_tokens=1000,
                    )
                )
                if response_text is None:
                    raise Exception("All API keys exhausted - no response generated")
                
                # Create a mock response object for compatibility
                class MockResponse:
                    def __init__(self, text):
                        self.text = text
                response = MockResponse(response_text)
            else:
                raise Exception("Rotation service not available")
        else:
            # Use single client
            response = await asyncio.to_thread(
                client.models.generate_content,
                model=settings.GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=settings.DEFAULT_TEMPERATURE,
                    max_output_tokens=1000,
                )
            )
        
        response_time_ms = int((time.time() - start_time) * 1000)
        
        # Ensure response text is not None
        final_answer = response.text if response and response.text else "Üzgünüm, yanıt oluşturulamadı. Lütfen tekrar deneyin."
        
        return ChatQueryResponse(
            answer=final_answer,
            sources=sources,
            documents_found=len(top_sources),
            has_context=len(top_sources) > 0,
            confidence=0.9 if top_sources else 0.3,  # Higher confidence with sources
            response_time_ms=response_time_ms,
            model_used=settings.GEMINI_MODEL,
            query_id=query_id,
            rag_pipeline={
                "embedding_created": True,
                "documents_searched": True,
                "context_used": len(top_sources) > 0,
                "top_k": settings.DEFAULT_TOP_K
            }
        )
        
    except Exception as e:
        response_time_ms = int((time.time() - start_time) * 1000)
        print(f"❌ RAG Pipeline Error: {str(e)}")
        # Context7 verified: Return structured error response
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "RAG pipeline error",
                "message": str(e),
                "response_time_ms": response_time_ms,
                "query_id": query_id
            }
        )

@router.get("/health")
async def chat_health_check():
    """Real chat service health check with RAG pipeline status (Context7 verified)"""
    status = {
        "service": "chat",
        "gemini_available": GEMINI_AVAILABLE,
        "model": settings.GEMINI_MODEL
    }
    
    if GEMINI_AVAILABLE:
        try:
            # Test Gemini API with a simple query (Context7 verified pattern)
            test_response = await asyncio.to_thread(
                client.models.generate_content,
                model=settings.GEMINI_MODEL,
                contents="Test",
                config=types.GenerateContentConfig(max_output_tokens=10)
            )
            status["gemini_api"] = "healthy"
            status["test_response"] = test_response.text[:50] + "..."
        except Exception as e:
            status["gemini_api"] = f"error: {str(e)}"
    
    # Test RAG pipeline components
    try:
        # Test embeddings service
        status["embeddings_service"] = "available"
        status["embeddings_model"] = embeddings_service.model
        status["embeddings_dimension"] = embeddings_service.dimensions
    except Exception as e:
        status["embeddings_service"] = f"error: {str(e)}"
    
    try:
        # Test vector store
        vector_stats = await vector_store_service.get_index_stats()
        status["vector_store"] = "available"
        status["vector_stats"] = vector_stats
    except Exception as e:
        status["vector_store"] = f"error: {str(e)}"
    
    return status

@router.get("/rotation-status")
async def get_rotation_status():
    """Get API rotation service status"""
    if not USE_ROTATION:
        return {
            "rotation_enabled": False,
            "message": "API rotation not enabled"
        }
    
    rotation_service = get_rotation_service()
    if not rotation_service:
        return {
            "rotation_enabled": True,
            "status": "error",
            "message": "Rotation service not initialized"
        }
    
    status_report = rotation_service.get_status_report()
    current_key_info = rotation_service.get_current_key_info()
    
    return {
        "rotation_enabled": True,
        "status": "active",
        "current_key": current_key_info,
        "summary": status_report,
        "message": f"Using key {status_report['current_key']}/{status_report['total_keys']}"
    } 