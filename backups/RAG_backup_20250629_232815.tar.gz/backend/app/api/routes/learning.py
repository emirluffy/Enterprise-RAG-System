"""
Dynamic Learning Routes for RAG System
Allows users to teach the system new information through chat
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlmodel import Session, select, func
from pydantic import BaseModel, Field

from app.core.db import get_session
from app.models import LearnedKnowledge, User, QueryLog
from app.services.embeddings import EmbeddingsService
from app.services.vector_store import VectorStoreService

router = APIRouter()

# Global embeddings service instance
embeddings_service = EmbeddingsService()

# Pydantic Models for Request/Response
class LearnRequest(BaseModel):
    """Request to learn new information"""
    content: str = Field(description="Content to learn")
    title: Optional[str] = Field(None, description="Title for the knowledge")
    knowledge_type: str = Field(default="instruction", description="Type: duyuru, instruction, qa, regulation")
    priority: str = Field(default="normal", description="Priority: low, normal, high, critical")
    summary: Optional[str] = Field(None, description="Optional summary")
    keywords: Optional[List[str]] = Field(None, description="Optional keywords")
    department: Optional[str] = Field(None, description="Department context")
    expires_at: Optional[datetime] = Field(None, description="Expiration date")

class LearnResponse(BaseModel):
    """Response after learning"""
    success: bool
    knowledge_id: str
    message: str
    embedding_created: bool

class KnowledgeListResponse(BaseModel):
    """Response for knowledge listing"""
    knowledge: List[Dict[str, Any]]
    total: int
    page: int
    size: int

@router.post("/learn", response_model=LearnResponse)
async def learn_knowledge(
    learn_request: LearnRequest,
    background_tasks: BackgroundTasks,
    session: Session = Depends(get_session),
    # current_user: User = Depends(get_current_active_user)  # Enable when auth ready
):
    """
    Teach the system new knowledge
    
    Usage Examples:
    - "Bunu öğren: Yeni kredi faiz oranları %15'e çıktı"
    - Content: "Pazartesi günleri saat 14:00'da sistem bakımı yapılır"
    """
    
    try:
        # Generate UUID for the knowledge
        knowledge_id = str(uuid.uuid4())
        
        # Auto-generate title if not provided
        if not learn_request.title:
            learn_request.title = learn_request.content[:100] + "..." if len(learn_request.content) > 100 else learn_request.content
        
        # Create knowledge entry
        knowledge = LearnedKnowledge(
            id=knowledge_id,
            content=learn_request.content,
            title=learn_request.title,
            knowledge_type=learn_request.knowledge_type,
            priority=learn_request.priority,
            summary=learn_request.summary,
            keywords=learn_request.keywords,
            language="tr",  # Default Turkish
            source_type="chat_instruction",
            source_reference=None,  # Not from document
            learned_from_query=None,  # Direct instruction
            is_verified=False,  # Requires manual verification
            verified_by=None,
            verified_at=None,
            access_count=0,
            last_accessed=None,
            status="active",
            superseded_by=None,
            department=learn_request.department,
            expires_at=learn_request.expires_at,
            created_by=None,  # current_user.id when auth ready
            session_id=None,  # Add session tracking later
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Save to database
        session.add(knowledge)
        session.commit()
        session.refresh(knowledge)
        
        # Generate embeddings in background
        background_tasks.add_task(
            create_knowledge_embedding,
            knowledge_id,
            learn_request.content
        )
        
        return LearnResponse(
            success=True,
            knowledge_id=knowledge_id,
            message=f"✅ Bilgi başarıyla öğrenildi: '{learn_request.title}'",
            embedding_created=True
        )
        
    except Exception as e:
        session.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Learning failed: {str(e)}"
        )

@router.get("/knowledge", response_model=KnowledgeListResponse)
async def list_knowledge(
    page: int = 1,
    size: int = 20,
    knowledge_type: Optional[str] = None,
    status: str = "active",
    department: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """List learned knowledge with filtering"""
    
    # Build query
    query = select(LearnedKnowledge).where(LearnedKnowledge.status == status)
    
    if knowledge_type:
        query = query.where(LearnedKnowledge.knowledge_type == knowledge_type)
    if department:
        query = query.where(LearnedKnowledge.department == department)
    
    # Pagination
    offset = (page - 1) * size
    results = session.exec(query.offset(offset).limit(size)).all()
    
    # Convert to dict
    knowledge_list = []
    for k in results:
        knowledge_list.append({
            "id": k.id,
            "title": k.title,
            "content": k.content[:200] + "..." if len(k.content) > 200 else k.content,
            "knowledge_type": k.knowledge_type,
            "priority": k.priority,
            "is_verified": k.is_verified,
            "access_count": k.access_count,
            "created_at": k.created_at,
            "department": k.department
        })
    
    # Total count
    count_query = select(func.count()).select_from(LearnedKnowledge).where(LearnedKnowledge.status == status)
    if knowledge_type:
        count_query = count_query.where(LearnedKnowledge.knowledge_type == knowledge_type)
    if department:
        count_query = count_query.where(LearnedKnowledge.department == department)
    
    total = session.exec(count_query).one()
    
    return KnowledgeListResponse(
        knowledge=knowledge_list,
        total=total,
        page=page,
        size=size
    )

@router.delete("/knowledge/{knowledge_id}")
async def delete_knowledge(
    knowledge_id: str,
    session: Session = Depends(get_session),
    # current_user: User = Depends(get_current_active_superuser)  # Enable when auth ready
):
    """Delete learned knowledge"""
    
    knowledge = session.get(LearnedKnowledge, knowledge_id)
    if not knowledge:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    
    # Soft delete
    knowledge.status = "deleted"
    knowledge.updated_at = datetime.utcnow()
    
    session.add(knowledge)
    session.commit()
    
    return {"message": "Knowledge deleted successfully"}

@router.post("/knowledge/{knowledge_id}/verify")
async def verify_knowledge(
    knowledge_id: str,
    session: Session = Depends(get_session),
    # current_user: User = Depends(get_current_active_user)  # Enable when auth ready
):
    """Verify learned knowledge as accurate"""
    
    knowledge = session.get(LearnedKnowledge, knowledge_id)
    if not knowledge:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    
    knowledge.is_verified = True
    knowledge.verified_at = datetime.utcnow()
    # knowledge.verified_by = current_user.id  # Enable when auth ready
    knowledge.updated_at = datetime.utcnow()
    
    session.add(knowledge)
    session.commit()
    
    return {"message": "Knowledge verified successfully"}

# Background Tasks
async def create_knowledge_embedding(knowledge_id: str, content: str):
    """Create embedding for learned knowledge in background"""
    try:
        # Get embeddings
        embedding_list = await embeddings_service.create_embeddings([content])
        embedding = embedding_list[0]
        
        # Save to database
        from app.core.db import get_session
        with next(get_session()) as session:
            knowledge = session.get(LearnedKnowledge, knowledge_id)
            if knowledge:
                # Convert embedding to dict format for JSON field
                knowledge.embedding = {"vector": embedding}
                knowledge.embedding_model = "multilingual-e5-large"
                knowledge.updated_at = datetime.utcnow()
                
                session.add(knowledge)
                session.commit()
        
        # TODO: Add to vector store when method is implemented
        # vector_service = VectorStoreService()
        # await vector_service.add_learned_knowledge_to_vector_store(knowledge_id, content, embedding)
        
        print(f"✅ Embedding created for knowledge {knowledge_id}")
        
    except Exception as e:
        print(f"❌ Embedding creation failed for {knowledge_id}: {e}") 