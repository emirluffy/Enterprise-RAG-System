"""
Email Webhook API for Operational Document Updates
Handles incoming operational emails and triggers automatic updates
"""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel, EmailStr
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

from app.services.email_processor import process_incoming_email, email_processor
from app.api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter()

class EmailWebhookRequest(BaseModel):
    """Email webhook request model"""
    sender: EmailStr
    recipient: EmailStr
    subject: str
    body: str
    timestamp: Optional[datetime] = None
    message_id: Optional[str] = None
    attachments: Optional[List[Dict]] = None

class EmailWebhookResponse(BaseModel):
    """Email webhook response model"""
    processed: bool
    message_id: Optional[str] = None
    processing_result: Dict[str, Any]
    timestamp: datetime

@router.post("/webhook/email", response_model=EmailWebhookResponse)
async def handle_email_webhook(
    request: EmailWebhookRequest,
    background_tasks: BackgroundTasks
):
    """
    Email webhook endpoint for processing operational emails
    
    Use this endpoint to automatically process incoming operational emails:
    
    **Example Usage:**
    ```python
    # Configure your email server to send webhooks here
    POST /api/email-updates/webhook/email
    {
        "sender": "operations@company.com",
        "recipient": "rag-system@company.com", 
        "subject": "ACİL: Yeni Politika Güncellemesi",
        "body": "Müşteri hizmetleri politikası güncellenmiştir...",
        "timestamp": "2024-01-15T10:30:00Z"
    }
    ```
    """
    
    try:
        logger.info(f"Processing email webhook from {request.sender}")
        
        # Process email in background for faster response
        background_tasks.add_task(
            process_email_background,
            request.body,
            request.sender,
            request.subject,
            request.message_id or f"email-{datetime.utcnow().isoformat()}"
        )
        
        # Quick response to email service
        return EmailWebhookResponse(
            processed=True,
            message_id=request.message_id,
            processing_result={"status": "queued", "message": "Email queued for processing"},
            timestamp=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Error processing email webhook: {e}")
        raise HTTPException(status_code=500, detail=f"Email processing failed: {str(e)}")

async def process_email_background(
    email_content: str,
    sender: str,
    subject: str,
    message_id: str
):
    """Background task for processing emails"""
    
    try:
        result = await process_incoming_email(email_content, sender, subject)
        logger.info(f"Email {message_id} processed: {result}")
        
        # Log successful processing
        if result.get("status") == "processed":
            logger.info(f"✅ Email from {sender} successfully processed: {result.get('type', 'unknown')}")
        elif result.get("status") == "urgent_processed":
            logger.warning(f"🚨 URGENT email from {sender} processed: {subject}")
        
    except Exception as e:
        logger.error(f"❌ Background email processing failed for {message_id}: {e}")

@router.post("/manual/email", response_model=Dict[str, Any])
async def process_manual_email(
    request: EmailWebhookRequest,
    current_user: Any = Depends(get_current_user)
):
    """
    Manual email processing endpoint
    
    Use this to manually process emails through the admin interface:
    
    **Example Usage:**
    ```python
    POST /api/email-updates/manual/email
    {
        "sender": "operations@company.com",
        "subject": "Prosedür Güncellemesi", 
        "body": "Yeni müşteri onboarding prosedürü..."
    }
    ```
    """
    
    try:
        result = await process_incoming_email(
            request.body,
            request.sender,
            request.subject
        )
        
        return {
            "status": "success",
            "processing_result": result,
            "processed_by": current_user.email,
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        logger.error(f"Manual email processing failed: {e}")
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")

@router.get("/settings/email-patterns")
async def get_email_patterns(current_user: Any = Depends(get_current_user)):
    """Get configured email processing patterns"""
    
    return {
        "operational_senders": email_processor.operational_senders,
        "update_patterns": email_processor.update_patterns,
        "last_updated": datetime.utcnow()
    }

@router.post("/settings/email-patterns")
async def update_email_patterns(
    patterns: Dict[str, Any],
    current_user: Any = Depends(get_current_user)
):
    """Update email processing patterns (admin only)"""
    
    try:
        if "operational_senders" in patterns:
            email_processor.operational_senders = patterns["operational_senders"]
        
        if "update_patterns" in patterns:
            email_processor.update_patterns.update(patterns["update_patterns"])
        
        logger.info(f"Email patterns updated by {current_user.email}")
        
        return {
            "status": "success",
            "message": "Email patterns updated",
            "updated_by": current_user.email,
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pattern update failed: {str(e)}")

# Test endpoints for development
@router.post("/test/simulate-email")
async def simulate_operational_email(
    email_type: str = "policy",
    urgency: str = "normal",
    current_user: Any = Depends(get_current_user)
):
    """
    Simulate operational email for testing
    
    **Example Usage:**
    ```python
    POST /api/email-updates/test/simulate-email?email_type=policy&urgency=urgent
    ```
    """
    
    test_emails = {
        "policy": {
            "sender": "policy@company.com",
            "subject": "Yeni Müşteri Hizmetleri Politikası",
            "body": "Müşteri hizmetleri politikası güncellenmiştir. Yeni kurallar: 1) Müşteri şikayetleri 24 saat içinde yanıtlanmalı 2) Geri ödeme talepleri 3 gün içinde işleme alınmalı"
        },
        "urgent": {
            "sender": "operations@company.com", 
            "subject": "ACİL: Sistem Bakım Duyurusu",
            "body": "URGENT: Sistem bakımı nedeniyle 14:00-16:00 arası kesinti olacaktır. Tüm müşterilere bilgilendirme yapılmalıdır."
        },
        "process": {
            "sender": "operations@company.com",
            "subject": "Onboarding Süreç Güncellemesi",
            "body": "Yeni müşteri onboarding süreci güncellenmiştir. Artık KYC dokümanları 2 gün içinde tamamlanmalıdır."
        }
    }
    
    if urgency == "urgent":
        email_data = test_emails["urgent"]
    else:
        email_data = test_emails.get(email_type, test_emails["policy"])
    
    result = await process_incoming_email(
        email_data["body"],
        email_data["sender"], 
        email_data["subject"]
    )
    
    return {
        "test_email": email_data,
        "processing_result": result,
        "simulated_by": current_user.email
    } 