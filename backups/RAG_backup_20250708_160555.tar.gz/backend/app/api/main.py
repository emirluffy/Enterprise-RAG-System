from fastapi import APIRouter

from app.api.routes import items, login, private, users, utils, documents, chat, local_rag, analytics, learning
from app.core.config import settings
from .routes.document_updates import router as document_updates_router
from .routes.email_updates import router as email_updates_router
from ..services.notification_service import notification_manager

api_router = APIRouter()
api_router.include_router(login.router)
api_router.include_router(users.router)
api_router.include_router(utils.router)
api_router.include_router(items.router)
api_router.include_router(documents.router)
api_router.include_router(chat.router)
# api_router.include_router(conversations.router)  # Real conversation management - DISABLED
api_router.include_router(local_rag.router)
api_router.include_router(learning.router, prefix="/learning")  # Dynamic Learning RAG System
api_router.include_router(analytics.router, prefix="/analytics")  # Context7 verified analytics dashboard
api_router.include_router(document_updates_router)
api_router.include_router(email_updates_router, prefix="/email-updates")

if settings.ENVIRONMENT == "local":
    api_router.include_router(private.router)
