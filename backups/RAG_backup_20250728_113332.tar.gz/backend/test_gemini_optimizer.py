"""
Test script for Gemini response optimizer with structured output (Context7)
"""

import asyncio
import os
from datetime import datetime
import json
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

# Gemini API import
try:
    import google.generativeai as genai
    from google.generativeai import types as genai_types
    GEMINI_AVAILABLE = True
    print("✅ Gemini API available for response optimization")
except ImportError:
    GEMINI_AVAILABLE = False
    print("⚠️ Gemini API not available - falling back to basic optimization")

# Simplified output models for testing
class ResponseAnalysis(BaseModel):
    """Analysis results from the Response Analyzer"""
    has_duplicates: bool = Field(..., description="Whether response contains duplicate information")
    repetitive_sections: List[str] = Field(default_factory=list, description="List of repetitive content sections")
    clarity_score: float = Field(..., ge=0.0, le=10.0, description="Clarity score from 1-10")
    completeness_score: float = Field(..., ge=0.0, le=10.0, description="Completeness score from 1-10")
    formatting_issues: List[str] = Field(default_factory=list, description="Identified formatting problems")
    key_points: List[str] = Field(default_factory=list, description="Main key points in the response")
    improvement_suggestions: List[str] = Field(default_factory=list, description="Specific improvement suggestions")

class OptimizedResponse(BaseModel):
    """Optimized response from the Response Optimizer"""
    optimized_content: str = Field(..., description="The optimized and polished response content")
    removed_duplicates: List[str] = Field(default_factory=list, description="List of removed duplicate content")
    formatting_improvements: List[str] = Field(default_factory=list, description="Applied formatting improvements")
    clarity_improvements: List[str] = Field(default_factory=list, description="Applied clarity improvements")
    optimization_score: float = Field(..., ge=0.0, le=10.0, description="Overall optimization improvement score")
    processing_notes: str = Field(..., description="Notes about the optimization process")

class ResponseOptimizationResult(BaseModel):
    """Final result combining analysis and optimization"""
    original_response: str = Field(..., description="Original RAG response")
    analysis: ResponseAnalysis = Field(..., description="Analysis results")
    optimized_response: OptimizedResponse = Field(..., description="Optimized response")
    optimization_applied: bool = Field(..., description="Whether optimization was successfully applied")
    processing_time_ms: int = Field(..., description="Time taken for optimization in milliseconds")
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())

class SimpleGeminiOptimizer:
    """Simplified Gemini API response optimization service for testing"""
    
    def __init__(self):
        self.gemini_available = GEMINI_AVAILABLE
        self.model = None
        if self.gemini_available:
            self._initialize_client()
        else:
            print("⚠️ Response optimization will use fallback patterns")
    
    def _initialize_client(self):
        """Initialize Gemini client for response optimization (Context7)"""
        try:
            gemini_api_key = os.getenv("GEMINI_API_KEY")
            if not gemini_api_key:
                print("⚠️ No Gemini API key found - using fallback optimization")
                self.gemini_available = False
                return
            genai.configure(api_key=gemini_api_key)
            self.model = genai.GenerativeModel("gemini-1.5-flash")
            print("✅ Gemini response optimization model initialized successfully")
        except Exception as e:
            print(f"⚠️ Failed to initialize Gemini client: {e}")
            self.gemini_available = False
    
    async def analyze_response(self, response_text: str) -> ResponseAnalysis:
        """Analyze RAG response for optimization opportunities (Context7)"""
        if not self.gemini_available or not self.model:
            # Fallback analysis
            return ResponseAnalysis(
                has_duplicates=len(response_text.split()) > 200,  # Simple heuristic
                repetitive_sections=[],
                clarity_score=7.0,
                completeness_score=8.0,
                formatting_issues=["No detailed analysis available"],
                key_points=["Analysis not available"],
                improvement_suggestions=["Use Gemini API for detailed analysis"]
            )
        try:
            # Context7: Define response schema as Python dict (verified pattern)
            analysis_schema = {
                "type": "OBJECT",
                "properties": {
                    "has_duplicates": {"type": "BOOLEAN"},
                    "repetitive_sections": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "clarity_score": {"type": "NUMBER"},
                    "completeness_score": {"type": "NUMBER"},
                    "formatting_issues": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "key_points": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "improvement_suggestions": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    }
                },
                "required": [
                    "has_duplicates",
                    "clarity_score",
                    "completeness_score"
                ]
            }
            
            analysis_prompt = f"""Sen profesyonel bir metin analiz uzmanısın. Verilen RAG yanıtını analiz et.

GÖREV:
1. **Tekrarları Tespit Et**: Aynı bilgilerin tekrar edildiği yerleri bul
2. **Netlik Değerlendir**: Yanıtın ne kadar anlaşılır olduğunu değerlendir (1-10)
3. **Tamlık Kontrolü**: Eksik bilgi olup olmadığını kontrol et (1-10)
4. **Formatlanma Sorunları**: Düzensiz formatlanma problemlerini tespit et
5. **Ana Noktalar**: Yanıttaki temel bilgileri listele
6. **İyileştirme Önerileri**: Spesifik iyileştirme önerilerini belirt

RAG YANITI:
{response_text}

Yanıtını JSON formatında ver. Output tam olarak JSON formatında olmalı ve sadece JSON içermeli, başka açıklama olmamalı."""
            
            # Context7: Use structured output with response_mime_type and response_schema
            generation_config = genai_types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=analysis_schema,
                temperature=0.2
            )
            
            response = await asyncio.to_thread(
                lambda: self.model.generate_content(
                    contents=analysis_prompt,
                    config=generation_config
                )
            )
            
            # Context7: Use the parsed attribute when response_schema is provided
            if hasattr(response, "parsed") and response.parsed:
                print("✅ Structured output parsed successfully!")
                analysis_result = response.parsed
            else:
                # Fall back to text parsing if structured output failed
                print("⚠️ Structured output not available, falling back to text parsing")
                content = response.text if hasattr(response, 'text') else str(response)
                # Clean the content to ensure it's valid JSON
                content = content.strip()
                if content.startswith("```json"):
                    content = content.split("```json")[1].split("```")[0].strip()
                elif content.startswith("```"):
                    content = content.split("```")[1].split("```")[0].strip()
                
                print(f"Raw content: {content[:100]}...")
                analysis_result = json.loads(content)
            
            return ResponseAnalysis(**analysis_result)
        except Exception as e:
            print(f"⚠️ Response analysis failed: {str(e)}")
            return ResponseAnalysis(
                has_duplicates=False,
                repetitive_sections=[],
                clarity_score=6.0,
                completeness_score=7.0,
                formatting_issues=[f"Analysis error: {str(e)}"],
                key_points=["Analysis failed"],
                improvement_suggestions=["Manual review recommended"]
            )
    
    async def optimize_response(self, response_text: str, analysis: ResponseAnalysis) -> OptimizedResponse:
        """Optimize RAG response based on analysis (Context7)"""
        if not self.gemini_available or not self.model:
            return OptimizedResponse(
                optimized_content=response_text,  # No optimization
                removed_duplicates=[],
                formatting_improvements=["No optimization available"],
                clarity_improvements=["Use Gemini API for optimization"],
                optimization_score=5.0,
                processing_notes="Fallback: No optimization applied"
            )
        try:
            # Context7: Define response schema as Python dict (verified pattern)
            optimization_schema = {
                "type": "OBJECT",
                "properties": {
                    "optimized_content": {"type": "STRING"},
                    "removed_duplicates": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "formatting_improvements": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "clarity_improvements": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "optimization_score": {"type": "NUMBER"},
                    "processing_notes": {"type": "STRING"}
                },
                "required": [
                    "optimized_content",
                    "optimization_score",
                    "processing_notes"
                ]
            }
            
            optimization_prompt = f"""Sen profesyonel bir metin optimizasyon uzmanısın. RAG yanıtını iyileştir.

OPTIMIZASYON GÖREVLERİ:
1. **Tekrarları Temizle**: Duplicate content'i kaldır, tek versiyonunu bırak
2. **Formatlanmayı İyileştir**: Professional business format uygula
3. **Netliği Artır**: Daha anlaşılır ve akıcı hale getir
4. **Yapıyı Düzenle**: Logical flow ve organization sağla

FORMATLANMA KURALLARI:
- **Başlıklar**: Emoji + **Kalın** format kullan (💡 **Öğrenilen Prosedür**)
- **Listeler**: Madde işaretleri ile organize et
- **Adımlar**: Numaralı listeler ile sıralama
- **Vurgu**: Önemli noktaları **kalın** yap
- **Kaynak**: [Belge X, Slide Y] formatında referanslar

ORIGINAL RESPONSE:
{response_text}

ANALYSIS BULGULARI:
- Duplicates detected: {analysis.has_duplicates}
- Clarity score: {analysis.clarity_score}/10
- Completeness score: {analysis.completeness_score}/10
- Issues: {', '.join(analysis.formatting_issues)}

Yanıtını JSON formatında ver. Output tam olarak JSON formatında olmalı ve sadece JSON içermeli, başka açıklama olmamalı."""
            
            # Context7: Use structured output with response_mime_type and response_schema
            generation_config = genai_types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=optimization_schema,
                temperature=0.2
            )
            
            response = await asyncio.to_thread(
                lambda: self.model.generate_content(
                    contents=optimization_prompt,
                    config=generation_config
                )
            )
            
            # Context7: Use the parsed attribute when response_schema is provided
            if hasattr(response, "parsed") and response.parsed:
                print("✅ Structured output parsed successfully!")
                optimization_result = response.parsed
            else:
                # Fall back to text parsing if structured output failed
                print("⚠️ Structured output not available, falling back to text parsing")
                content = response.text if hasattr(response, 'text') else str(response)
                # Clean the content to ensure it's valid JSON
                content = content.strip()
                if content.startswith("```json"):
                    content = content.split("```json")[1].split("```")[0].strip()
                elif content.startswith("```"):
                    content = content.split("```")[1].split("```")[0].strip()
                
                print(f"Raw content: {content[:100]}...")
                optimization_result = json.loads(content)
            
            return OptimizedResponse(**optimization_result)
        except Exception as e:
            print(f"⚠️ Response optimization failed: {str(e)}")
            return OptimizedResponse(
                optimized_content=response_text,
                removed_duplicates=[],
                formatting_improvements=[],
                clarity_improvements=[],
                optimization_score=5.0,
                processing_notes=f"Optimization failed: {str(e)}"
            )
    
    async def optimize_rag_response(self, original_response: str) -> ResponseOptimizationResult:
        """
        Complete response optimization workflow (Context7)
        Flow:
        1. User asks question → RAG generates response
        2. Response Analyzer analyzes the response
        3. Response Optimizer optimizes based on analysis
        4. Return polished, professional response
        """
        import time
        start_time = time.time()
        try:
            print(f"🎯 Starting response optimization for {len(original_response)} character response")
            print("📊 Step 1: Analyzing response...")
            analysis = await self.analyze_response(original_response)
            print(f"✅ Analysis complete - Clarity: {analysis.clarity_score}/10, Duplicates: {analysis.has_duplicates}")
            print("⚡ Step 2: Optimizing response...")
            optimized = await self.optimize_response(original_response, analysis)
            print(f"✅ Optimization complete - Score: {optimized.optimization_score}/10")
            processing_time_ms = int((time.time() - start_time) * 1000)
            result = ResponseOptimizationResult(
                original_response=original_response,
                analysis=analysis,
                optimized_response=optimized,
                optimization_applied=self.gemini_available,
                processing_time_ms=processing_time_ms
            )
            print(f"🎉 Response optimization completed in {processing_time_ms}ms")
            return result
        except Exception as e:
            processing_time_ms = int((time.time() - start_time) * 1000)
            print(f"❌ Response optimization failed: {e}")
            return ResponseOptimizationResult(
                original_response=original_response,
                analysis=ResponseAnalysis(
                    has_duplicates=False,
                    repetitive_sections=[],
                    clarity_score=6.0,
                    completeness_score=7.0,
                    formatting_issues=[f"Error: {str(e)}"],
                    key_points=["Error in analysis"],
                    improvement_suggestions=["Manual review needed"]
                ),
                optimized_response=OptimizedResponse(
                    optimized_content=original_response,
                    removed_duplicates=[],
                    formatting_improvements=[],
                    clarity_improvements=[],
                    optimization_score=5.0,
                    processing_notes=f"Error: {str(e)}"
                ),
                optimization_applied=False,
                processing_time_ms=processing_time_ms
            )

async def test_gemini_optimizer():
    """
    Test the Gemini response optimizer with a sample RAG response
    """
    print("🧪 Testing Gemini Response Optimizer with Structured Output...")
    
    # Sample RAG response
    sample_response = """
    FX işlemlerinizi bankacılık kanalları üzerinden gerçekleştirebilirsiniz. İşte FX emirleri nasıl verilir:

    FX emirleri şu kanallar üzerinden verilebilir:
    - İnternet Bankacılığı
    - Mobil Bankacılık
    - Şube
    - Müşteri İletişim Merkezi

    FX emir türleri:
    - Piyasa Emri (Market Order): Mevcut piyasa fiyatından hemen gerçekleştirilir.
    - Limit Emir: Belirli bir fiyat seviyesinde veya daha iyi bir fiyattan gerçekleştirilir.
    - Stop Emir: Belirlenen bir fiyat seviyesine ulaşıldığında aktifleşir.

    FX emirleri internet bankacılığı üzerinden şu şekilde verilir:
    1. İnternet bankacılığına giriş yapın
    2. "Yatırım" menüsüne tıklayın
    3. "Döviz İşlemleri" seçeneğini seçin
    4. "FX İşlemleri" butonuna tıklayın
    5. İşlem yapmak istediğiniz para birimini seçin
    6. Emir türünü belirleyin
    7. Tutarı girin
    8. İşlemi onaylayın

    Mobil bankacılık üzerinden FX emirleri:
    1. Mobil bankacılık uygulamasına giriş yapın
    2. Alt menüden "Yatırım" sekmesine gelin
    3. "Döviz İşlemleri" seçeneğine tıklayın
    4. "FX İşlemleri" butonunu seçin
    5. Para birimini ve emir türünü belirleyin
    6. İşlem tutarını girin
    7. Onay verin

    İnternet bankacılığı üzerinden FX emirleri verilirken dikkat edilmesi gereken hususlar:
    - Piyasa koşulları hızla değişebileceğinden işlem yapmadan önce güncel kurları kontrol edin.
    - Yüksek tutarlı işlemlerde şubeden destek almanız daha uygun olabilir.
    - İşlem saatleri ve komisyon oranları hakkında bilgi alın.
    - Emir tipleri ve özellikleri hakkında bilgi sahibi olun.

    FX emirlerinizi mobil bankacılık üzerinden verirken internet bağlantınızın güçlü olduğundan emin olun.
    
    FX işlemlerinizi Müşteri İletişim Merkezi üzerinden de gerçekleştirebilirsiniz. Bunun için 0850 222 0 800 numaralı hattı arayabilirsiniz.
    """
    
    try:
        # Create and call the response optimizer
        optimizer = SimpleGeminiOptimizer()
        print("🚀 Calling Gemini Response Optimizer...")
        result = await optimizer.optimize_rag_response(sample_response)
        
        # Print results
        print("\n" + "="*50)
        print("📊 ANALYSIS RESULTS:")
        print("="*50)
        print(f"Has duplicates: {result.analysis.has_duplicates}")
        print(f"Clarity score: {result.analysis.clarity_score}/10")
        print(f"Completeness score: {result.analysis.completeness_score}/10")
        print(f"Key points found: {len(result.analysis.key_points)}")
        print(f"Formatting issues: {result.analysis.formatting_issues}")
        
        print("\n" + "="*50)
        print("⚡ OPTIMIZATION RESULTS:")
        print("="*50)
        print(f"Optimization score: {result.optimized_response.optimization_score}/10")
        print(f"Processing time: {result.processing_time_ms}ms")
        print(f"Removed duplicates: {len(result.optimized_response.removed_duplicates)}")
        print(f"Formatting improvements: {result.optimized_response.formatting_improvements}")
        
        print("\n" + "="*50)
        print("📝 OPTIMIZED CONTENT:")
        print("="*50)
        print(result.optimized_response.optimized_content)
        
        return result
    except Exception as e:
        print(f"❌ Error testing Gemini optimizer: {str(e)}")
        raise

if __name__ == "__main__":
    print("🔍 Context7 Gemini Response Optimizer Test")
    asyncio.run(test_gemini_optimizer()) 