#!/usr/bin/env python3
"""
Context7 Verified API Test Script
Test user registration and login with fresh database
"""
import requests
import json

def test_api():
    base_url = "http://localhost:8002/api/v1"
    
    print("🔧 Context7 API Testing Started...")
    
    # Test 1: Health Check
    print("\n1️⃣ Testing Health Endpoint...")
    try:
        response = requests.get(f"{base_url}/auth/health")
        print(f"✅ Health Status: {response.status_code}")
        print(f"📊 Response: {response.json()}")
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        return False
    
    # Test 2: User Registration
    print("\n2️⃣ Testing User Registration...")
    user_data = {
        "email": "test@example.com",
        "password": "test123456",
        "full_name": "Test User",
        "department": "IT"
    }
    
    try:
        response = requests.post(f"{base_url}/auth/register", json=user_data)
        print(f"✅ Registration Status: {response.status_code}")
        if response.status_code == 200:
            print(f"📊 User Created: {response.json()}")
        else:
            print(f"❌ Registration Error: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Registration failed: {e}")
        return False
    
    # Test 3: User Login
    print("\n3️⃣ Testing User Login...")
    login_data = {
        "email": "test@example.com",
        "password": "test123456"
    }
    
    try:
        response = requests.post(f"{base_url}/auth/login", json=login_data)
        print(f"✅ Login Status: {response.status_code}")
        if response.status_code == 200:
            login_response = response.json()
            print(f"📊 Login Success: {login_response.get('access_token', 'No token')[:50]}...")
            
            # Test 4: Get User Profile
            print("\n4️⃣ Testing User Profile...")
            headers = {"Authorization": f"Bearer {login_response.get('access_token')}"}
            profile_response = requests.get(f"{base_url}/auth/me", headers=headers)
            print(f"✅ Profile Status: {profile_response.status_code}")
            if profile_response.status_code == 200:
                profile = profile_response.json()
                print(f"📊 User Profile: {profile.get('email')} - {profile.get('full_name')}")
                print(f"🎯 User ID: {profile.get('id')}")
                print(f"🏢 Department: {profile.get('department')}")
            else:
                print(f"❌ Profile Error: {profile_response.text}")
                
        else:
            print(f"❌ Login Error: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Login failed: {e}")
        return False
    
    print("\n🎉 Context7 API Test Completed Successfully!")
    return True

if __name__ == "__main__":
    success = test_api()
    if not success:
        print("💥 API Test Failed!")
        exit(1) 