#!/usr/bin/env python3
"""
Simple FX Query Test After Context7 Rollback
"""
import requests
import json
import time

print("Testing FX query after Context7 rollback...")
time.sleep(10)  # Wait for server

try:
    response = requests.post(
        'http://localhost:8002/api/v1/chat/query',
        headers={'Content-Type': 'application/json'},
        json={'question': 'FX doviz islemleri hakkinda bilgi ver'},
        timeout=30
    )
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        answer = data.get('answer', '')
        
        print(f"Answer length: {len(answer)} chars")
        print(f"Answer preview: {answer[:300]}...")
        print(f"Documents Found: {data.get('documents_found', 0)}")
        
        if 'I apologize, but I encountered an error' in answer:
            print("❌ Still getting error message")
        elif len(answer) < 10:
            print("❌ Empty or very short response")
        else:
            print("✅ Normal response received!")
            print("✅ Context7 rollback successful!")
    else:
        print(f"❌ HTTP Error: {response.status_code}")
        
except Exception as e:
    print(f"❌ Failed: {e}") 