"""
🎯 Priority Routing Service - Phase 4.7
Context7 verified implementation for intelligent query routing

Features:
- Sentiment-based priority calculation  
- SLA rules for different banking categories
- Escalation engine for high-priority cases
- Queue management with priority scoring
- Integration with sentiment analysis & agent handoff
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import logging
import uuid

from .sentiment_analysis_service import SentimentAnalysisService, SentimentResult
from .agent_handoff_service import AgentHandoffService, BankingDepartment

logger = logging.getLogger(__name__)

class PriorityLevel(str, Enum):
    """Priority levels for routing"""
    LOW = "low"           # Normal queries, standard SLA
    MEDIUM = "medium"     # Important queries, faster response needed
    HIGH = "high"         # Urgent queries, immediate attention
    CRITICAL = "critical" # Emergency queries, instant escalation

class RoutingDecision(str, Enum):
    """Routing decision types"""
    DIRECT_ROUTE = "direct_route"           # Route directly to department
    ESCALATE = "escalate"                   # Escalate to supervisor
    QUEUE_PRIORITY = "queue_priority"       # Add to priority queue
    IMMEDIATE_RESPONSE = "immediate_response" # Needs instant response

@dataclass
class PriorityScore:
    """Priority scoring breakdown"""
    base_score: float           # Base priority (0-100)
    sentiment_modifier: float   # Sentiment-based adjustment
    urgency_modifier: float     # Urgency keywords adjustment  
    category_modifier: float    # Banking category priority
    time_modifier: float        # Time-based factors
    final_score: float          # Final calculated priority
    priority_level: PriorityLevel
    
@dataclass
class RoutingPlan:
    """Complete routing plan for a query"""
    routing_id: str
    priority_score: PriorityScore
    recommended_department: BankingDepartment
    routing_decision: RoutingDecision
    estimated_response_time: int  # minutes
    sla_deadline: datetime
    escalation_path: List[str]
    routing_reasons: List[str]
    confidence: float
    metadata: Dict[str, Any]

class PriorityRoutingService:
    """
    🎯 Context7 Verified Priority Routing Service
    Turkish Banking Intelligent Query Routing System
    """
    
    def __init__(self):
        self.sentiment_service = SentimentAnalysisService()
        self.handoff_service = AgentHandoffService()
        self.is_initialized = False
        
        # SLA Rules for different banking categories (in minutes)
        self.sla_rules = {
            "kredi_ve_borc": {
                PriorityLevel.LOW: 180,      # 3 hours
                PriorityLevel.MEDIUM: 120,   # 2 hours  
                PriorityLevel.HIGH: 60,      # 1 hour
                PriorityLevel.CRITICAL: 15   # 15 minutes
            },
            "hesap_islemleri": {
                PriorityLevel.LOW: 120,      # 2 hours
                PriorityLevel.MEDIUM: 60,    # 1 hour
                PriorityLevel.HIGH: 30,      # 30 minutes
                PriorityLevel.CRITICAL: 10   # 10 minutes
            },
            "kart_islemleri": {
                PriorityLevel.LOW: 90,       # 1.5 hours
                PriorityLevel.MEDIUM: 45,    # 45 minutes
                PriorityLevel.HIGH: 20,      # 20 minutes
                PriorityLevel.CRITICAL: 5    # 5 minutes
            },
            "sikayet_ve_destek": {
                PriorityLevel.LOW: 240,      # 4 hours
                PriorityLevel.MEDIUM: 180,   # 3 hours
                PriorityLevel.HIGH: 90,      # 1.5 hours
                PriorityLevel.CRITICAL: 30   # 30 minutes
            },
            "yasal_ve_uyumluluk": {
                PriorityLevel.LOW: 480,      # 8 hours
                PriorityLevel.MEDIUM: 240,   # 4 hours
                PriorityLevel.HIGH: 120,     # 2 hours
                PriorityLevel.CRITICAL: 60   # 1 hour
            },
            "guvenlik_ve_risk": {
                PriorityLevel.LOW: 60,       # 1 hour
                PriorityLevel.MEDIUM: 30,    # 30 minutes
                PriorityLevel.HIGH: 15,      # 15 minutes
                PriorityLevel.CRITICAL: 5    # 5 minutes (emergency)
            },
            "genel_bilgi": {
                PriorityLevel.LOW: 300,      # 5 hours
                PriorityLevel.MEDIUM: 180,   # 3 hours
                PriorityLevel.HIGH: 120,     # 2 hours
                PriorityLevel.CRITICAL: 60   # 1 hour
            }
        }
        
        # Urgency indicators with weights
        self.urgency_indicators = {
            "critical": {
                "keywords": ["acil", "hemen", "kritik", "çok önemli", "asla beklemez", "derhal"],
                "weight": 40.0
            },
            "high": {
                "keywords": ["önemli", "hızlı", "ivedi", "bekleyemem", "sorun var"],
                "weight": 25.0
            },
            "medium": {
                "keywords": ["yakında", "mümkün olduğunca", "tercihen", "olabildiğince"],
                "weight": 15.0
            },
            "security": {
                "keywords": ["dolandırıldım", "çalındı", "hack", "şüpheli işlem", "fraud", "güvenlik"],
                "weight": 50.0  # Security issues get maximum priority
            }
        }
        
        # Escalation paths by department
        self.escalation_paths = {
            BankingDepartment.CREDITS: ["senior_credit_analyst", "credit_manager", "branch_manager"],
            BankingDepartment.OPERATIONS: ["senior_operations", "ops_manager", "branch_manager"],
            BankingDepartment.CUSTOMER_SERVICE: ["team_lead", "customer_manager", "branch_manager"],
            BankingDepartment.COMPLIANCE: ["compliance_manager", "legal_counsel", "executive_management"],
            BankingDepartment.RISK_MANAGEMENT: ["risk_manager", "chief_risk_officer", "executive_management"]
        }
        
        logger.info("🎯 Priority Routing Service initialized")

    async def initialize(self) -> bool:
        """Initialize priority routing service"""
        try:
            # Initialize sentiment service
            if not self.sentiment_service.is_initialized:
                await self.sentiment_service.initialize()
            
            self.is_initialized = True
            logger.info("✅ Priority Routing Service ready")
            return True
            
        except Exception as e:
            logger.error(f"❌ Priority Routing Service initialization failed: {str(e)}")
            return False

    async def calculate_priority_score(
        self, 
        query: str, 
        sentiment_result: Optional[SentimentResult] = None,
        context: Dict[str, Any] = None
    ) -> PriorityScore:
        """
        Calculate comprehensive priority score for a query
        """
        try:
            # Get sentiment analysis if not provided
            if sentiment_result is None:
                sentiment_result = await self.sentiment_service.analyze_sentiment(query, context)
            
            # Base score calculation (0-100)
            base_score = 50.0  # Start with medium priority
            
            # 1. Sentiment-based modifier
            sentiment_modifier = self._calculate_sentiment_modifier(sentiment_result)
            
            # 2. Urgency keywords modifier  
            urgency_modifier = self._calculate_urgency_modifier(query)
            
            # 3. Banking category modifier
            category_modifier = self._calculate_category_modifier(query, sentiment_result)
            
            # 4. Time-based modifier (business hours, holidays etc.)
            time_modifier = self._calculate_time_modifier()
            
            # Calculate final score
            final_score = min(100.0, max(0.0, 
                base_score + sentiment_modifier + urgency_modifier + category_modifier + time_modifier
            ))
            
            # Determine priority level
            priority_level = self._determine_priority_level(final_score)
            
            return PriorityScore(
                base_score=base_score,
                sentiment_modifier=sentiment_modifier,
                urgency_modifier=urgency_modifier,
                category_modifier=category_modifier,
                time_modifier=time_modifier,
                final_score=final_score,
                priority_level=priority_level
            )
            
        except Exception as e:
            logger.error(f"❌ Priority calculation error: {str(e)}")
            # Return medium priority on error
            return PriorityScore(
                base_score=50.0,
                sentiment_modifier=0.0,
                urgency_modifier=0.0,
                category_modifier=0.0,
                time_modifier=0.0,
                final_score=50.0,
                priority_level=PriorityLevel.MEDIUM
            )

    async def create_routing_plan(
        self,
        query: str,
        customer_context: Dict[str, Any] = None,
        conversation_history: List[str] = None
    ) -> RoutingPlan:
        """
        Create comprehensive routing plan for a customer query
        """
        try:
            routing_id = str(uuid.uuid4())
            
            # Analyze sentiment and category
            sentiment_result = await self.sentiment_service.analyze_sentiment(query, customer_context)
            category_result = await self.sentiment_service.categorize_query(query, sentiment_result)
            
            # Calculate priority score
            priority_score = await self.calculate_priority_score(query, sentiment_result, customer_context)
            
            # Determine recommended department
            recommended_department = self._determine_department(category_result, priority_score)
            
            # Determine routing decision
            routing_decision = self._determine_routing_decision(priority_score, sentiment_result)
            
            # Calculate SLA and response time
            estimated_response_time = self._calculate_response_time(
                category_result.primary_category, 
                priority_score.priority_level
            )
            
            sla_deadline = datetime.now() + timedelta(minutes=estimated_response_time)
            
            # Build escalation path
            escalation_path = self.escalation_paths.get(recommended_department, [])
            
            # Collect routing reasons
            routing_reasons = self._build_routing_reasons(
                priority_score, sentiment_result, category_result
            )
            
            # Calculate confidence
            confidence = self._calculate_routing_confidence(
                sentiment_result, category_result, priority_score
            )
            
            # Build metadata
            metadata = {
                "sentiment_analysis": {
                    "score": sentiment_result.sentiment_score,
                    "label": sentiment_result.sentiment_label,
                    "emotions": sentiment_result.emotion_indicators
                },
                "category_analysis": {
                    "primary": category_result.primary_category,
                    "confidence": category_result.confidence_scores
                },
                "timestamp": datetime.now().isoformat(),
                "query_length": len(query),
                "has_context": customer_context is not None,
                "has_history": conversation_history is not None
            }
            
            return RoutingPlan(
                routing_id=routing_id,
                priority_score=priority_score,
                recommended_department=recommended_department,
                routing_decision=routing_decision,
                estimated_response_time=estimated_response_time,
                sla_deadline=sla_deadline,
                escalation_path=escalation_path,
                routing_reasons=routing_reasons,
                confidence=confidence,
                metadata=metadata
            )
            
        except Exception as e:
            logger.error(f"❌ Routing plan creation error: {str(e)}")
            # Return basic routing plan
            return RoutingPlan(
                routing_id=str(uuid.uuid4()),
                priority_score=PriorityScore(50.0, 0.0, 0.0, 0.0, 0.0, 50.0, PriorityLevel.MEDIUM),
                recommended_department=BankingDepartment.CUSTOMER_SERVICE,
                routing_decision=RoutingDecision.QUEUE_PRIORITY,
                estimated_response_time=180,
                sla_deadline=datetime.now() + timedelta(minutes=180),
                escalation_path=[],
                routing_reasons=["Fallback routing due to analysis error"],
                confidence=0.5,
                metadata={"error": str(e)}
            )

    def _calculate_sentiment_modifier(self, sentiment_result: SentimentResult) -> float:
        """Calculate priority modifier based on sentiment"""
        score = sentiment_result.sentiment_score
        
        if score <= -0.7:  # Very negative
            return 30.0
        elif score <= -0.3:  # Negative
            return 20.0
        elif score <= 0.3:   # Neutral
            return 0.0
        elif score <= 0.7:   # Positive
            return -5.0
        else:                # Very positive
            return -10.0

    def _calculate_urgency_modifier(self, query: str) -> float:
        """Calculate priority modifier based on urgency keywords"""
        query_lower = query.lower()
        max_urgency = 0.0
        
        for urgency_level, config in self.urgency_indicators.items():
            for keyword in config["keywords"]:
                if keyword in query_lower:
                    max_urgency = max(max_urgency, config["weight"])
        
        return max_urgency

    def _calculate_category_modifier(self, query: str, sentiment_result: SentimentResult) -> float:
        """Calculate priority modifier based on banking category"""
        # Security and risk categories get highest priority
        query_lower = query.lower()
        
        security_keywords = ["dolandırıldım", "çalındı", "hack", "şüpheli", "fraud", "güvenlik"]
        risk_keywords = ["risk", "tehlike", "kayıp", "zarar"]
        
        if any(keyword in query_lower for keyword in security_keywords):
            return 25.0
        elif any(keyword in query_lower for keyword in risk_keywords):
            return 15.0
        elif sentiment_result.banking_context.get("is_complaint", False):
            return 10.0
        else:
            return 0.0

    def _calculate_time_modifier(self) -> float:
        """Calculate priority modifier based on current time"""
        now = datetime.now()
        hour = now.hour
        
        # Business hours: 09:00 - 17:00 = normal
        # Outside business hours = higher priority
        # Weekend = higher priority
        
        if now.weekday() >= 5:  # Weekend
            return 5.0
        elif hour < 9 or hour > 17:  # Outside business hours
            return 3.0
        else:
            return 0.0

    def _determine_priority_level(self, score: float) -> PriorityLevel:
        """Determine priority level from score"""
        if score >= 80:
            return PriorityLevel.CRITICAL
        elif score >= 65:
            return PriorityLevel.HIGH
        elif score >= 40:
            return PriorityLevel.MEDIUM
        else:
            return PriorityLevel.LOW

    def _determine_department(self, category_result, priority_score: PriorityScore) -> BankingDepartment:
        """Determine best department based on category and priority"""
        primary_category = category_result.primary_category
        
        # Category to department mapping
        category_mapping = {
            "kredi_ve_borc": BankingDepartment.CREDITS,
            "hesap_islemleri": BankingDepartment.OPERATIONS,
            "kart_islemleri": BankingDepartment.OPERATIONS,
            "sikayet_ve_destek": BankingDepartment.CUSTOMER_SERVICE,
            "yasal_ve_uyumluluk": BankingDepartment.COMPLIANCE,
            "guvenlik_ve_risk": BankingDepartment.RISK_MANAGEMENT,
            "genel_bilgi": BankingDepartment.CUSTOMER_SERVICE
        }
        
        # High priority security issues go to Risk Management
        if priority_score.priority_level == PriorityLevel.CRITICAL and \
           priority_score.urgency_modifier > 40:
            return BankingDepartment.RISK_MANAGEMENT
        
        return category_mapping.get(primary_category, BankingDepartment.CUSTOMER_SERVICE)

    def _determine_routing_decision(
        self, 
        priority_score: PriorityScore, 
        sentiment_result: SentimentResult
    ) -> RoutingDecision:
        """Determine routing decision based on priority and sentiment"""
        
        if priority_score.priority_level == PriorityLevel.CRITICAL:
            return RoutingDecision.IMMEDIATE_RESPONSE
        elif priority_score.priority_level == PriorityLevel.HIGH:
            return RoutingDecision.ESCALATE
        elif sentiment_result.sentiment_score <= -0.5:
            return RoutingDecision.QUEUE_PRIORITY
        else:
            return RoutingDecision.DIRECT_ROUTE

    def _calculate_response_time(self, category: str, priority_level: PriorityLevel) -> int:
        """Calculate estimated response time based on SLA rules"""
        return self.sla_rules.get(category, {}).get(
            priority_level, 
            self.sla_rules["genel_bilgi"][priority_level]
        )

    def _build_routing_reasons(
        self, 
        priority_score: PriorityScore, 
        sentiment_result: SentimentResult, 
        category_result
    ) -> List[str]:
        """Build list of routing reasons"""
        reasons = []
        
        if priority_score.priority_level in [PriorityLevel.HIGH, PriorityLevel.CRITICAL]:
            reasons.append(f"Yüksek öncelik seviyesi: {priority_score.priority_level.value}")
        
        if sentiment_result.sentiment_score <= -0.5:
            reasons.append("Negatif müşteri duygusu")
        
        if priority_score.urgency_modifier > 20:
            reasons.append("Aciliyet göstergeleri tespit edildi")
        
        if priority_score.category_modifier > 10:
            reasons.append("Güvenlik/risk kategorisi")
        
        reasons.append(f"Kategori eşleşmesi: {category_result.primary_category}")
        
        return reasons

    def _calculate_routing_confidence(
        self, 
        sentiment_result: SentimentResult, 
        category_result, 
        priority_score: PriorityScore
    ) -> float:
        """Calculate confidence in routing decision"""
        
        # Start with sentiment confidence
        confidence = sentiment_result.confidence
        
        # Adjust based on category confidence
        max_category_confidence = max(category_result.confidence_scores.values()) if category_result.confidence_scores else 0.5
        confidence = (confidence + max_category_confidence) / 2
        
        # Boost confidence for clear high/critical priority
        if priority_score.priority_level in [PriorityLevel.HIGH, PriorityLevel.CRITICAL]:
            confidence = min(1.0, confidence + 0.1)
        
        return round(confidence, 2)

    async def get_routing_statistics(self) -> Dict[str, Any]:
        """Get priority routing service statistics"""
        return {
            "service_name": "Priority Routing Service",
            "version": "1.0.0",
            "is_initialized": self.is_initialized,
            "priority_levels": [level.value for level in PriorityLevel],
            "routing_decisions": [decision.value for decision in RoutingDecision],
            "supported_departments": [dept.value for dept in BankingDepartment],
            "sla_categories": list(self.sla_rules.keys()),
            "urgency_indicators": len(sum([config["keywords"] for config in self.urgency_indicators.values()], [])),
            "escalation_paths": {dept.value: len(path) for dept, path in self.escalation_paths.items()}
        }

# Global priority routing service instance
priority_routing_service = PriorityRoutingService() 