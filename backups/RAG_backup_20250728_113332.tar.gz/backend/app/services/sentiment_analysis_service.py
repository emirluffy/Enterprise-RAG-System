"""
Sentiment Analysis & Auto-categorization Service for Phase 4
Advanced Turkish language sentiment analysis with banking domain specialization.
"""

import logging
import re
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from dataclasses import dataclass

# NLP libraries
from textblob import TextBlob
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import torch

from ..core.config import settings

logger = logging.getLogger(__name__)

@dataclass
class SentimentResult:
    """Sentiment analysis result structure."""
    sentiment_score: float  # -1 (very negative) to 1 (very positive)
    sentiment_label: str    # "positive", "negative", "neutral"
    confidence: float       # 0 to 1
    priority_level: str     # "low", "medium", "high", "urgent"
    emotion_indicators: Dict[str, int]
    banking_context: Dict[str, Any]

@dataclass
class CategoryResult:
    """Auto-categorization result structure."""
    primary_category: str
    secondary_categories: List[str]
    confidence_scores: Dict[str, float]
    keywords_found: List[str]
    department_recommendation: str

class SentimentAnalysisService:
    """Advanced sentiment analysis and categorization for Turkish banking domain."""
    
    def __init__(self):
        self.is_initialized = False
        self.transformer_model = None
        self.tokenizer = None
        
        # Turkish Banking Domain Sentiment Lexicon
        self.turkish_sentiment_lexicon = {
            "very_positive": {
                "words": ["mükemmel", "harika", "fevkalade", "muhteşem", "süper", "fantastik", "olağanüstü"],
                "weight": 1.0
            },
            "positive": {
                "words": ["iyi", "güzel", "memnun", "başarılı", "teşekkür", "hoş", "faydalı", "hızlı", "kolay"],
                "weight": 0.7
            },
            "negative": {
                "words": ["kötü", "berbat", "sorun", "problem", "şikayet", "zor", "yavaş", "karmaşık", "eksik"],
                "weight": -0.7
            },
            "very_negative": {
                "words": ["rezalet", "felaket", "korkunç", "berbat", "çok kötü", "iğrenç", "kabul edilemez"],
                "weight": -1.0
            },
            "urgent": {
                "words": ["acil", "hemen", "derhal", "ivedi", "kritik", "önemli", "çok önemli", "asla beklemez"],
                "weight": 0.0  # neutral for sentiment but high for priority
            }
        }
        
        # Banking-specific emotional indicators
        self.banking_emotions = {
            "frustration": ["sinirli", "kızgın", "öfkeli", "rahatsız", "tedirgin", "kaygılı"],
            "satisfaction": ["memnun", "mutlu", "rahat", "güvenli", "tatmin"],
            "confusion": ["anlamadım", "karışık", "belirsiz", "net değil", "açık değil"],
            "urgency": ["acil", "hemen", "derhal", "bekleyemem", "kritik"],
            "trust": ["güveniyorum", "emin", "güvenli", "sağlam", "güvenilir"],
            "distrust": ["güvenmiyorum", "şüpheli", "endişeli", "kaygılı", "çekinceli"]
        }
        
        # Banking domain categories with Turkish keywords
        self.banking_categories = {
            "kredi_ve_borc": {
                "keywords": ["kredi", "borç", "taksit", "faiz", "ödeme", "limit", "teminat", "kefil"],
                "department": "credits",
                "priority_multiplier": 1.2
            },
            "hesap_islemleri": {
                "keywords": ["hesap", "bakiye", "havale", "eft", "swift", "transfer", "para"],
                "department": "operations", 
                "priority_multiplier": 1.0
            },
            "kart_islemleri": {
                "keywords": ["kart", "atm", "pos", "çekim", "ödeme", "nakit", "kredi kartı"],
                "department": "operations",
                "priority_multiplier": 1.1
            },
            "sikayet_ve_destek": {
                "keywords": ["şikayet", "sorun", "problem", "yardım", "destek", "çözüm", "mağdur"],
                "department": "customer_service",
                "priority_multiplier": 1.5
            },
            "yasal_ve_uyumluluk": {
                "keywords": ["yasal", "hukuki", "bddk", "kanun", "düzenleme", "uyumluluk", "hak"],
                "department": "compliance",
                "priority_multiplier": 1.3
            },
            "guvenlik_ve_risk": {
                "keywords": ["güvenlik", "dolandırıcılık", "fraud", "şüpheli", "risk", "güven"],
                "department": "risk_management", 
                "priority_multiplier": 1.8
            },
            "genel_bilgi": {
                "keywords": ["bilgi", "öğrenmek", "nasıl", "ne", "hangi", "soru", "merak"],
                "department": "customer_service",
                "priority_multiplier": 0.8
            }
        }
        
    async def initialize(self) -> bool:
        """Initialize sentiment analysis models."""
        try:
            logger.info("🚀 Initializing Sentiment Analysis Service")
            
            # Try to load Turkish BERT model for better accuracy
            try:
                model_name = "savasy/bert-base-turkish-sentiment-cased"
                self.tokenizer = AutoTokenizer.from_pretrained(model_name)
                self.transformer_model = AutoModelForSequenceClassification.from_pretrained(model_name)
                logger.info("✅ Turkish BERT sentiment model loaded")
            except Exception as e:
                logger.warning(f"⚠️ Could not load Turkish BERT model: {e}")
                logger.info("📝 Using TextBlob fallback for sentiment analysis")
            
            self.is_initialized = True
            logger.info("✅ Sentiment Analysis Service initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Sentiment Analysis Service initialization failed: {str(e)}")
            return False
    
    async def analyze_sentiment(self, text: str, context: Dict[str, Any] = None) -> SentimentResult:
        """Comprehensive sentiment analysis for Turkish banking text."""
        try:
            if not self.is_initialized:
                await self.initialize()
            
            # Clean and normalize text
            normalized_text = self._normalize_text(text)
            
            # Multiple sentiment analysis approaches
            lexicon_sentiment = self._lexicon_based_sentiment(normalized_text)
            transformer_sentiment = await self._transformer_sentiment(normalized_text)
            
            # Combine sentiment scores (weighted average)
            if transformer_sentiment:
                combined_score = (0.7 * transformer_sentiment + 0.3 * lexicon_sentiment)
            else:
                combined_score = lexicon_sentiment
            
            # Determine sentiment label and confidence
            sentiment_label, confidence = self._determine_sentiment_label(combined_score)
            
            # Analyze emotions
            emotion_indicators = self._analyze_emotions(normalized_text)
            
            # Calculate priority level
            priority_level = self._calculate_priority(combined_score, emotion_indicators, normalized_text)
            
            # Banking context analysis
            banking_context = self._analyze_banking_context(normalized_text, context)
            
            return SentimentResult(
                sentiment_score=combined_score,
                sentiment_label=sentiment_label,
                confidence=confidence,
                priority_level=priority_level,
                emotion_indicators=emotion_indicators,
                banking_context=banking_context
            )
            
        except Exception as e:
            logger.error(f"❌ Sentiment analysis error: {str(e)}")
            # Return neutral sentiment on error
            return SentimentResult(
                sentiment_score=0.0,
                sentiment_label="neutral",
                confidence=0.5,
                priority_level="medium",
                emotion_indicators={},
                banking_context={}
            )
    
    async def categorize_query(self, text: str, sentiment_result: SentimentResult = None) -> CategoryResult:
        """Auto-categorize banking queries with confidence scores."""
        try:
            normalized_text = self._normalize_text(text)
            
            # Calculate category scores
            category_scores = {}
            keywords_found = []
            
            for category, config in self.banking_categories.items():
                score = 0
                category_keywords = []
                
                for keyword in config["keywords"]:
                    if keyword in normalized_text:
                        score += 1
                        category_keywords.append(keyword)
                        keywords_found.append(keyword)
                
                # Apply priority multiplier if sentiment is negative
                if sentiment_result and sentiment_result.sentiment_score < -0.2:
                    score *= config["priority_multiplier"]
                
                # Normalize score
                if config["keywords"]:
                    category_scores[category] = score / len(config["keywords"])
                else:
                    category_scores[category] = 0
            
            # Find primary and secondary categories
            sorted_categories = sorted(category_scores.items(), key=lambda x: x[1], reverse=True)
            
            primary_category = sorted_categories[0][0] if sorted_categories else "genel_bilgi"
            secondary_categories = [cat for cat, score in sorted_categories[1:3] if score > 0.1]
            
            # Department recommendation
            department_recommendation = self.banking_categories[primary_category]["department"]
            
            return CategoryResult(
                primary_category=primary_category,
                secondary_categories=secondary_categories,
                confidence_scores=category_scores,
                keywords_found=list(set(keywords_found)),
                department_recommendation=department_recommendation
            )
            
        except Exception as e:
            logger.error(f"❌ Query categorization error: {str(e)}")
            return CategoryResult(
                primary_category="genel_bilgi",
                secondary_categories=[],
                confidence_scores={},
                keywords_found=[],
                department_recommendation="customer_service"
            )
    
    def _normalize_text(self, text: str) -> str:
        """Normalize Turkish text for analysis."""
        # Convert to lowercase
        text = text.lower()
        
        # Turkish character normalization
        replacements = {
            'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u'
        }
        
        # Remove extra whitespace and punctuation
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def _lexicon_based_sentiment(self, text: str) -> float:
        """Calculate sentiment using Turkish banking lexicon."""
        total_score = 0
        word_count = 0
        
        words = text.split()
        
        for sentiment_type, config in self.turkish_sentiment_lexicon.items():
            for word in config["words"]:
                if word in text:
                    total_score += config["weight"]
                    word_count += 1
        
        # Normalize score
        if word_count > 0:
            return max(-1.0, min(1.0, total_score / word_count))
        else:
            # Fallback to TextBlob
            try:
                blob = TextBlob(text)
                return blob.sentiment.polarity
            except:
                return 0.0
    
    async def _transformer_sentiment(self, text: str) -> Optional[float]:
        """Use transformer model for sentiment analysis."""
        if not self.transformer_model or not self.tokenizer:
            return None
        
        try:
            # Tokenize and predict
            inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
            
            with torch.no_grad():
                outputs = self.transformer_model(**inputs)
                predictions = torch.nn.functional.softmax(outputs.logits, dim=-1)
            
            # Convert to sentiment score (-1 to 1)
            # Assuming model outputs [negative, positive] probabilities
            neg_prob = predictions[0][0].item()
            pos_prob = predictions[0][1].item()
            
            sentiment_score = pos_prob - neg_prob
            return max(-1.0, min(1.0, sentiment_score))
            
        except Exception as e:
            logger.warning(f"⚠️ Transformer sentiment analysis failed: {e}")
            return None
    
    def _determine_sentiment_label(self, score: float) -> Tuple[str, float]:
        """Determine sentiment label and confidence from score."""
        abs_score = abs(score)
        
        if score > 0.3:
            return "positive", min(0.95, 0.5 + abs_score)
        elif score < -0.3:
            return "negative", min(0.95, 0.5 + abs_score)
        else:
            return "neutral", max(0.3, 0.8 - abs_score)
    
    def _analyze_emotions(self, text: str) -> Dict[str, int]:
        """Analyze emotional indicators in text."""
        emotion_counts = {}
        
        for emotion, words in self.banking_emotions.items():
            count = sum(1 for word in words if word in text)
            if count > 0:
                emotion_counts[emotion] = count
        
        return emotion_counts
    
    def _calculate_priority(self, sentiment_score: float, emotions: Dict[str, int], text: str) -> str:
        """Calculate priority level based on sentiment and emotions."""
        
        # Base priority from sentiment
        if sentiment_score < -0.7:
            base_priority = 3  # high
        elif sentiment_score < -0.3:
            base_priority = 2  # medium-high
        elif sentiment_score > 0.5:
            base_priority = 0  # low
        else:
            base_priority = 1  # medium
        
        # Adjust for emotions
        urgency_boost = emotions.get("urgency", 0) * 2
        frustration_boost = emotions.get("frustration", 0) * 1.5
        distrust_boost = emotions.get("distrust", 0) * 1.5
        
        # Urgent keywords boost
        urgent_keywords = ["acil", "hemen", "derhal", "kritik"]
        urgency_keyword_boost = sum(2 for keyword in urgent_keywords if keyword in text)
        
        total_priority = base_priority + urgency_boost + frustration_boost + distrust_boost + urgency_keyword_boost
        
        # Map to priority levels
        if total_priority >= 6:
            return "urgent"
        elif total_priority >= 4:
            return "high"
        elif total_priority >= 2:
            return "medium"
        else:
            return "low"
    
    def _analyze_banking_context(self, text: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Analyze banking-specific context."""
        banking_context = {
            "transaction_mentioned": bool(re.search(r'\d+(\.\d+)?\s*(tl|lira|₺)', text)),
            "account_mentioned": bool(re.search(r'hesap|iban|account', text)),
            "time_sensitive": bool(re.search(r'bugün|yarın|hemen|acil', text)),
            "customer_type": context.get("customer_type", "unknown") if context else "unknown",
            "previous_interactions": context.get("interaction_count", 0) if context else 0
        }
        
        return banking_context
    
    async def analyze_conversation_batch(self, messages: List[str]) -> Dict[str, Any]:
        """Analyze a batch of conversation messages for patterns."""
        try:
            batch_results = []
            
            for message in messages:
                sentiment_result = await self.analyze_sentiment(message)
                category_result = await self.categorize_query(message, sentiment_result)
                
                batch_results.append({
                    "message": message,
                    "sentiment": sentiment_result,
                    "category": category_result
                })
            
            # Aggregate analysis
            avg_sentiment = sum(r["sentiment"].sentiment_score for r in batch_results) / len(batch_results)
            priority_distribution = {}
            category_distribution = {}
            
            for result in batch_results:
                priority = result["sentiment"].priority_level
                category = result["category"].primary_category
                
                priority_distribution[priority] = priority_distribution.get(priority, 0) + 1
                category_distribution[category] = category_distribution.get(category, 0) + 1
            
            return {
                "individual_results": batch_results,
                "aggregate_analysis": {
                    "average_sentiment": avg_sentiment,
                    "priority_distribution": priority_distribution,
                    "category_distribution": category_distribution,
                    "total_messages": len(messages),
                    "analysis_timestamp": datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"❌ Batch analysis error: {str(e)}")
            return {"error": str(e)}
    
    async def get_service_statistics(self) -> Dict[str, Any]:
        """Get comprehensive service statistics."""
        return {
            "initialization_status": self.is_initialized,
            "model_available": self.transformer_model is not None,
            "sentiment_lexicon_size": sum(len(config["words"]) for config in self.turkish_sentiment_lexicon.values()),
            "banking_categories": len(self.banking_categories),
            "emotion_indicators": len(self.banking_emotions),
            "supported_languages": ["Turkish", "English"],
            "features": [
                "Turkish sentiment analysis",
                "Banking domain categorization", 
                "Emotion detection",
                "Priority calculation",
                "Batch processing",
                "Context awareness"
            ],
            "timestamp": datetime.now().isoformat()
        }

# Global sentiment analysis service instance
sentiment_service = SentimentAnalysisService() 