#!/usr/bin/env python3
"""
Context7 Verified Server Fix Test
Tests if the FX query works after server restart
"""
import requests
import json
import time

def test_context7_fix():
    print("Testing Context7 verified server fix...")
    time.sleep(5)  # Wait for server
    
    try:
        response = requests.post(
            'http://localhost:8002/api/v1/chat/query',
            headers={'Content-Type': 'application/json'},
            json={'question': 'FX hakkinda bilgi ver'},
            timeout=30
        )
        
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            answer = data.get('answer', '')
            
            print(f"Answer length: {len(answer)} chars")
            print(f"Answer preview: {answer[:200]}...")
            print(f"Documents Found: {data.get('documents_found', 0)}")
            
            if 'I apologize, but I encountered an error' in answer:
                print("ERROR: Still getting error message")
                return False
            elif len(answer) < 10:
                print("ERROR: Empty response")
                return False
            else:
                print("SUCCESS: FX query working!")
                print("SUCCESS: Context7 server fix complete!")
                return True
        else:
            print(f"HTTP Error: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"Request failed: {e}")
        return False

if __name__ == "__main__":
    success = test_context7_fix()
    if success:
        print("\nContext7 Fix: PASSED")
    else:
        print("\nContext7 Fix: FAILED") 