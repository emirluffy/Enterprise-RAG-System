"""
Test for Gemini API Response Optimization - Context7 Verified
"""

import requests
import json
import time

# Test Configuration
url = "http://localhost:8002/api/v1/chat/query"
headers = {"Content-Type": "application/json"}
data = {
    "question": "fx emirleri nasıl verilir?",
    "conversation_id": "test-optimization-gemini"
}

print("🧪 Testing Gemini API Response Optimization...")
print(f"📞 Sending request to: {url}")
print(f"📝 Question: {data['question']}")

try:
    start_time = time.time()
    response = requests.post(url, headers=headers, json=data, timeout=30)
    end_time = time.time()
    total_time = int((end_time - start_time) * 1000)
    
    print(f"📊 Response time: {total_time}ms")
    print(f"📊 Status Code: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        print("✅ Response received!")
        
        # Check optimization data
        optimization = result.get('response_optimization', {})
        print(f"🤖 Optimization applied: {optimization.get('applied', False)}")
        
        if optimization.get('applied'):
            print(f"📊 Clarity Score: {optimization.get('clarity_score', 'N/A')}/10")
            print(f"⚡ Optimization Score: {optimization.get('optimization_score', 'N/A')}/10")
            print(f"🕒 Optimization Time: {optimization.get('processing_time_ms', 'N/A')}ms")
            print(f"🔄 Duplicates removed: {optimization.get('duplicates_removed', 'N/A')}")
            print(f"✨ Improvements: {optimization.get('improvements_applied', 'N/A')}")
        else:
            print(f"❌ Reason: {optimization.get('reason', 'N/A')}")
            print(f"⚠️ Error: {optimization.get('error', 'N/A')}")
        
        # Print response sections if available
        if 'sections' in result and result['sections']:
            print("\n" + "="*50)
            print("📑 STRUCTURED SECTIONS:")
            print("="*50)
            for section in result['sections']:
                print(f"{section.get('icon', '•')} **{section.get('title')}**")
                print(f"  {section.get('content')[:100]}...")
        
        print("\n" + "="*50)
        print("📝 OPTIMIZED ANSWER:")
        print("="*50)
        print(result.get('answer', 'No answer'))
        
        # Save result for analysis
        with open("test_optimization_result.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print("\n✅ Result saved to test_optimization_result.json")
    else:
        print(f"❌ Error: {response.status_code}")
        print(f"📄 Response: {response.text}")
except Exception as e:
    print(f"❌ Request failed: {e}") 