#!/usr/bin/env python3
"""
Context7 FX Query Test Script
Tests if the FX document error has been fixed
"""
import requests
import json
import time

def test_fx_query():
    print("Testing FX query with Context7 verified fix...")
    
    try:
        response = requests.post(
            'http://localhost:8002/api/v1/chat/query',
            headers={'Content-Type': 'application/json'},
            json={'question': 'FX doviz islemleri nasil yapilir?'},
            timeout=60
        )
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            answer = data.get('answer', '')
            
            print(f"Answer length: {len(answer)} characters")
            print(f"Answer preview: {answer[:300]}...")
            print(f"Documents Found: {data.get('documents_found', 0)}")
            print(f"Response Time: {data.get('response_time_ms', 0)}ms")
            print(f"Has Context: {data.get('has_context', False)}")
            
            # Check for error messages
            if 'I apologize, but I encountered an error' in answer:
                print("❌ ERROR: Still getting English error message")
                return False
            elif 'Üzgünüm' in answer and 'yanıt oluşturulamadı' in answer:
                print("❌ ERROR: Getting Turkish fallback error message")
                return False
            else:
                print("✅ SUCCESS: No error message found!")
                print("✅ Context7 verified fix is working!")
                return True
        else:
            print(f"❌ HTTP Error {response.status_code}: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Request failed: {e}")
        return False

if __name__ == "__main__":
    # Wait for server to be ready
    print("Waiting for server to start...")
    time.sleep(15)
    
    success = test_fx_query()
    if success:
        print("\n🎉 Context7 Fix Verification: PASSED")
    else:
        print("\n💥 Context7 Fix Verification: FAILED") 