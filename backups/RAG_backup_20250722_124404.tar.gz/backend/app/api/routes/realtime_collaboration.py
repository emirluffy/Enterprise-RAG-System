from typing import List, Dict, Optional
from fastapi import APIRouter, HTTPException, Depends, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from datetime import datetime
import logging

from app.services.realtime_collaboration_service import collaboration_service

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models for request/response
class JoinRoomRequest(BaseModel):
    room_id: str = Field(..., description="Unique room identifier")
    user_id: str = Field(..., description="User identifier")
    user_info: Dict = Field(..., description="User information (name, avatar, etc.)")
    room_type: str = Field(default="chat", description="Room type: chat, document, workspace")

class SendMessageRequest(BaseModel):
    room_id: str = Field(..., description="Room identifier")
    user_id: str = Field(..., description="User identifier")
    content: str = Field(..., description="Message content")
    message_type: str = Field(default="text", description="Message type: text, image, file, etc.")
    metadata: Dict = Field(default_factory=dict, description="Additional message metadata")

class TypingStatusRequest(BaseModel):
    room_id: str = Field(..., description="Room identifier")
    user_id: str = Field(..., description="User identifier")
    is_typing: bool = Field(..., description="Typing status")

class RoomStateResponse(BaseModel):
    room_id: str
    room_type: str
    users: Dict
    typing_users: List[str]
    user_count: int
    created_at: str
    last_activity: str

class MessageResponse(BaseModel):
    message_id: str
    room_id: str
    user_id: str
    content: str
    message_type: str
    timestamp: str
    metadata: Dict

@router.post("/rooms/join", response_model=RoomStateResponse)
async def join_collaboration_room(request: JoinRoomRequest):
    """
    Join a real-time collaboration room
    
    Creates room if it doesn't exist, adds user to room, and returns current room state.
    """
    try:
        room_state = await collaboration_service.join_room(
            room_id=request.room_id,
            user_id=request.user_id,
            user_info=request.user_info,
            room_type=request.room_type
        )
        
        return RoomStateResponse(**room_state)
        
    except Exception as e:
        logger.error(f"❌ Error joining room {request.room_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to join room: {str(e)}")

@router.post("/rooms/leave")
async def leave_collaboration_room(room_id: str, user_id: str):
    """
    Leave a real-time collaboration room
    
    Removes user from room and publishes leave event to other participants.
    """
    try:
        await collaboration_service.leave_room(room_id, user_id)
        
        return {"success": True, "message": f"User {user_id} left room {room_id}"}
        
    except Exception as e:
        logger.error(f"❌ Error leaving room {room_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to leave room: {str(e)}")

@router.post("/rooms/message", response_model=MessageResponse)
async def send_room_message(request: SendMessageRequest):
    """
    Send message to collaboration room
    
    Broadcasts message to all room participants via WebSocket PubSub.
    """
    try:
        message_data = await collaboration_service.send_message(
            room_id=request.room_id,
            user_id=request.user_id,
            message={
                'content': request.content,
                'message_type': request.message_type,
                'metadata': request.metadata
            }
        )
        
        return MessageResponse(**message_data)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"❌ Error sending message to room {request.room_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to send message: {str(e)}")

@router.post("/rooms/typing")
async def set_typing_status(request: TypingStatusRequest):
    """
    Set user typing status in room
    
    Updates typing indicators for real-time collaboration experience.
    """
    try:
        await collaboration_service.set_typing_status(
            room_id=request.room_id,
            user_id=request.user_id,
            is_typing=request.is_typing
        )
        
        return {"success": True, "message": f"Typing status updated for user {request.user_id}"}
        
    except Exception as e:
        logger.error(f"❌ Error setting typing status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to set typing status: {str(e)}")

@router.get("/rooms/{room_id}/state", response_model=Optional[RoomStateResponse])
async def get_room_state(room_id: str):
    """
    Get current state of collaboration room
    
    Returns room information, participants, and activity status.
    """
    try:
        room_state = await collaboration_service.get_room_state(room_id)
        
        if not room_state:
            raise HTTPException(status_code=404, detail=f"Room {room_id} not found")
        
        return RoomStateResponse(**room_state)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error getting room state {room_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get room state: {str(e)}")

@router.get("/rooms/active", response_model=List[RoomStateResponse])
async def get_active_rooms():
    """
    Get all active collaboration rooms
    
    Returns list of all rooms with current participants and activity.
    """
    try:
        active_rooms = await collaboration_service.get_active_rooms()
        
        return [RoomStateResponse(**room) for room in active_rooms]
        
    except Exception as e:
        logger.error(f"❌ Error getting active rooms: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get active rooms: {str(e)}")

@router.get("/health")
async def collaboration_health():
    """
    Health check for real-time collaboration service
    """
    try:
        active_rooms = await collaboration_service.get_active_rooms()
        total_users = sum(room['user_count'] for room in active_rooms)
        
        return {
            "status": "healthy",
            "service": "real-time-collaboration",
            "active_rooms": len(active_rooms),
            "total_users": total_users,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Collaboration health check failed: {e}")
        return {
            "status": "unhealthy",
            "service": "real-time-collaboration",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

# WebSocket endpoint is handled by PubSub service setup
# Available at: /ws/collaboration 