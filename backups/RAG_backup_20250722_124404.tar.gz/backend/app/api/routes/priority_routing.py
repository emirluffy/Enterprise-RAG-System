"""
🎯 Priority Routing API Routes - Phase 4.7
Context7 verified endpoints for intelligent query routing

Provides endpoints for:
- Priority calculation
- Routing plan creation
- SLA management
- Escalation handling
"""

from typing import Dict, List, Optional, Any
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import logging

from ...services.priority_routing_service import (
    priority_routing_service, 
    PriorityScore, 
    RoutingPlan,
    PriorityLevel,
    RoutingDecision
)
from ...services.agent_handoff_service import BankingDepartment
from ..deps import SessionDep, get_current_user
from ...models import User

logger = logging.getLogger(__name__)

router = APIRouter(tags=["priority-routing"])

# Request Models
class PriorityCalculationRequest(BaseModel):
    query: str = Field(..., description="Customer query to analyze")
    customer_context: Optional[Dict[str, Any]] = Field(default=None, description="Additional customer context")

class RoutingPlanRequest(BaseModel):
    query: str = Field(..., description="Customer query to route")
    customer_context: Optional[Dict[str, Any]] = Field(default=None, description="Customer context")
    conversation_history: Optional[List[str]] = Field(default=None, description="Previous conversation messages")

class EscalationRequest(BaseModel):
    routing_id: str = Field(..., description="Original routing ID")
    escalation_reason: str = Field(..., description="Reason for escalation")
    current_department: str = Field(..., description="Current handling department")

# Response Models
class PriorityScoreResponse(BaseModel):
    base_score: float
    sentiment_modifier: float
    urgency_modifier: float
    category_modifier: float
    time_modifier: float
    final_score: float
    priority_level: str
    priority_explanation: List[str]

class RoutingPlanResponse(BaseModel):
    routing_id: str
    priority_score: PriorityScoreResponse
    recommended_department: str
    department_name: str
    routing_decision: str
    estimated_response_time: int
    sla_deadline: str
    escalation_path: List[str]
    routing_reasons: List[str]
    confidence: float
    metadata: Dict[str, Any]

class SLAStatusResponse(BaseModel):
    category: str
    priority_level: str
    sla_minutes: int
    estimated_response: int
    sla_status: str  # "within_sla", "approaching_breach", "breached"
    time_remaining: Optional[int]

class EscalationResponse(BaseModel):
    escalation_id: str
    original_routing_id: str
    escalated_to: str
    escalation_reason: str
    new_priority_level: str
    new_sla_deadline: str
    escalation_path: List[str]

@router.post("/calculate-priority", response_model=PriorityScoreResponse)
async def calculate_priority(
    request: PriorityCalculationRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Calculate priority score for a customer query
    """
    try:
        logger.info(f"🎯 Priority calculation request from user {current_user.id}")
        
        # Initialize service if needed
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Calculate priority score
        priority_score = await priority_routing_service.calculate_priority_score(
            request.query,
            context=request.customer_context or {}
        )
        
        # Build explanation
        priority_explanation = []
        if priority_score.sentiment_modifier > 0:
            priority_explanation.append(f"Negatif duygu tespit edildi (+{priority_score.sentiment_modifier:.1f})")
        if priority_score.urgency_modifier > 0:
            priority_explanation.append(f"Aciliyet göstergeleri (+{priority_score.urgency_modifier:.1f})")
        if priority_score.category_modifier > 0:
            priority_explanation.append(f"Yüksek öncelikli kategori (+{priority_score.category_modifier:.1f})")
        if priority_score.time_modifier > 0:
            priority_explanation.append(f"Mesai dışı/hafta sonu (+{priority_score.time_modifier:.1f})")
        
        return PriorityScoreResponse(
            base_score=priority_score.base_score,
            sentiment_modifier=priority_score.sentiment_modifier,
            urgency_modifier=priority_score.urgency_modifier,
            category_modifier=priority_score.category_modifier,
            time_modifier=priority_score.time_modifier,
            final_score=priority_score.final_score,
            priority_level=priority_score.priority_level.value,
            priority_explanation=priority_explanation
        )
        
    except Exception as e:
        logger.error(f"❌ Priority calculation error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Priority calculation failed: {str(e)}"
        )

@router.post("/create-routing-plan", response_model=RoutingPlanResponse)
async def create_routing_plan(
    request: RoutingPlanRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Create comprehensive routing plan for a customer query
    """
    try:
        logger.info(f"🎯 Routing plan request from user {current_user.id}")
        
        # Initialize service if needed
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Create routing plan
        routing_plan = await priority_routing_service.create_routing_plan(
            request.query,
            request.customer_context or {},
            request.conversation_history or []
        )
        
        # Get department info
        department_info = priority_routing_service.handoff_service.department_info
        department_name = department_info[routing_plan.recommended_department]["turkish_name"]
        
        # Convert priority score to response format
        priority_score_response = PriorityScoreResponse(
            base_score=routing_plan.priority_score.base_score,
            sentiment_modifier=routing_plan.priority_score.sentiment_modifier,
            urgency_modifier=routing_plan.priority_score.urgency_modifier,
            category_modifier=routing_plan.priority_score.category_modifier,
            time_modifier=routing_plan.priority_score.time_modifier,
            final_score=routing_plan.priority_score.final_score,
            priority_level=routing_plan.priority_score.priority_level.value,
            priority_explanation=routing_plan.routing_reasons
        )
        
        return RoutingPlanResponse(
            routing_id=routing_plan.routing_id,
            priority_score=priority_score_response,
            recommended_department=routing_plan.recommended_department.value,
            department_name=department_name,
            routing_decision=routing_plan.routing_decision.value,
            estimated_response_time=routing_plan.estimated_response_time,
            sla_deadline=routing_plan.sla_deadline.isoformat(),
            escalation_path=routing_plan.escalation_path,
            routing_reasons=routing_plan.routing_reasons,
            confidence=routing_plan.confidence,
            metadata=routing_plan.metadata
        )
        
    except Exception as e:
        logger.error(f"❌ Routing plan creation error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Routing plan creation failed: {str(e)}"
        )

@router.get("/sla-rules", response_model=Dict[str, Any])
async def get_sla_rules(
    current_user: User = Depends(get_current_user)
):
    """
    Get SLA rules for all banking categories and priority levels
    """
    try:
        logger.info(f"📋 SLA rules request from user {current_user.id}")
        
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Convert SLA rules to JSON-serializable format
        sla_rules_formatted = {}
        for category, rules in priority_routing_service.sla_rules.items():
            sla_rules_formatted[category] = {}
            for priority_level, minutes in rules.items():
                sla_rules_formatted[category][priority_level.value] = {
                    "minutes": minutes,
                    "hours": round(minutes / 60, 1),
                    "display": f"{minutes // 60}h {minutes % 60}m" if minutes >= 60 else f"{minutes}m"
                }
        
        return {
            "sla_rules": sla_rules_formatted,
            "categories": list(sla_rules_formatted.keys()),
            "priority_levels": [level.value for level in PriorityLevel],
            "last_updated": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ SLA rules retrieval error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"SLA rules retrieval failed: {str(e)}"
        )

@router.post("/check-sla-status", response_model=SLAStatusResponse)
async def check_sla_status(
    request: PriorityCalculationRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Check SLA status for a query against defined rules
    """
    try:
        logger.info(f"⏰ SLA status check from user {current_user.id}")
        
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Get sentiment and category analysis
        sentiment_result = await priority_routing_service.sentiment_service.analyze_sentiment(
            request.query, request.customer_context or {}
        )
        category_result = await priority_routing_service.sentiment_service.categorize_query(
            request.query, sentiment_result
        )
        
        # Calculate priority
        priority_score = await priority_routing_service.calculate_priority_score(
            request.query, sentiment_result, request.customer_context or {}
        )
        
        # Get SLA time
        sla_minutes = priority_routing_service._calculate_response_time(
            category_result.primary_category,
            priority_score.priority_level
        )
        
        # Calculate status
        estimated_response = priority_score.final_score  # Simplified for demo
        time_remaining = max(0, sla_minutes - int(estimated_response))
        
        if estimated_response <= sla_minutes * 0.7:
            sla_status = "within_sla"
        elif estimated_response <= sla_minutes:
            sla_status = "approaching_breach"
        else:
            sla_status = "breached"
        
        return SLAStatusResponse(
            category=category_result.primary_category,
            priority_level=priority_score.priority_level.value,
            sla_minutes=sla_minutes,
            estimated_response=int(estimated_response),
            sla_status=sla_status,
            time_remaining=time_remaining if sla_status != "breached" else None
        )
        
    except Exception as e:
        logger.error(f"❌ SLA status check error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"SLA status check failed: {str(e)}"
        )

@router.post("/escalate", response_model=EscalationResponse)
async def escalate_query(
    request: EscalationRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Escalate a query to higher priority/department
    """
    try:
        logger.info(f"⬆️ Escalation request from user {current_user.id}")
        
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Get escalation path for current department
        try:
            current_dept = BankingDepartment(request.current_department)
            escalation_path = priority_routing_service.escalation_paths.get(current_dept, [])
        except ValueError:
            escalation_path = ["senior_analyst", "manager", "executive"]
        
        # Determine escalated priority
        escalated_to = escalation_path[0] if escalation_path else "manager"
        new_priority_level = PriorityLevel.HIGH.value  # Escalated queries get high priority
        
        # Calculate new SLA deadline (faster response)
        new_sla_minutes = 60  # 1 hour for escalated queries
        new_sla_deadline = datetime.now() + timedelta(minutes=new_sla_minutes)
        
        escalation_id = f"ESC-{request.routing_id[:8]}-{datetime.now().strftime('%H%M%S')}"
        
        return EscalationResponse(
            escalation_id=escalation_id,
            original_routing_id=request.routing_id,
            escalated_to=escalated_to,
            escalation_reason=request.escalation_reason,
            new_priority_level=new_priority_level,
            new_sla_deadline=new_sla_deadline.isoformat(),
            escalation_path=escalation_path
        )
        
    except Exception as e:
        logger.error(f"❌ Escalation error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Escalation failed: {str(e)}"
        )

@router.get("/statistics", response_model=Dict[str, Any])
async def get_routing_statistics(
    current_user: User = Depends(get_current_user)
):
    """
    Get priority routing service statistics and configuration
    """
    try:
        logger.info(f"📊 Routing statistics request from user {current_user.id}")
        
        if not priority_routing_service.is_initialized:
            await priority_routing_service.initialize()
        
        # Get service statistics
        stats = await priority_routing_service.get_routing_statistics()
        
        # Add additional runtime info
        stats.update({
            "current_time": datetime.now().isoformat(),
            "business_hours": {
                "start": "09:00",
                "end": "17:00", 
                "timezone": "Turkey/Istanbul"
            },
            "escalation_triggers": {
                "critical_priority": "Immediate escalation",
                "high_priority": "30 min response time",
                "customer_complaint": "Priority queue",
                "security_issue": "Immediate risk management"
            }
        })
        
        return stats
        
    except Exception as e:
        logger.error(f"❌ Statistics retrieval error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Statistics retrieval failed: {str(e)}"
        )

@router.get("/health")
async def priority_routing_health():
    """Health check for priority routing service"""
    try:
        is_healthy = priority_routing_service.is_initialized
        
        return {
            "status": "healthy" if is_healthy else "initializing",
            "service": "Priority Routing Service",
            "version": "1.0.0",
            "features": [
                "Sentiment-based priority calculation",
                "SLA rules management", 
                "Escalation engine",
                "Department routing",
                "Turkish banking specialization"
            ],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        } 