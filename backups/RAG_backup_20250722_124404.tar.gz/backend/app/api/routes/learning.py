"""
Dynamic Learning Routes for RAG System
Allows users to teach the system new information through chat
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
import re

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlmodel import Session, select, func
from pydantic import BaseModel, Field

from app.core.db import get_session
from app.models import LearnedKnowledge, User, QueryLog
from app.services.embeddings import EmbeddingsService
from app.services.vector_store import VectorStoreService
from app.api.deps import get_db
from app.services.hybrid_rag_service import HybridRAGService

router = APIRouter()

# Global embeddings service instance
embeddings_service = EmbeddingsService()

# Pydantic Models for Request/Response
class LearnRequest(BaseModel):
    """Request to learn new information"""
    content: str = Field(description="Content to learn")
    title: Optional[str] = Field(None, description="Title for the knowledge")
    knowledge_type: str = Field(default="instruction", description="Type: duyuru, instruction, qa, regulation")
    priority: str = Field(default="normal", description="Priority: low, normal, high, critical")
    summary: Optional[str] = Field(None, description="Optional summary")
    keywords: Optional[List[str]] = Field(None, description="Optional keywords")
    department: Optional[str] = Field(None, description="Department context")
    expires_at: Optional[datetime] = Field(None, description="Expiration date")
    source: Optional[str] = Field(None, description="Source of the knowledge")

class LearnResponse(BaseModel):
    """Response after learning"""
    success: bool
    learned_knowledge_id: str
    message: str
    confidence_score: float
    knowledge_integrated: bool

class KnowledgeListResponse(BaseModel):
    """Response for knowledge listing"""
    knowledge: List[Dict[str, Any]]
    total: int
    page: int
    size: int

class EnhancedContentProcessor:
    """Context7-verified enhanced content processor for detailed procedures"""
    
    def __init__(self):
        self.procedure_patterns = [
            r'(?:müşterimlere|müşterilerimizde|müşterinin|müşteriye)',  # Customer references
            r'(?:öncelikle|sonrasında|eğer|ardından)',  # Procedure steps
            r'(?:kontrol\s+ed[ei]\w*|güncelle\w*|transfer\s+ed[ei]\w*)',  # Actions
            r'(?:IVR|MBS|OTP|N\s*Kolay)',  # Technical terms
            r'(?:telefon|numara|iletişim)',  # Contact info
            r'(?:kayıt|açma|tuşla\w*)',  # Administrative actions
        ]
        
        self.section_indicators = [
            r'^\d+\.',  # Numbered steps
            r'^[A-ZÇĞIİÖŞÜ]',  # Capital letter starts
            r'^\s*[-•]',  # Bullet points
            r'(?:Eğer|Konu|Müşterimlere)',  # Conditional/topic starters
        ]
    
    def extract_detailed_knowledge(self, content: str) -> List[Dict[str, Any]]:
        """Extract multiple knowledge pieces from detailed content"""
        knowledge_items = []
        
        # Split content into meaningful sections
        sections = self._split_into_sections(content)
        
        for i, section in enumerate(sections):
            if self._is_meaningful_section(section):
                knowledge_item = {
                    'content': section.strip(),
                    'section_order': i + 1,
                    'confidence': self._calculate_confidence(section),
                    'knowledge_type': self._classify_knowledge_type(section),
                    'keywords': self._extract_keywords(section)
                }
                knowledge_items.append(knowledge_item)
        
        # Also create a comprehensive summary
        if len(knowledge_items) > 1:
            summary = self._create_comprehensive_summary(content, knowledge_items)
            knowledge_items.insert(0, {
                'content': summary,
                'section_order': 0,
                'confidence': 0.95,
                'knowledge_type': 'prosedür_özeti',
                'keywords': self._extract_keywords(content)
            })
        
        return knowledge_items
    
    def _split_into_sections(self, content: str) -> List[str]:
        """Split content into logical sections"""
        # Try different splitting strategies
        sections = []
        
        # Strategy 1: Split by sentences with procedure indicators
        sentences = re.split(r'[.!?]\s+', content)
        current_section = ""
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
                
            # Check if this starts a new procedure step
            if any(re.search(pattern, sentence, re.IGNORECASE) for pattern in self.section_indicators):
                if current_section:
                    sections.append(current_section.strip())
                current_section = sentence
            else:
                current_section += ". " + sentence if current_section else sentence
        
        if current_section:
            sections.append(current_section.strip())
        
        # Strategy 2: If no clear sections found, split by key transition words
        if len(sections) <= 1:
            sections = re.split(r'(?:Eğer|Konu|Müşterimlere|Öncelikle)', content)
            sections = [s.strip() for s in sections if s.strip()]
        
        return sections
    
    def _is_meaningful_section(self, section: str) -> bool:
        """Check if section contains meaningful procedural information"""
        if len(section) < 20:  # Too short
            return False
            
        # Must contain procedure-related terms
        procedure_indicators = any(
            re.search(pattern, section, re.IGNORECASE) 
            for pattern in self.procedure_patterns
        )
        
        return procedure_indicators
    
    def _calculate_confidence(self, section: str) -> float:
        """Calculate confidence score for the section"""
        base_confidence = 0.7
        
        # Boost confidence for specific indicators
        if re.search(r'müşterimlere.*iletelim', section, re.IGNORECASE):
            base_confidence += 0.1
        if re.search(r'kontrol\s+edelim', section, re.IGNORECASE):
            base_confidence += 0.1
        if re.search(r'transfer\s+edelim', section, re.IGNORECASE):
            base_confidence += 0.1
        if re.search(r'(?:IVR|MBS|OTP)', section):
            base_confidence += 0.05
            
        return min(base_confidence, 0.95)
    
    def _classify_knowledge_type(self, section: str) -> str:
        """Classify the type of knowledge"""
        section_lower = section.lower()
        
        if 'kontrol' in section_lower and ('telefon' in section_lower or 'iletişim' in section_lower):
            return 'telefon_kontrol_prosedürü'
        elif 'ivr' in section_lower and 'transfer' in section_lower:
            return 'ivr_transfer_prosedürü'
        elif 'mbs' in section_lower and 'kayıt' in section_lower:
            return 'mbs_kayıt_kuralı'
        elif 'otp' in section_lower and ('ulaşmad' in section_lower or 'gelmed' in section_lower):
            return 'otp_sorun_çözümü'
        elif 'müşterimlere' in section_lower and 'iletelim' in section_lower:
            return 'müşteri_bilgilendirme'
        else:
            return 'genel_prosedür'
    
    def _extract_keywords(self, content: str) -> List[str]:
        """Extract relevant keywords from content"""
        # Technical terms
        tech_terms = re.findall(r'\b(?:IVR|MBS|OTP|N\s*Kolay|İnternet\s*[Bb]ankacılığı)\b', content, re.IGNORECASE)
        
        # Action words
        actions = re.findall(r'\b(?:kontrol|güncelle|transfer|kayıt|tuşla|işaretle)\w*', content, re.IGNORECASE)
        
        # Process terms
        processes = re.findall(r'\b(?:telefon|numara|iletişim|şifre|yenile)\w*', content, re.IGNORECASE)
        
        keywords = list(set(tech_terms + actions + processes))
        return [kw.lower() for kw in keywords if len(kw) > 2]
    
    def _create_comprehensive_summary(self, original_content: str, knowledge_items: List[Dict]) -> str:
        """Create a comprehensive summary of the procedure"""
        summary_parts = []
        
        # Extract main topic
        if 'otp' in original_content.lower() and 'ulaşmad' in original_content.lower():
            summary_parts.append("İnternet bankacılığı şifre yenileme sonrası OTP ulaşmama problemi prosedürü:")
        
        # Add key steps
        for item in knowledge_items:
            if item['knowledge_type'] in ['telefon_kontrol_prosedürü', 'ivr_transfer_prosedürü', 'mbs_kayıt_kuralı']:
                summary_parts.append(f"• {item['content'][:100]}...")
        
        return " ".join(summary_parts)

# Background task for processing learned content
async def process_learned_content_background(
    content: str,
    user_id: int,
    source: str,
    db: Session
):
    """Background task to process and store learned content using Context7-verified patterns"""
    try:
        processor = EnhancedContentProcessor()
        embeddings_service = EmbeddingsService()
        
        # Extract detailed knowledge
        knowledge_items = processor.extract_detailed_knowledge(content)
        
        for item in knowledge_items:
            # Generate embeddings
            embeddings = await embeddings_service.create_embeddings([item['content']])
            embedding_dict = {"vector": embeddings[0]} if embeddings else {}
            
            # Auto-generate title from content
            title = item['content'][:100] + "..." if len(item['content']) > 100 else item['content']
            
            # Create learned knowledge entry with proper parameters
            learned_knowledge = LearnedKnowledge(
                id=str(uuid.uuid4()),
                content=item['content'],
                knowledge_type=item['knowledge_type'],
                title=title,
                summary=item['content'][:200] + "..." if len(item['content']) > 200 else item['content'],
                keywords=item['keywords'],
                priority="normal",
                language="tr",
                source_type=source,
                source_reference=None,
                learned_from_query=None,
                embedding=embedding_dict,
                embedding_model="multilingual-e5-large",
                is_verified=False,
                verified_by=None,
                verified_at=None,
                confidence_score=item['confidence'],
                access_count=0,
                usefulness_score=None,
                last_accessed=None,
                status="active",
                superseded_by=None,
                expires_at=None,
                created_by=str(user_id) if user_id else None,
                session_id=None,
                department="Genel",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            db.add(learned_knowledge)
        
        db.commit()
        
    except Exception as e:
        db.rollback()
        print(f"Background processing error: {str(e)}")

@router.post("/learn", response_model=LearnResponse)
async def enhanced_learn_endpoint(
    request: LearnRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user_id: int = 1  # TODO: Get from auth
):
    """
    Enhanced learning endpoint that can handle complex procedures and detailed content
    Uses Context7-verified background tasks and content processing patterns
    """
    try:
        # Validate input
        if not request.content or len(request.content.strip()) < 10:
            raise HTTPException(status_code=400, detail="İçerik çok kısa veya boş")
        
        # Process content immediately for quick response
        processor = EnhancedContentProcessor()
        knowledge_items = processor.extract_detailed_knowledge(request.content)
        
        if not knowledge_items:
            raise HTTPException(status_code=400, detail="İçerikte öğrenilebilir bilgi bulunamadı")
        
        # Take the primary knowledge item for immediate response
        primary_knowledge = knowledge_items[0]
        knowledge_id = str(uuid.uuid4())
        
        # Determine source type with proper handling
        source_type = "manuel_öğrenme"
        if hasattr(request, 'source_type') and request.source_type:
            source_type = request.source_type
        
        # Add comprehensive background processing task
        background_tasks.add_task(
            process_learned_content_background,
            request.content,
            current_user_id,
            source_type,
            db
        )
        
        return LearnResponse(
            success=True,
            message=f"✅ **Detaylı prosedür başarıyla öğrenildi!**\n\n"
                   f"📝 **Öğrenilen:** {primary_knowledge['content'][:100]}...\n\n"
                   f"🆔 **ID:** {knowledge_id}\n\n"
                   f"📊 **Toplam bölüm:** {len(knowledge_items)}\n"
                   f"🎯 **Tür:** {primary_knowledge['knowledge_type']}\n"
                   f"💯 **Güven skoru:** {primary_knowledge['confidence']:.1%}\n\n"
                   f"Bu detaylı prosedür artık gelecekteki sorularınızda kullanılacak. "
                   f"Tüm bölümler arka planda işleniyor ve vektör veritabanına kaydediliyor.",
            learned_knowledge_id=knowledge_id,
            confidence_score=primary_knowledge['confidence'],
            knowledge_integrated=False
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Öğrenme hatası: {str(e)}")

@router.get("/knowledge", response_model=KnowledgeListResponse)
async def list_knowledge(
    page: int = 1,
    size: int = 20,
    knowledge_type: Optional[str] = None,
    status: str = "active",
    department: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """List learned knowledge with filtering"""
    
    # Build query
    query = select(LearnedKnowledge).where(LearnedKnowledge.status == status)
    
    if knowledge_type:
        query = query.where(LearnedKnowledge.knowledge_type == knowledge_type)
    if department:
        query = query.where(LearnedKnowledge.department == department)
    
    # Pagination
    offset = (page - 1) * size
    results = session.exec(query.offset(offset).limit(size)).all()
    
    # Convert to dict
    knowledge_list = []
    for k in results:
        knowledge_list.append({
            "id": k.id,
            "title": k.title,
            "content": k.content[:200] + "..." if len(k.content) > 200 else k.content,
            "knowledge_type": k.knowledge_type,
            "priority": k.priority,
            "is_verified": k.is_verified,
            "access_count": k.access_count,
            "created_at": k.created_at,
            "department": k.department
        })
    
    # Total count
    count_query = select(func.count()).select_from(LearnedKnowledge).where(LearnedKnowledge.status == status)
    if knowledge_type:
        count_query = count_query.where(LearnedKnowledge.knowledge_type == knowledge_type)
    if department:
        count_query = count_query.where(LearnedKnowledge.department == department)
    
    total = session.exec(count_query).one()
    
    return KnowledgeListResponse(
        knowledge=knowledge_list,
        total=total,
        page=page,
        size=size
    )

@router.delete("/knowledge/{knowledge_id}")
async def delete_knowledge(
    knowledge_id: str,
    session: Session = Depends(get_session),
    # current_user: User = Depends(get_current_active_superuser)  # Enable when auth ready
):
    """Delete learned knowledge"""
    
    knowledge = session.get(LearnedKnowledge, knowledge_id)
    if not knowledge:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    
    # Soft delete
    knowledge.status = "deleted"
    knowledge.updated_at = datetime.utcnow()
    
    session.add(knowledge)
    session.commit()
    
    return {"message": "Knowledge deleted successfully"}

@router.post("/knowledge/{knowledge_id}/verify")
async def verify_knowledge(
    knowledge_id: str,
    session: Session = Depends(get_session),
    # current_user: User = Depends(get_current_active_user)  # Enable when auth ready
):
    """Verify learned knowledge as accurate"""
    
    knowledge = session.get(LearnedKnowledge, knowledge_id)
    if not knowledge:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    
    knowledge.is_verified = True
    knowledge.verified_at = datetime.utcnow()
    # knowledge.verified_by = current_user.id  # Enable when auth ready
    knowledge.updated_at = datetime.utcnow()
    
    session.add(knowledge)
    session.commit()
    
    return {"message": "Knowledge verified successfully"}

@router.get("/knowledge/{knowledge_id}/status")
async def get_knowledge_status(
    knowledge_id: str,
    db: Session = Depends(get_db)
):
    """Check the processing status of learned knowledge"""
    knowledge = db.query(LearnedKnowledge).filter(LearnedKnowledge.id == knowledge_id).first()
    
    if not knowledge:
        raise HTTPException(status_code=404, detail="Bilgi bulunamadı")
    
    return {
        "id": knowledge.id,
        "status": "processed" if knowledge.embedding else "processing",
        "content_preview": knowledge.content[:200] + "..." if len(knowledge.content) > 200 else knowledge.content,
        "knowledge_type": knowledge.knowledge_type,
        "confidence_score": knowledge.confidence_score,
        "access_count": knowledge.access_count,
        "is_verified": knowledge.is_verified
    }

@router.get("/knowledge/search")
async def search_learned_knowledge(
    query: str,
    knowledge_type: Optional[str] = None,
    department: Optional[str] = None,
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """Search through learned knowledge using Context7-verified patterns"""
    try:
        # Build query
        db_query = db.query(LearnedKnowledge)
        
        if knowledge_type:
            db_query = db_query.filter(LearnedKnowledge.knowledge_type == knowledge_type)
        
        if department:
            db_query = db_query.filter(LearnedKnowledge.department == department)
        
        # Text search in content
        if query:
            db_query = db_query.filter(LearnedKnowledge.content.like(f"%{query}%"))
        
        results = db_query.order_by(LearnedKnowledge.confidence_score.desc()).limit(limit).all()
        
        return {
            "results": [
                {
                    "id": r.id,
                    "content_preview": r.content[:200] + "..." if len(r.content) > 200 else r.content,
                    "knowledge_type": r.knowledge_type,
                    "confidence_score": r.confidence_score,
                    "access_count": r.access_count,
                    "created_at": r.created_at
                }
                for r in results
            ],
            "total": len(results)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Arama hatası: {str(e)}") 