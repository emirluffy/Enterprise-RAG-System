"""
🤝 Agent Handoff API Routes
Context7 verified endpoints for Turkish Banking Multi-Agent System

Provides REST API endpoints for:
- Agent handoffs between departments
- Department suggestions
- Handoff history tracking
- Agent capabilities management
"""

from typing import Dict, List, Any, Optional
from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, Field
import logging

from ...services.agent_handoff_service import (
    agent_handoff_service,
    BankingDepartment,
    HandoffReason,
    BankingAgentState
)
from ...api.deps import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Agent Handoff"])

# ✅ Context7 Verified: Pydantic Models for API
class HandoffRequest(BaseModel):
    """Handoff talebi"""
    from_department: str = Field(..., description="Kaynak departman")
    to_department: str = Field(..., description="Hedef departman")
    reason: str = Field(..., description="Handoff sebebi")
    context: Optional[str] = Field(None, description="Transfer için gerekli bilgiler")
    customer_query: Optional[str] = Field(None, description="Müşteri sorgusu")

class HandoffResponse(BaseModel):
    """Handoff cevabı"""
    success: bool
    message: str
    handoff_id: Optional[str] = None
    from_department: str
    to_department: str
    reason: str
    timestamp: str

class DepartmentSuggestionRequest(BaseModel):
    """Departman önerisi talebi"""
    query: str = Field(..., description="Müşteri sorgusu")
    current_department: Optional[str] = Field(None, description="Mevcut departman")

class DepartmentSuggestionResponse(BaseModel):
    """Departman önerisi cevabı"""
    suggested_department: Optional[str]
    confidence_score: int
    reason: str
    alternatives: List[Dict[str, Any]]

class DepartmentCapabilitiesResponse(BaseModel):
    """Departman yetenekleri"""
    department: str
    name: str
    turkish_name: str
    description: str
    expertise_areas: List[str]
    available_handoffs: List[str]

class HandoffHistoryResponse(BaseModel):
    """Handoff geçmişi"""
    total_handoffs: int
    departments_involved: List[str]
    handoff_chain: List[str]
    recent_handoffs: List[Dict[str, Any]]

# ✅ Context7 Verified: Agent Handoff Endpoints

@router.post("/handoff", response_model=HandoffResponse)
async def create_handoff(
    request: HandoffRequest,
    current_user: Dict = Depends(get_current_user)
):
    """
    🔄 Departmanlar arası agent handoff gerçekleştir
    
    Turkish Banking departmanları arasında akıllı transfer:
    - Credits (Krediler)
    - Operations (Operasyonlar)
    - Customer Service (Müşteri Hizmetleri)
    - Compliance (Uyumluluk)
    - Risk Management (Risk Yönetimi)
    """
    try:
        # Handoff validasyonu
        validation = agent_handoff_service.validate_handoff(
            from_dept=request.from_department,
            to_dept=request.to_department,
            reason=request.reason
        )
        
        if not validation["valid"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": validation["error"],
                    "error_code": validation["error_code"]
                }
            )
        
        # Handoff oluştur
        from datetime import datetime
        handoff_id = f"handoff_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        response = HandoffResponse(
            success=True,
            message=f"✅ {request.from_department} → {request.to_department} handoff başarılı",
            handoff_id=handoff_id,
            from_department=request.from_department,
            to_department=request.to_department,
            reason=request.reason,
            timestamp=datetime.now().isoformat()
        )
        
        logger.info(f"🤝 Handoff created: {request.from_department} → {request.to_department}")
        return response
        
    except Exception as e:
        logger.error(f"❌ Handoff error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Handoff işlemi başarısız: {str(e)}"
        )

@router.post("/suggest-department", response_model=DepartmentSuggestionResponse)
async def suggest_department(
    request: DepartmentSuggestionRequest,
    current_user: Dict = Depends(get_current_user)
):
    """
    🎯 Akıllı departman önerisi
    
    Müşteri sorgusuna göre en uygun departmanı öneren AI system:
    - Query analizi ile keyword matching
    - Banking domain expertise
    - Confidence scoring
    """
    try:
        suggestion = agent_handoff_service.suggest_handoff_department(
            query=request.query,
            current_department=request.current_department or "customer_service"
        )
        
        # Confidence açıklaması
        confidence_explanations = {
            0: "Departman önerisi yok - genel müşteri hizmetleri",
            1: "Düşük güven - birkaç keyword match",
            2: "Orta güven - açık keyword match",
            3: "Yüksek güven - departman adı + keyword match",
            4: "Çok yüksek güven - multiple keyword match"
        }
        
        confidence_score = suggestion["confidence_score"]
        reason = confidence_explanations.get(confidence_score, "Belirsiz güven seviyesi")
        
        # Alternatif departmanlar
        alternatives = []
        for dept, score in suggestion["all_scores"].items():
            if dept != suggestion["suggested_department"] and score > 0:
                dept_info = agent_handoff_service.department_info.get(
                    BankingDepartment(dept), {}
                )
                alternatives.append({
                    "department": dept,
                    "name": dept_info.get("turkish_name", dept),
                    "score": score,
                    "description": dept_info.get("description", "")
                })
        
        # Score'a göre sırala
        alternatives.sort(key=lambda x: x["score"], reverse=True)
        
        response = DepartmentSuggestionResponse(
            suggested_department=suggestion["suggested_department"],
            confidence_score=confidence_score,
            reason=reason,
            alternatives=alternatives[:3]  # Top 3 alternatif
        )
        
        logger.info(f"🎯 Department suggested: {suggestion['suggested_department']} (confidence: {confidence_score})")
        return response
        
    except Exception as e:
        logger.error(f"❌ Department suggestion error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Departman önerisi başarısız: {str(e)}"
        )

@router.get("/departments", response_model=List[DepartmentCapabilitiesResponse])
async def get_all_departments(
    current_user: Dict = Depends(get_current_user)
):
    """
    📋 Tüm banking departmanları ve yetenekleri
    
    Turkish Banking sistemindeki tüm departmanların:
    - Uzmanlık alanları
    - Açıklamaları  
    - Transfer seçenekleri
    """
    try:
        departments = []
        
        for department in BankingDepartment:
            capabilities = agent_handoff_service.get_department_capabilities(department)
            
            dept_response = DepartmentCapabilitiesResponse(
                department=capabilities["department"],
                name=capabilities["name"],
                turkish_name=capabilities["turkish_name"],
                description=capabilities["description"],
                expertise_areas=capabilities["expertise_areas"],
                available_handoffs=capabilities["available_handoffs"]
            )
            departments.append(dept_response)
        
        logger.info(f"📋 Retrieved {len(departments)} department capabilities")
        return departments
        
    except Exception as e:
        logger.error(f"❌ Department capabilities error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Departman bilgileri alınamadı: {str(e)}"
        )

@router.get("/departments/{department_name}", response_model=DepartmentCapabilitiesResponse)
async def get_department_capabilities(
    department_name: str,
    current_user: Dict = Depends(get_current_user)
):
    """
    🏢 Spesifik departman yetenekleri
    
    Belirli bir departmanın detaylı bilgileri:
    - Uzmanlık alanları
    - Transfer seçenekleri
    - Departman açıklaması
    """
    try:
        # Departman validation
        try:
            department = BankingDepartment(department_name)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Departman bulunamadı: {department_name}"
            )
        
        capabilities = agent_handoff_service.get_department_capabilities(department)
        
        response = DepartmentCapabilitiesResponse(
            department=capabilities["department"],
            name=capabilities["name"],
            turkish_name=capabilities["turkish_name"],
            description=capabilities["description"],
            expertise_areas=capabilities["expertise_areas"],
            available_handoffs=capabilities["available_handoffs"]
        )
        
        logger.info(f"🏢 Department capabilities retrieved: {department_name}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Department capabilities error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Departman bilgileri alınamadı: {str(e)}"
        )

@router.get("/history/{conversation_id}", response_model=HandoffHistoryResponse)
async def get_handoff_history(
    conversation_id: str,
    current_user: Dict = Depends(get_current_user)
):
    """
    📊 Conversation handoff geçmişi
    
    Belirli bir conversation'daki:
    - Toplam handoff sayısı
    - İlgili departmanlar
    - Handoff zinciri
    - Son handoff'lar
    """
    try:
        # Gerçek implementasyonda database'den gelecek
        history = agent_handoff_service.get_handoff_history(conversation_id)
        
        # Filter None values and convert to strings
        from_agents = [h.get("from_agent") for h in history if h.get("from_agent")]
        to_agents = [h.get("to_agent") for h in history if h.get("to_agent")]
        departments = list(set(from_agents + to_agents))
        handoff_chain = [h.get("to_agent") for h in history if h.get("to_agent")]
        
        response = HandoffHistoryResponse(
            total_handoffs=len(history),
            departments_involved=departments,
            handoff_chain=handoff_chain,
            recent_handoffs=history[-5:] if history else []  # Son 5 handoff
        )
        
        logger.info(f"📊 Handoff history retrieved: {conversation_id} ({len(history)} handoffs)")
        return response
        
    except Exception as e:
        logger.error(f"❌ Handoff history error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Handoff geçmişi alınamadı: {str(e)}"
        )

@router.get("/validate/{from_dept}/{to_dept}/{reason}")
async def validate_handoff_endpoint(
    from_dept: str,
    to_dept: str,
    reason: str,
    current_user: Dict = Depends(get_current_user)
):
    """
    ✅ Handoff validasyonu
    
    Handoff işleminin geçerliliğini kontrol eder:
    - Departman geçerliliği
    - Sebep kontrolü
    - Transfer kuralları
    """
    try:
        validation = agent_handoff_service.validate_handoff(
            from_dept=from_dept,
            to_dept=to_dept,
            reason=reason
        )
        
        logger.info(f"✅ Handoff validation: {from_dept} → {to_dept} = {validation['valid']}")
        return validation
        
    except Exception as e:
        logger.error(f"❌ Handoff validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Handoff validasyonu başarısız: {str(e)}"
        )

@router.get("/reasons", response_model=List[Dict[str, str]])
async def get_handoff_reasons(
    current_user: Dict = Depends(get_current_user)
):
    """
    📝 Handoff sebepleri listesi
    
    Kullanılabilir handoff sebeplerinin listesi:
    - expertise_required
    - authorization_needed
    - escalation
    - specialized_task
    - customer_request
    - routine_transfer
    """
    try:
        reasons = []
        
        reason_descriptions = {
            HandoffReason.EXPERTISE_REQUIRED: "Uzmanlık gerekli",
            HandoffReason.AUTHORIZATION_NEEDED: "Yetki gerekli", 
            HandoffReason.ESCALATION: "Yükseltme",
            HandoffReason.SPECIALIZED_TASK: "Özel görev",
            HandoffReason.CUSTOMER_REQUEST: "Müşteri talebi",
            HandoffReason.ROUTINE_TRANSFER: "Rutin transfer"
        }
        
        for reason in HandoffReason:
            reasons.append({
                "code": reason.value,
                "description": reason_descriptions[reason],
                "turkish_name": reason_descriptions[reason]
            })
        
        logger.info(f"📝 Retrieved {len(reasons)} handoff reasons")
        return reasons
        
    except Exception as e:
        logger.error(f"❌ Handoff reasons error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Handoff sebepleri alınamadı: {str(e)}"
        ) 