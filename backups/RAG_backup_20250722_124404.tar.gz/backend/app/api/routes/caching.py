from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import logging

from app.services.caching_service import caching_service, CacheStats
from app.api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models for request/response
class CacheInvalidationRequest(BaseModel):
    pattern: str
    reason: Optional[str] = None

class CacheWarmupRequest(BaseModel):
    queries: List[str]

class CacheConfigRequest(BaseModel):
    enabled: bool
    default_ttl: Optional[int] = None
    max_cache_size: Optional[int] = None

@router.get("/stats", response_model=CacheStats)
async def get_cache_statistics():
    """
    Get comprehensive cache statistics
    
    Returns cache performance metrics, hit ratios, and usage statistics
    """
    try:
        stats = await caching_service.get_cache_stats()
        return stats
    except Exception as e:
        logger.error(f"❌ Error getting cache stats: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving cache statistics: {str(e)}")

@router.get("/health")
async def cache_health_check():
    """
    Check caching service health
    
    Returns the current status of the caching system
    """
    try:
        if not caching_service.cache_enabled:
            return {
                "status": "disabled",
                "message": "Caching service is disabled",
                "redis_connection": False
            }
        
        # Test Redis connection
        if caching_service.redis_client:
            await caching_service.redis_client.ping()
            redis_connected = True
        else:
            redis_connected = False
        
        return {
            "status": "healthy" if redis_connected else "unhealthy",
            "message": "Caching service is operational" if redis_connected else "Redis connection failed",
            "redis_connection": redis_connected,
            "cache_enabled": caching_service.cache_enabled,
            "default_ttl": caching_service.default_ttl,
            "max_cache_size": caching_service.max_cache_size
        }
        
    except Exception as e:
        logger.error(f"❌ Cache health check failed: {e}")
        return {
            "status": "error",
            "message": f"Health check failed: {str(e)}",
            "redis_connection": False
        }

@router.post("/invalidate")
async def invalidate_cache(
    request: CacheInvalidationRequest,
    current_user=Depends(get_current_user)
):
    """
    Invalidate cache entries by pattern
    
    Supports patterns like:
    - query:hash123 - Invalidate specific query
    - key:mykey - Invalidate specific key
    - tag:banking - Invalidate all entries with tag
    """
    try:
        await caching_service.invalidate_cache(request.pattern)
        
        logger.info(f"🗑️ Cache invalidated by user {current_user.get('email', 'unknown')}: {request.pattern}")
        
        return {
            "success": True,
            "message": f"Cache invalidated for pattern: {request.pattern}",
            "pattern": request.pattern,
            "reason": request.reason
        }
        
    except Exception as e:
        logger.error(f"❌ Error invalidating cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error invalidating cache: {str(e)}")

@router.post("/cleanup")
async def cleanup_expired_cache(current_user=Depends(get_current_user)):
    """
    Clean up expired cache entries
    
    Removes all entries that have passed their expiration time
    """
    try:
        await caching_service.cleanup_expired_entries()
        
        logger.info(f"🧹 Cache cleanup initiated by user {current_user.get('email', 'unknown')}")
        
        return {
            "success": True,
            "message": "Expired cache entries cleaned up successfully"
        }
        
    except Exception as e:
        logger.error(f"❌ Error cleaning up cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error cleaning up cache: {str(e)}")

@router.post("/warmup")
async def warmup_cache(
    request: CacheWarmupRequest,
    current_user=Depends(get_current_user)
):
    """
    Pre-warm cache with common queries
    
    Executes a list of queries to populate the cache for better performance
    """
    try:
        await caching_service.warm_cache(request.queries)
        
        logger.info(f"🔥 Cache warmup initiated by user {current_user.get('email', 'unknown')} with {len(request.queries)} queries")
        
        return {
            "success": True,
            "message": f"Cache warmup initiated with {len(request.queries)} queries",
            "queries_count": len(request.queries)
        }
        
    except Exception as e:
        logger.error(f"❌ Error warming up cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error warming up cache: {str(e)}")

@router.get("/config")
async def get_cache_config():
    """
    Get current cache configuration
    
    Returns the current caching system settings
    """
    return {
        "enabled": caching_service.cache_enabled,
        "default_ttl": caching_service.default_ttl,
        "max_cache_size": caching_service.max_cache_size,
        "redis_url": "configured" if caching_service.redis_client else "not configured"
    }

@router.post("/config")
async def update_cache_config(
    request: CacheConfigRequest,
    current_user=Depends(get_current_user)
):
    """
    Update cache configuration
    
    Allows runtime modification of cache settings
    """
    try:
        old_config = {
            "enabled": caching_service.cache_enabled,
            "default_ttl": caching_service.default_ttl,
            "max_cache_size": caching_service.max_cache_size
        }
        
        # Update configuration
        caching_service.cache_enabled = request.enabled
        if request.default_ttl is not None:
            caching_service.default_ttl = request.default_ttl
        if request.max_cache_size is not None:
            caching_service.max_cache_size = request.max_cache_size
        
        new_config = {
            "enabled": caching_service.cache_enabled,
            "default_ttl": caching_service.default_ttl,
            "max_cache_size": caching_service.max_cache_size
        }
        
        logger.info(f"⚙️ Cache config updated by user {current_user.get('email', 'unknown')}: {old_config} -> {new_config}")
        
        return {
            "success": True,
            "message": "Cache configuration updated successfully",
            "old_config": old_config,
            "new_config": new_config
        }
        
    except Exception as e:
        logger.error(f"❌ Error updating cache config: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating cache configuration: {str(e)}")

@router.get("/performance")
async def get_cache_performance():
    """
    Get detailed cache performance metrics
    
    Returns performance data for cache optimization
    """
    try:
        stats = await caching_service.get_cache_stats()
        
        # Calculate additional performance metrics
        performance_data = {
            "hit_ratio_percentage": round(stats.hit_ratio * 100, 2),
            "miss_ratio_percentage": round((1 - stats.hit_ratio) * 100, 2),
            "total_requests": stats.total_hits + stats.total_misses,
            "memory_usage_mb": round(stats.memory_usage / (1024 * 1024), 2),
            "cache_efficiency": "excellent" if stats.hit_ratio > 0.8 else 
                               "good" if stats.hit_ratio > 0.6 else 
                               "poor" if stats.hit_ratio > 0.3 else "very_poor",
            "recommendations": []
        }
        
        # Generate recommendations
        if stats.hit_ratio < 0.5:
            performance_data["recommendations"].append("Consider increasing cache TTL")
        if stats.expired_entries > stats.total_entries * 0.1:
            performance_data["recommendations"].append("Run cache cleanup more frequently")
        if stats.total_entries > caching_service.max_cache_size * 0.9:
            performance_data["recommendations"].append("Consider increasing max cache size")
        
        return {
            "success": True,
            "performance": performance_data,
            "cache_stats": stats.dict(),
            "timestamp": "utcnow"
        }
        
    except Exception as e:
        logger.error(f"❌ Error getting cache performance: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving cache performance: {str(e)}")

@router.delete("/clear")
async def clear_all_cache(current_user=Depends(get_current_user)):
    """
    Clear all cache entries
    
    ⚠️ WARNING: This will remove all cached data
    """
    try:
        # Clear all cache types
        await caching_service.invalidate_cache("tag:all")
        
        # Also clear Redis patterns
        if caching_service.redis_client:
            # Clear all rag-cache entries
            keys = []
            async for key in caching_service.redis_client.scan_iter(match="rag-*"):
                keys.append(key)
            
            if keys:
                await caching_service.redis_client.delete(*keys)
        
        logger.warning(f"🗑️ ALL CACHE CLEARED by user {current_user.get('email', 'unknown')}")
        
        return {
            "success": True,
            "message": "All cache entries cleared successfully",
            "warning": "All cached data has been removed"
        }
        
    except Exception as e:
        logger.error(f"❌ Error clearing all cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error clearing cache: {str(e)}") 