"""
Multi-modal API Routes
Context7 verified FastAPI implementation for image processing, OCR, and vision analysis
"""

from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from typing import List, Dict, Any, Optional
import logging
from pathlib import Path

from ...services.multimodal_processor import multimodal_processor
from ...core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/capabilities")
async def get_multimodal_capabilities() -> Dict[str, Any]:
    """
    Get multi-modal processing capabilities
    Returns available features and supported formats
    """
    try:
        capabilities = multimodal_processor.get_processing_capabilities()
        
        return {
            "success": True,
            "capabilities": capabilities,
            "status": "operational"
        }
        
    except Exception as e:
        logger.error(f"❌ Failed to get capabilities: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/process-image")
async def process_image_file(
    file: UploadFile = File(...),
    analysis_type: Optional[str] = Form(default="auto")
) -> Dict[str, Any]:
    """
    Process a single image file for multi-modal analysis
    Supports OCR, chart analysis, and general image understanding
    """
    try:
        # Validate file type
        if not multimodal_processor.is_image_file(file.filename or "unknown", file.content_type):
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file.content_type}"
            )
        
        # Read file data
        file_data = await file.read()
        
        if len(file_data) == 0:
            raise HTTPException(status_code=400, detail="Empty file uploaded")
        
        # Check file size (max 10MB for images)
        max_size = 10 * 1024 * 1024  # 10MB
        if len(file_data) > max_size:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Maximum size: {max_size / 1024 / 1024}MB"
            )
        
        logger.info(f"🔍 Processing image: {file.filename} ({len(file_data)} bytes)")
        
        # Process based on analysis type
        if analysis_type == "ocr":
            # OCR only
            result = await multimodal_processor.extract_text_from_image(
                file_data, file.content_type or "image/jpeg"
            )
            return {
                "success": True,
                "analysis_type": "ocr",
                "extracted_text": result,
                "filename": file.filename
            }
            
        elif analysis_type == "chart":
            # Chart analysis only
            result = await multimodal_processor.process_chart_or_graph(
                file_data, file.content_type or "image/jpeg"
            )
            return {
                "success": True,
                "analysis_type": "chart",
                "analysis": result,
                "filename": file.filename
            }
            
        elif analysis_type == "document":
            # Document processing
            result = await multimodal_processor.process_document_image(
                file_data, file.content_type or "image/jpeg"
            )
            return {
                "success": True,
                "analysis_type": "document",
                "analysis": result,
                "filename": file.filename
            }
            
        else:
            # Auto-detect and full processing
            result = await multimodal_processor.process_multimodal_content(
                file.filename or "uploaded_image",
                file_data,
                file.content_type or "image/jpeg"
            )
            return {
                "success": result.get("success", False),
                "analysis_type": "auto",
                "result": result,
                "filename": file.filename
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Image processing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/batch-process")
async def batch_process_images(
    files: List[UploadFile] = File(...),
    analysis_type: Optional[str] = Form(default="auto")
) -> Dict[str, Any]:
    """
    Process multiple image files in batch
    Returns results for each file
    """
    try:
        if len(files) == 0:
            raise HTTPException(status_code=400, detail="No files uploaded")
        
        if len(files) > 10:  # Limit batch size
            raise HTTPException(
                status_code=400,
                detail="Too many files. Maximum 10 files per batch"
            )
        
        results = []
        total_size = 0
        
        for file in files:
            try:
                # Check individual file
                if not multimodal_processor.is_image_file(file.filename or "unknown", file.content_type):
                    results.append({
                        "filename": file.filename,
                        "success": False,
                        "error": f"Unsupported file type: {file.content_type}"
                    })
                    continue
                
                file_data = await file.read()
                total_size += len(file_data)
                
                # Check total batch size (max 50MB)
                max_batch_size = 50 * 1024 * 1024  # 50MB
                if total_size > max_batch_size:
                    results.append({
                        "filename": file.filename,
                        "success": False,
                        "error": "Batch size limit exceeded"
                    })
                    continue
                
                # Process the file
                if analysis_type == "auto":
                    result = await multimodal_processor.process_multimodal_content(
                        file.filename or "uploaded_image",
                        file_data,
                        file.content_type or "image/jpeg"
                    )
                else:
                    # Use specific analysis type
                    if analysis_type == "ocr":
                        text = await multimodal_processor.extract_text_from_image(
                            file_data, file.content_type or "image/jpeg"
                        )
                        result = {"extracted_text": text, "success": True}
                    else:
                        result = await multimodal_processor.process_multimodal_content(
                            file.filename or "uploaded_image",
                            file_data,
                            file.content_type or "image/jpeg"
                        )
                
                results.append({
                    "filename": file.filename,
                    "success": result.get("success", False),
                    "result": result
                })
                
            except Exception as e:
                logger.error(f"❌ Failed to process {file.filename}: {e}")
                results.append({
                    "filename": file.filename,
                    "success": False,
                    "error": str(e)
                })
        
        # Summary statistics
        successful = sum(1 for r in results if r["success"])
        failed = len(results) - successful
        
        return {
            "success": True,
            "batch_summary": {
                "total_files": len(results),
                "successful": successful,
                "failed": failed,
                "analysis_type": analysis_type
            },
            "results": results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Batch processing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
async def multimodal_health_check() -> Dict[str, Any]:
    """
    Health check for multi-modal services
    Tests OCR and Vision API availability
    """
    try:
        health_status = {
            "status": "healthy",
            "services": {},
            "timestamp": multimodal_processor._get_timestamp()
        }
        
        # Test Tesseract OCR
        try:
            import pytesseract
            pytesseract.get_tesseract_version()
            health_status["services"]["tesseract_ocr"] = "available"
        except Exception as e:
            health_status["services"]["tesseract_ocr"] = f"unavailable: {e}"
            health_status["status"] = "degraded"
        
        # Test Gemini Vision API
        try:
            from ...services.embeddings import EmbeddingsService
            embeddings_service = EmbeddingsService()
            if hasattr(embeddings_service, 'gemini_client') and embeddings_service.gemini_client:
                health_status["services"]["gemini_vision"] = "available"
            else:
                health_status["services"]["gemini_vision"] = "unavailable: no client"
                health_status["status"] = "degraded"
        except Exception as e:
            health_status["services"]["gemini_vision"] = f"unavailable: {e}"
            health_status["status"] = "degraded"
        
        # Get capabilities
        capabilities = multimodal_processor.get_processing_capabilities()
        health_status["capabilities"] = capabilities
        
        return health_status
        
    except Exception as e:
        logger.error(f"❌ Health check failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/test-ocr")
async def test_ocr_functionality(
    file: UploadFile = File(...),
    language: Optional[str] = Form(default="eng+tur")
) -> Dict[str, Any]:
    """
    Test OCR functionality with custom language settings
    Useful for debugging OCR issues
    """
    try:
        if not multimodal_processor.is_image_file(file.filename or "unknown", file.content_type):
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file.content_type}"
            )
        
        file_data = await file.read()
        
        # Extract text with OCR
        extracted_text = await multimodal_processor.extract_text_from_image(
            file_data, file.content_type or "image/jpeg"
        )
        
        return {
            "success": True,
            "filename": file.filename,
            "language": language,
            "extracted_text": extracted_text,
            "text_length": len(extracted_text),
            "has_text": len(extracted_text.strip()) > 0
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ OCR test failed: {e}")
        raise HTTPException(status_code=500, detail=str(e)) 