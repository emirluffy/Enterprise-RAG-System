from fastapi import APIRouter
from .routes import (
    auth, documents, chat, learning, 
    conversations, websocket, 
    document_updates, email_updates,
    agent_handoff, priority_routing, multimodal,
    realtime_collaboration, caching
)

api_router = APIRouter()

# Include all route modules
api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(documents.router, prefix="/documents", tags=["documents"])
api_router.include_router(chat.router, prefix="/chat", tags=["chat"])
api_router.include_router(learning.router, prefix="/learning", tags=["learning"])

api_router.include_router(conversations.router, prefix="/conversations", tags=["conversations"])
# WebSocket router moved to main app (no API prefix) - Context7 verified ✅
# api_router.include_router(websocket.router, prefix="/ws", tags=["websocket"])
api_router.include_router(document_updates.router, prefix="/document-updates", tags=["document-updates"])
api_router.include_router(email_updates.router, prefix="/email-updates", tags=["email-updates"])


api_router.include_router(agent_handoff.router, prefix="/agent-handoff", tags=["agent-handoff"])
api_router.include_router(priority_routing.router, prefix="/priority-routing", tags=["priority-routing"])

# Phase 4.8: Multi-modal RAG Enhancement
api_router.include_router(multimodal.router, prefix="/multimodal", tags=["multimodal"])

# Phase 5.3: Real-time Collaboration
api_router.include_router(realtime_collaboration.router, prefix="/collaboration", tags=["real-time-collaboration"])

# Phase 5.4: Advanced Caching System
api_router.include_router(caching.router, prefix="/cache", tags=["caching"])



@api_router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "message": "RAG System API is running",
        "features": [
            "Document Processing & RAG",
            "Real-time Chat & Learning", 
            "WebSocket Notifications",
            "Document & Email Updates",
            "🤝 Agent Handoff & Collaboration System",
            "🎯 Priority Routing & SLA Management",
            "📷 Multi-modal RAG Enhancement (OCR, Vision AI)",
            "⚡ Phase 5.3: Real-time Collaboration & Multi-user Chat",
            "💾 Phase 5.4: Advanced Caching System with Redis OM"
        ]
    }
