"""
🤝 Agent Handoff & Collaboration Service
Context7 verified implementation using LangGraph patterns

Enables seamless handoffs between Turkish banking departments:
- Credits (Krediler)
- Operations (Operasyonlar) 
- Customer Service (Müşteri Hizmetleri)
- Compliance (Uyumluluk)
- Risk Management (Risk Yönetimi)
"""

from typing import Annotated, Literal, Dict, List, Optional, Any
from datetime import datetime
import logging
from enum import Enum

from langchain_core.tools import tool, InjectedToolCallId
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langgraph.prebuilt import InjectedState
from langgraph.types import Command
from langgraph.graph import StateGraph, START, END, MessagesState

from ..core.config import settings

logger = logging.getLogger(__name__)

# ✅ Context7 Verified: LangGraph Multi-Agent State Management
class BankingAgentState(MessagesState):
    """Enhanced state for Turkish banking multi-agent system"""
    current_agent: str
    previous_agent: Optional[str]
    handoff_reason: Optional[str]
    customer_context: Dict[str, Any]
    conversation_metadata: Dict[str, Any]
    handoff_history: List[Dict[str, Any]]

class BankingDepartment(str, Enum):
    """Turkish Banking Departments"""
    CREDITS = "credits"           # Krediler
    OPERATIONS = "operations"     # Operasyonlar
    CUSTOMER_SERVICE = "customer_service"  # Müşteri Hizmetleri
    COMPLIANCE = "compliance"     # Uyumluluk
    RISK_MANAGEMENT = "risk_management"   # Risk Yönetimi

class HandoffReason(str, Enum):
    """Handoff sebepleri"""
    EXPERTISE_REQUIRED = "expertise_required"      # Uzmanlık gerekli
    AUTHORIZATION_NEEDED = "authorization_needed"  # Yetki gerekli
    ESCALATION = "escalation"                     # Yükseltme
    SPECIALIZED_TASK = "specialized_task"         # Özel görev
    CUSTOMER_REQUEST = "customer_request"         # Müşteri talebi
    ROUTINE_TRANSFER = "routine_transfer"         # Rutin transfer

class AgentHandoffService:
    """
    🤝 Context7 Verified Agent Handoff Service
    Turkish Banking Multi-Agent Collaboration System
    """
    
    def __init__(self):
        self.department_info = {
            BankingDepartment.CREDITS: {
                "name": "Krediler Departmanı",
                "description": "Kredi başvuruları, limit artırımı, faiz oranları, ödeme planları",
                "expertise": ["kredi", "limit", "faiz", "taksit", "borç", "ödeme"],
                "turkish_name": "Krediler"
            },
            BankingDepartment.OPERATIONS: {
                "name": "Operasyonlar Departmanı", 
                "description": "Hesap işlemleri, para transferi, ATM sorunları, kart işlemleri",
                "expertise": ["hesap", "transfer", "atm", "kart", "işlem", "bakiye"],
                "turkish_name": "Operasyonlar"
            },
            BankingDepartment.CUSTOMER_SERVICE: {
                "name": "Müşteri Hizmetleri Departmanı",
                "description": "Genel sorular, şikayetler, bilgi talepleri, hesap açma",
                "expertise": ["şikayet", "bilgi", "yardım", "hesap açma", "genel"],
                "turkish_name": "Müşteri Hizmetleri"
            },
            BankingDepartment.COMPLIANCE: {
                "name": "Uyumluluk Departmanı",
                "description": "Yasal düzenlemeler, KYC, AML, raporlama, denetim",
                "expertise": ["yasal", "kyc", "aml", "denetim", "raporlama", "uyumluluk"],
                "turkish_name": "Uyumluluk"
            },
            BankingDepartment.RISK_MANAGEMENT: {
                "name": "Risk Yönetimi Departmanı",
                "description": "Risk analizi, güvenlik, dolandırıcılık tespiti, limit kontrolü",
                "expertise": ["risk", "güvenlik", "dolandırıcılık", "kontrol", "analiz"],
                "turkish_name": "Risk Yönetimi"
            }
        }
        
        logger.info("🤝 Agent Handoff Service initialized with 5 Turkish banking departments")

    # ✅ Context7 Verified: LangGraph Handoff Tool Creation Pattern
    def create_handoff_tool(self, *, target_department: BankingDepartment, description: Optional[str] = None):
        """
        Context7 verified handoff tool creation using LangGraph patterns
        Creates dynamic handoff tools for Turkish banking departments
        """
        dept_info = self.department_info[target_department]
        tool_name = f"transfer_to_{target_department.value}"
        tool_description = description or f"{dept_info['turkish_name']} departmanına transfer et"
        
        @tool(tool_name, description=tool_description)
        def handoff_tool(
            reason: Annotated[str, "Transfer sebebi (expertise_required, escalation, vb.)"],
            state: Annotated[BankingAgentState, InjectedState],
            tool_call_id: Annotated[str, InjectedToolCallId],
            context: Annotated[str, "Müşteri durumu ve transfer için gerekli bilgiler"] = "",
        ) -> Command:
            """Turkish Banking Department Handoff Tool"""
            
            # Handoff geçmişi kaydı
            handoff_record = {
                "timestamp": datetime.now().isoformat(),
                "from_agent": state.get("current_agent", "unknown"),
                "to_agent": target_department.value,
                "reason": reason,
                "context": context,
                "tool_call_id": tool_call_id
            }
            
            # Tool message oluştur
            tool_message = {
                "role": "tool",
                "content": f"✅ {dept_info['turkish_name']} departmanına başarıyla transfer edildi. Sebep: {reason}",
                "name": tool_name,
                "tool_call_id": tool_call_id,
            }
            
            # State güncellemeleri
            updated_handoff_history = (state.get("handoff_history", []) or []) + [handoff_record]
            updated_customer_context = {
                **state.get("customer_context", {}),
                "last_handoff_reason": reason,
                "handoff_context": context
            }
            
            logger.info(f"🔄 Handoff: {state.get('current_agent')} -> {target_department.value} (Reason: {reason})")
            
            # ✅ Context7 Verified: LangGraph Command Pattern
            return Command(
                goto=target_department.value,
                update={
                    "messages": state.get("messages", []) + [tool_message],
                    "current_agent": target_department.value,
                    "previous_agent": state.get("current_agent"),
                    "handoff_reason": reason,
                    "customer_context": updated_customer_context,
                    "handoff_history": updated_handoff_history
                },
                graph=Command.PARENT,
            )
        
        return handoff_tool

    def create_all_handoff_tools(self, current_department: BankingDepartment) -> List:
        """Tüm diğer departmanlara handoff tools oluştur"""
        tools = []
        
        for department in BankingDepartment:
            if department != current_department:
                dept_info = self.department_info[department]
                description = f"{dept_info['turkish_name']} departmanına transfer et: {dept_info['description']}"
                tool = self.create_handoff_tool(
                    target_department=department,
                    description=description
                )
                tools.append(tool)
        
        logger.info(f"✅ Created {len(tools)} handoff tools for {current_department.value}")
        return tools

    def suggest_handoff_department(self, query: str, current_department: str) -> Dict[str, Any]:
        """
        Akıllı departman önerisi
        Query içeriğine göre en uygun departmanı belirler
        """
        query_lower = query.lower()
        
        # Departman skorları
        scores = {}
        
        for department, info in self.department_info.items():
            score = 0
            
            # Expertise keywords ile eşleştirme
            for keyword in info["expertise"]:
                if keyword in query_lower:
                    score += 2
            
            # Departman adı ile eşleştirme
            if info["turkish_name"].lower() in query_lower:
                score += 3
                
            scores[department.value] = score
        
        # En yüksek skorlu departman
        if scores:
            suggested_dept = max(scores.keys(), key=lambda k: scores[k])
            max_score = scores[suggested_dept]
            
            # Eşik değeri - çok düşük skorlarda öneride bulunma
            if max_score < 1:
                suggested_dept = None
        else:
            suggested_dept = None
            max_score = 0
        
        return {
            "suggested_department": suggested_dept,
            "confidence_score": max_score,
            "all_scores": scores,
            "current_department": current_department
        }

    def get_handoff_history(self, conversation_id: str = None) -> List[Dict[str, Any]]:
        """Handoff geçmişini getir"""
        # Bu implementasyonda memory'den alınacak
        # Gerçek implementasyonda database'den
        return []

    def validate_handoff(self, from_dept: str, to_dept: str, reason: str) -> Dict[str, Any]:
        """Handoff validasyonu"""
        
        # Aynı departmana transfer kontrolü
        if from_dept == to_dept:
            return {
                "valid": False,
                "error": "Aynı departmana transfer yapılamaz",
                "error_code": "SAME_DEPARTMENT"
            }
        
        # Geçerli departman kontrolü
        valid_departments = [dept.value for dept in BankingDepartment]
        if to_dept not in valid_departments:
            return {
                "valid": False,
                "error": f"Geçersiz departman: {to_dept}",
                "error_code": "INVALID_DEPARTMENT"
            }
        
        # Geçerli sebep kontrolü
        valid_reasons = [reason.value for reason in HandoffReason]
        if reason not in valid_reasons:
            return {
                "valid": False,
                "error": f"Geçersiz handoff sebebi: {reason}",
                "error_code": "INVALID_REASON"
            }
        
        return {
            "valid": True,
            "message": f"✅ {from_dept} -> {to_dept} handoff geçerli"
        }

    def get_department_capabilities(self, department: BankingDepartment) -> Dict[str, Any]:
        """Departman yetenekleri ve uzmanlık alanları"""
        dept_info = self.department_info.get(department)
        if not dept_info:
            return {}
        
        return {
            "department": department.value,
            "name": dept_info["name"],
            "turkish_name": dept_info["turkish_name"],
            "description": dept_info["description"],
            "expertise_areas": dept_info["expertise"],
            "available_handoffs": [
                dept.value for dept in BankingDepartment if dept != department
            ]
        }

    def create_handoff_summary(self, state: BankingAgentState) -> Dict[str, Any]:
        """Handoff özeti oluştur"""
        handoff_history = state.get("handoff_history", [])
        
        if not handoff_history:
            return {
                "total_handoffs": 0,
                "departments_involved": [state.get("current_agent")],
                "last_handoff": None
            }
        
        departments = list(set([h.get("from_agent") for h in handoff_history] + 
                              [h.get("to_agent") for h in handoff_history] +
                              [state.get("current_agent")]))
        
        return {
            "total_handoffs": len(handoff_history),
            "departments_involved": departments,
            "last_handoff": handoff_history[-1] if handoff_history else None,
            "current_department": state.get("current_agent"),
            "handoff_chain": [h.get("to_agent") for h in handoff_history]
        }

# Global instance
agent_handoff_service = AgentHandoffService()

# ✅ Context7 Verified: LangGraph Multi-Agent State Graph
def create_banking_multi_agent_graph() -> StateGraph:
    """
    Context7 verified Turkish Banking Multi-Agent Graph
    5 departman ile tam entegre handoff sistemi
    """
    
    def credits_agent(state: BankingAgentState) -> Command:
        """Krediler Departmanı Agent"""
        # Gerçek implementasyonda LLM çağrısı olacak
        response_message = AIMessage(
            content="🏦 Krediler departmanından size yardımcı oluyorum. Kredi limitiniz, faiz oranları veya ödeme planlarınız hakkında detaylı bilgi verebilirim."
        )
        
        return Command(
            update={
                "messages": state["messages"] + [response_message],
                "current_agent": BankingDepartment.CREDITS.value
            }
        )
    
    def operations_agent(state: BankingAgentState) -> Command:
        """Operasyonlar Departmanı Agent"""
        response_message = AIMessage(
            content="⚙️ Operasyonlar departmanından size yardımcı oluyorum. Hesap işlemleri, para transferleri ve ATM sorunlarınızla ilgilenebilirim."
        )
        
        return Command(
            update={
                "messages": state["messages"] + [response_message],
                "current_agent": BankingDepartment.OPERATIONS.value
            }
        )
    
    def customer_service_agent(state: BankingAgentState) -> Command:
        """Müşteri Hizmetleri Agent"""
        response_message = AIMessage(
            content="🤝 Müşteri Hizmetleri departmanından size yardımcı oluyorum. Genel sorularınız ve şikayetleriniz için buradayım."
        )
        
        return Command(
            update={
                "messages": state["messages"] + [response_message],
                "current_agent": BankingDepartment.CUSTOMER_SERVICE.value
            }
        )
    
    def compliance_agent(state: BankingAgentState) -> Command:
        """Uyumluluk Departmanı Agent"""
        response_message = AIMessage(
            content="📋 Uyumluluk departmanından size yardımcı oluyorum. Yasal düzenlemeler ve raporlama konularında destek sağlayabilirim."
        )
        
        return Command(
            update={
                "messages": state["messages"] + [response_message],
                "current_agent": BankingDepartment.COMPLIANCE.value
            }
        )
    
    def risk_management_agent(state: BankingAgentState) -> Command:
        """Risk Yönetimi Agent"""
        response_message = AIMessage(
            content="🛡️ Risk Yönetimi departmanından size yardımcı oluyorum. Güvenlik ve risk analizi konularında size destek olabilirim."
        )
        
        return Command(
            update={
                "messages": state["messages"] + [response_message],
                "current_agent": BankingDepartment.RISK_MANAGEMENT.value
            }
        )
    
    # ✅ Context7 Verified: StateGraph Construction
    builder = StateGraph(BankingAgentState)
    
    # Agent nodes ekle
    builder.add_node(BankingDepartment.CREDITS.value, credits_agent)
    builder.add_node(BankingDepartment.OPERATIONS.value, operations_agent)  
    builder.add_node(BankingDepartment.CUSTOMER_SERVICE.value, customer_service_agent)
    builder.add_node(BankingDepartment.COMPLIANCE.value, compliance_agent)
    builder.add_node(BankingDepartment.RISK_MANAGEMENT.value, risk_management_agent)
    
    # Default entry point
    builder.add_edge(START, BankingDepartment.CUSTOMER_SERVICE.value)
    
    logger.info("🤝 Banking Multi-Agent Graph created with 5 departments")
    return builder.compile()

# Global graph instance
banking_multi_agent_graph = create_banking_multi_agent_graph() 