"""
Banking Agents Service - Multi-Agent System for Turkish Banking Domain
Implements 5 specialized banking department agents with LangGraph orchestration.
"""

from typing import Dict, Any, List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime
import logging
import asyncio
import json

# Temporarily commented for compatibility
# from langgraph.graph import StateGraph, MessagesState, START, END
# from langgraph.graph.message import add_messages
# from langgraph.prebuilt import create_react_agent
# from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)

# Agent State Models
class BankingAgentState(BaseModel):
    """State model for banking agents"""
    messages: List[Dict[str, Any]] = Field(default_factory=list)
    current_department: Optional[str] = None
    priority: str = "normal"  # low, normal, high, critical
    sentiment: Optional[str] = None
    escalation_reason: Optional[str] = None
    handoff_context: Optional[Dict[str, Any]] = None

# Department Agent Configurations
BANKING_DEPARTMENTS = {
    "credits": {
        "name": "Kredi Departmanı",
        "description": "Kredi başvuruları, ödeme planları, faiz oranları uzmanı",
        "expertise": ["kredi başvurusu", "ödeme planı", "faiz oranı", "mortgage", "tüketici kredisi", "ticari kredi"],
        "prompt": """Sen Kredi Departmanı uzmanısın. Türk bankacılık sektöründe kredi işlemleri konusunda uzmansın.
        
Uzmanlık alanların:
- Kredi başvuru süreçleri
- Ödeme planları ve taksitlendirme
- Faiz oranları ve hesaplamaları
- Mortgage ve konut kredileri
- Tüketici ve ticari krediler
- FICO skorları ve kredi değerlendirme

Müşteriye profesyonel, detaylı ve Türkçe yanıtlar ver. Gerektiğinde başka departmanlara yönlendir."""
    },
    "operations": {
        "name": "Operasyon Departmanı", 
        "description": "Hesap işlemleri, transferler, teknik destek uzmanı",
        "expertise": ["hesap işlemi", "transfer", "havale", "eft", "atm", "internet bankacılığı", "teknik sorun"],
        "prompt": """Sen Operasyon Departmanı uzmanısın. Günlük bankacılık işlemleri ve teknik konularda uzmansın.

Uzmanlık alanların:
- Hesap açma/kapatma işlemleri
- Para transferleri (havale, EFT, SWIFT)
- ATM ve POS işlemleri
- İnternet/mobil bankacılık
- Kart işlemleri ve sorunları
- Teknik destek

Müşteriye hızlı çözüm odaklı, net Türkçe yanıtlar ver."""
    },
    "customer_service": {
        "name": "Müşteri Hizmetleri",
        "description": "Genel müşteri soruları, şikayet yönetimi uzmanı", 
        "expertise": ["genel bilgi", "şikayet", "öneri", "hesap bilgisi", "müşteri memnuniyeti"],
        "prompt": """Sen Müşteri Hizmetleri uzmanısın. Müşteri memnuniyeti ve genel bankacılık konularında uzmansın.

Uzmanlık alanların:
- Genel bankacılık bilgileri
- Şikayet ve öneri yönetimi
- Hesap bilgileri ve sorgulama
- Müşteri memnuniyeti
- Ürün tanıtımları
- Genel destek

Müşteriye empati kurarak, samimi ve çözüm odaklı Türkçe yanıtlar ver."""
    },
    "compliance": {
        "name": "Uyumluluk Departmanı",
        "description": "BDDK düzenlemeleri, yasal konular, KYC/AML uzmanı",
        "expertise": ["bddk", "yasal", "düzenleme", "kyc", "aml", "compliance", "mevzuat"],
        "prompt": """Sen Uyumluluk Departmanı uzmanısın. Yasal düzenlemeler ve bankacılık mevzuatı konusunda uzmansın.

Uzmanlık alanların:
- BDDK düzenlemeleri
- KYC (Müşteriyi Tanı) prosedürleri
- AML (Kara Para Aklama) önlemleri
- Bankacılık mevzuatı
- Yasal uyumluluk
- Düzenleyici raporlama

Müşteriye yasal çerçevede, detaylı ve güvenilir Türkçe bilgi ver."""
    },
    "risk_management": {
        "name": "Risk Yönetimi",
        "description": "Güvenlik, dolandırıcılık önleme, risk analizi uzmanı",
        "expertise": ["güvenlik", "dolandırıcılık", "risk", "fraud", "siber güvenlik", "kimlik doğrulama"],
        "prompt": """Sen Risk Yönetimi uzmanısın. Bankacılık güvenliği ve risk analizi konusunda uzmansın.

Uzmanlık alanların:
- Dolandırıcılık tespiti ve önleme
- Siber güvenlik
- Kimlik doğrulama
- Risk değerlendirme
- Güvenlik protokolleri
- Fraud analizi

Müşteriye güvenlik odaklı, koruyucu ve net Türkçe bilgi ver."""
    }
}

class BankingAgentsService:
    """
    Multi-Agent Banking System Service
    Manages 5 specialized banking department agents with intelligent routing
    """
    
    def __init__(self):
        self.departments = BANKING_DEPARTMENTS
        # self.memory = MemorySaver()  # Temporarily commented
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        logger.info("Banking Agents Service initialized with 5 departments")
    
    async def route_query(self, query: str, sentiment_data: Optional[Dict[str, Any]] = None) -> str:
        """
        Intelligent query routing to appropriate department
        """
        query_lower = query.lower()
        
        # Priority routing based on sentiment
        if sentiment_data:
            if sentiment_data.get("priority") == "critical":
                if any(keyword in query_lower for keyword in ["dolandırıcılık", "fraud", "güvenlik", "çalınmış"]):
                    return "risk_management"
                elif sentiment_data.get("sentiment") == "negative":
                    return "customer_service"
        
        # Content-based routing
        for dept_id, dept_info in self.departments.items():
            if any(keyword in query_lower for keyword in dept_info["expertise"]):
                return dept_id
        
        # Default to customer service
        return "customer_service"
    
    async def process_banking_query(
        self,
        query: str,
        department: Optional[str] = None,
        sentiment_data: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process banking query with multi-agent system
        """
        try:
            # Route to appropriate department
            if not department:
                department = await self.route_query(query, sentiment_data)
            
            dept_info = self.departments.get(department, self.departments["customer_service"])
            
            # Simulate agent processing (placeholder for actual LangGraph implementation)
            response = await self._simulate_agent_response(query, dept_info, sentiment_data)
            
            # Check if handoff is needed
            handoff_needed, target_dept = await self._check_handoff_needed(query, department)
            
            result = {
                "department": department,
                "agent_name": dept_info["name"],  # Frontend expects agent_name
                "response": response,
                "handoff_suggestion": target_dept,  # Frontend expects handoff_suggestion
                "confidence": 0.85,  # Placeholder
                "metadata": {
                    "processing_time": "0.5s",
                    "handoff_needed": handoff_needed,
                    "target_department": target_dept
                }
            }
            
            # Update session if provided
            if session_id:
                self._update_session(session_id, result)
            
            return result
            
        except Exception as e:
            logger.error(f"Error processing banking query: {str(e)}")
            return {
                "department": "customer_service",
                "agent_name": "Müşteri Hizmetleri",
                "response": "Üzgünüm, şu anda teknik bir sorun yaşıyoruz. Lütfen daha sonra tekrar deneyin.",
                "confidence": 0.0,
                "metadata": {
                    "error": str(e),
                    "handoff_needed": False
                }
            }
    
    async def _simulate_agent_response(
        self,
        query: str,
        dept_info: Dict[str, Any],
        sentiment_data: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generate intelligent Turkish banking responses based on query and department
        """
        query_lower = query.lower()
        department = dept_info.get("name", "")
        
        # Sentiment-aware greeting
        greeting = ""
        if sentiment_data:
            if sentiment_data.get("sentiment") == "negative":
                greeting = "Yaşadığınız sorunu anlıyorum ve en kısa sürede çözüm bulmak için buradayım. "
            elif sentiment_data.get("priority") == "high":
                greeting = "Acil durumunuzu anlıyorum ve öncelikli olarak size yardımcı olacağım. "
            else:
                greeting = "Size yardımcı olmaktan mutluluk duyarım. "
        else:
            greeting = "Size yardımcı olmaktan mutluluk duyarım. "
        
        # Department-specific smart responses
        if "kredi" in query_lower:
            if "limit" in query_lower or "artır" in query_lower:
                return f"{greeting}{department} olarak kredi kartı limit artırım konusunda size yardımcı olabilirim.\n\nKredi kartı limitinizi artırmak için:\n• Son 6 aydır düzenli gelir beyanınız\n• Mevcut kart kullanım geçmişiniz\n• Güncel gelir durumunuz değerlendirilir.\n\nİnternet bankacılığınızdan veya 444 0 333 numaralı telefon bankacılığımızdan başvurunuzu yapabilirsiniz."
            elif "başvuru" in query_lower:
                return f"{greeting}{department} olarak kredi başvurunuz konusunda size detaylı bilgi verebilirim.\n\nKredi başvurusu için gerekli belgeler:\n• Kimlik fotokopisi\n• Gelir belgesi (maaş bordrosu/SGK hizmet dökümü)\n• İkametgah belgesi\n\nBaşvurunuz 1-3 iş günü içinde değerlendirilir ve sonuç SMS ile bildirilir."
        
        elif "transfer" in query_lower or "havale" in query_lower:
            return f"{greeting}{department} olarak para transferi işlemlerinizde size yardımcı olacağım.\n\nPara transferi seçenekleriniz:\n• İnternet/Mobil bankacılık (7/24 anında)\n• ATM'lerden havale (günlük 50.000 TL'ye kadar)\n• Şube işlemleri (working hours)\n\nEFT işlemleri aynı gün saat 17:30'a kadar, FAST transferler 7/24 anında gerçekleşir."
        
        elif "atm" in query_lower:
            if "şifre" in query_lower or "pin" in query_lower:
                return f"{greeting}{department} olarak ATM şifre işlemlerinizde size yardımcı olabilirim.\n\nATM şifrenizi:\n• İnternet bankacılığından değiştirebilirsiniz\n• 444 0 333 telefon bankacılığından yenileyebilirsiniz\n• En yakın şubemizden kimlikle başvurabilirsiniz\n\nGüvenliğiniz için şifrenizi kimseyle paylaşmayın ve düzenli olarak değiştirin."
            else:
                return f"{greeting}{department} olarak ATM işlemlerinizde size yardımcı olacağım.\n\nATM'lerimizde yapabileceğiniz işlemler:\n• Para çekme/yatırma\n• Hesap bakiye sorgulama\n• EFT/Havale işlemleri\n• Fatura ödeme\n• Cep telefonu kontör yükleme\n\n7/24 hizmet veren 15.000+ ATM'miz ülke genelinde hizmetinizde."
        
        elif "güvenlik" in query_lower or "dolandırıcılık" in query_lower:
            return f"{greeting}{department} olarak güvenlik konularında size destek vereceğim.\n\n⚠️ Güvenlik uyarıları:\n• Şifre ve kişisel bilgilerinizi kimseyle paylaşmayın\n• Şüpheli SMS/email'lere tıklamayın\n• Bilinmeyen numaralardan gelen çağrılara güvenmeyin\n• Hesap hareketlerinizi düzenli kontrol edin\n\nAcil durumlarda 444 0 333'ü arayarak kartlarınızı bloke ettirebilirsiniz."
        
        elif "faiz" in query_lower or "oran" in query_lower:
            return f"{greeting}{department} olarak faiz oranları konusunda size bilgi verebilirim.\n\nGüncel faiz oranlarımız:\n• Vadeli mevduat: %45-55 (vade ve tutara göre)\n• Kredi kartı: %49,90 (aylık)\n• İhtiyaç kredisi: %39,90-59,90\n• Konut kredisi: %36,90-42,90\n\nDetaylı bilgi için web sitemizi ziyaret edin veya şubelerimizden bilgi alın."
        
        # Default response based on department
        dept_responses = {
            "Kredi Departmanı": f"{greeting}Kredi Departmanı olarak kredi başvuruları, kredi kartı limitleri, ödeme planları ve kredi değerlendirme kriterleri konularında size yardımcı olabilirim.",
            "Operasyon Departmanı": f"{greeting}Operasyon Departmanı olarak hesap işlemleri, para transferleri, ATM hizmetleri ve bankacılık işlemlerinizde size destek verebilirim.",
            "Müşteri Hizmetleri": f"{greeting}Müşteri Hizmetleri olarak tüm bankacılık sorularınızda size yardımcı olmaktan mutluluk duyarım. Hangi konuda destek istiyorsunuz?",
            "Uyumluluk Departmanı": f"{greeting}Uyumluluk Departmanı olarak BDDK düzenlemeleri, yasal gereklilikler ve bankacılık mevzuatı konularında size bilgi verebilirim.",
            "Risk Yönetimi": f"{greeting}Risk Yönetimi olarak hesap güvenliği, dolandırıcılık önleme ve güvenlik protokolleri konularında size destek vereceğim."
        }
        
        return dept_responses.get(department, f"{greeting}{department} olarak size yardımcı olmaya hazırım. Lütfen sorununuzu detaylandırın.")
    
    async def _check_handoff_needed(self, query: str, current_dept: str) -> tuple[bool, Optional[str]]:
        """
        Check if query needs to be handed off to another department
        """
        query_lower = query.lower()
        
        # Complex queries that might need multiple departments
        if current_dept == "customer_service":
            if any(keyword in query_lower for keyword in ["kredi", "faiz", "ödeme"]):
                return True, "credits"
            elif any(keyword in query_lower for keyword in ["transfer", "havale", "atm"]):
                return True, "operations"
            elif any(keyword in query_lower for keyword in ["dolandırıcılık", "güvenlik"]):
                return True, "risk_management"
        
        return False, None
    
    def _update_session(self, session_id: str, result: Dict[str, Any]) -> None:
        """
        Update session with latest interaction
        """
        if session_id not in self.active_sessions:
            self.active_sessions[session_id] = {
                "created_at": datetime.now(),
                "interactions": []
            }
        
        self.active_sessions[session_id]["interactions"].append({
            "timestamp": datetime.now(),
            "department": result["department"],
            "response": result["response"]
        })
    
    async def get_department_capabilities(self) -> Dict[str, Any]:
        """
        Get all department capabilities and expertise areas
        """
        return {
            dept_id: {
                "name": dept_info["name"],
                "description": dept_info["description"],
                "expertise": dept_info["expertise"]
            }
            for dept_id, dept_info in self.departments.items()
        }
    
    async def get_session_history(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get session interaction history
        """
        return self.active_sessions.get(session_id)

# Global service instance
banking_agents_service = BankingAgentsService() 