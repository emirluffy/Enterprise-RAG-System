"""
Email Integration Service for Operational Announcements
Automatically processes incoming emails and triggers document updates
"""

import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from email.mime.text import MIMEText
from email import message_from_string
import asyncio
from pydantic import BaseModel

from .document_update_processor import schedule_auto_update, schedule_version_update
from .notification_service import send_document_update_notification

logger = logging.getLogger(__name__)

class EmailUpdate(BaseModel):
    """Email update request DTO"""
    sender: str
    subject: str
    body: str
    timestamp: datetime
    attachments: Optional[List[Dict]] = None

class OperationalEmailProcessor:
    """Processes operational emails for document updates"""
    
    def __init__(self):
        # Define operational email patterns
        self.operational_senders = [
            "operations@company.com",
            "policy@company.com", 
            "compliance@company.com",
            "management@company.com"
        ]
        
        # Email classification patterns
        self.update_patterns = {
            "URGENT": [
                r"acil|urgent|kritik|critical|emergency",
                r"derhal|immediately|asap|urgent action"
            ],
            "POLICY": [
                r"policy|politika|prosedür|procedure|kural|rule",
                r"compliance|uyumluluk|regulation|düzenleme"
            ],
            "PROCESS": [
                r"süreç|process|workflow|iş akışı",
                r"güncelleme|update|değişiklik|change"
            ]
        }
    
    async def process_operational_email(self, email_data: EmailUpdate) -> Dict[str, Any]:
        """Main email processing function"""
        
        if email_data.sender not in self.operational_senders:
            return {"status": "ignored", "reason": "Not from operational sender"}
        
        # Classify email type and urgency
        classification = self._classify_email(email_data)
        
        # Extract document references
        document_refs = self._extract_document_references(email_data.body)
        
        # Process based on classification
        if classification["type"] == "POLICY":
            return await self._handle_policy_update(email_data, document_refs, classification)
        elif classification["type"] == "PROCESS":
            return await self._handle_process_update(email_data, document_refs, classification)
        elif classification["urgency"] == "URGENT":
            return await self._handle_urgent_update(email_data, document_refs, classification)
        else:
            return await self._handle_general_update(email_data, document_refs, classification)
    
    async def _handle_process_update(
        self,
        email_data: EmailUpdate,
        document_refs: List[str],
        classification: Dict[str, str]
    ) -> Dict[str, Any]:
        """Handle process update emails"""
        
        logger.info(f"Processing process update from {email_data.sender}")
        
        results = []
        
        for doc_ref in document_refs or ["PROCESS-MANUAL"]:
            try:
                # Schedule document update
                job_id = await schedule_auto_update(
                    document_id=doc_ref,
                    new_content=email_data.body,
                    change_summary=f"Process update from operations: {email_data.subject}"
                )
                
                # Send notification
                await send_document_update_notification(
                    document_id=doc_ref,
                    change_type="PROCESS_UPDATE",
                    description=f"Süreç güncellemesi: {email_data.subject}",
                    urgency=classification["urgency"],
                    affected_systems=["Operations", "Workflow"]
                )
                
                results.append({
                    "document_id": doc_ref,
                    "job_id": job_id,
                    "status": "scheduled"
                })
                
            except Exception as e:
                logger.error(f"Error processing process update for {doc_ref}: {e}")
                results.append({
                    "document_id": doc_ref,
                    "status": "error", 
                    "error": str(e)
                })
        
        return {
            "status": "processed",
            "type": "process_update",
            "results": results,
            "email_subject": email_data.subject
        }
    
    def _classify_email(self, email_data: EmailUpdate) -> Dict[str, str]:
        """Classify email type and urgency"""
        
        content = f"{email_data.subject} {email_data.body}".lower()
        
        classification = {
            "type": "GENERAL",
            "urgency": "NORMAL"
        }
        
        # Check for urgent patterns
        for pattern in self.update_patterns["URGENT"]:
            if re.search(pattern, content, re.IGNORECASE):
                classification["urgency"] = "URGENT"
                break
        
        # Check for policy patterns
        for pattern in self.update_patterns["POLICY"]:
            if re.search(pattern, content, re.IGNORECASE):
                classification["type"] = "POLICY"
                break
        
        # Check for process patterns  
        for pattern in self.update_patterns["PROCESS"]:
            if re.search(pattern, content, re.IGNORECASE):
                classification["type"] = "PROCESS"
                break
        
        return classification
    
    def _extract_document_references(self, email_body: str) -> List[str]:
        """Extract document IDs or names from email"""
        
        # Look for document patterns
        doc_patterns = [
            r"doküman\s*[:#]?\s*([A-Z0-9-]+)",
            r"document\s*[:#]?\s*([A-Z0-9-]+)",
            r"policy\s*[:#]?\s*([A-Z0-9-]+)",
            r"prosedür\s*[:#]?\s*([A-Z0-9-]+)"
        ]
        
        document_refs = []
        for pattern in doc_patterns:
            matches = re.findall(pattern, email_body, re.IGNORECASE)
            document_refs.extend(matches)
        
        # If no specific docs mentioned, use default mappings
        if not document_refs:
            if "policy" in email_body.lower() or "politika" in email_body.lower():
                document_refs = ["POLICY-HANDBOOK"]
            elif "procedure" in email_body.lower() or "prosedür" in email_body.lower():
                document_refs = ["PROCESS-MANUAL"]
        
        return list(set(document_refs))  # Remove duplicates
    
    async def _handle_policy_update(
        self, 
        email_data: EmailUpdate, 
        document_refs: List[str],
        classification: Dict[str, str]
    ) -> Dict[str, Any]:
        """Handle policy update emails"""
        
        logger.info(f"Processing policy update from {email_data.sender}")
        
        results = []
        
        for doc_ref in document_refs or ["POLICY-HANDBOOK"]:
            try:
                # Schedule document update
                job_id = await schedule_auto_update(
                    document_id=doc_ref,
                    new_content=email_data.body,
                    change_summary=f"Policy update from operations: {email_data.subject}"
                )
                
                # Send notification
                await send_document_update_notification(
                    document_id=doc_ref,
                    change_type="POLICY_UPDATE",
                    description=f"Policy güncellemesi: {email_data.subject}",
                    urgency=classification["urgency"],
                    affected_systems=["CRM", "Support", "Operations"]
                )
                
                results.append({
                    "document_id": doc_ref,
                    "job_id": job_id,
                    "status": "scheduled"
                })
                
            except Exception as e:
                logger.error(f"Error processing policy update for {doc_ref}: {e}")
                results.append({
                    "document_id": doc_ref,
                    "status": "error",
                    "error": str(e)
                })
        
        return {
            "status": "processed",
            "type": "policy_update",
            "results": results,
            "email_subject": email_data.subject
        }
    
    async def _handle_urgent_update(
        self,
        email_data: EmailUpdate,
        document_refs: List[str], 
        classification: Dict[str, str]
    ) -> Dict[str, Any]:
        """Handle urgent updates"""
        
        logger.warning(f"Processing URGENT update from {email_data.sender}")
        
        # For urgent updates, notify immediately
        for doc_ref in document_refs or ["ALL-DOCUMENTS"]:
            await send_document_update_notification(
                document_id=doc_ref,
                change_type="URGENT_ANNOUNCEMENT",
                description=f"🚨 ACİL DUYURU: {email_data.subject}",
                urgency="URGENT",
                affected_systems=["ALL"]
            )
        
        return {
            "status": "urgent_processed",
            "notification_sent": True,
            "email_subject": email_data.subject
        }
    
    async def _handle_general_update(
        self,
        email_data: EmailUpdate,
        document_refs: List[str],
        classification: Dict[str, str]
    ) -> Dict[str, Any]:
        """Handle general operational updates"""
        
        # Create scheduled update for later processing
        job_ids = []
        
        for doc_ref in document_refs:
            job_id = await schedule_version_update(
                document_id=doc_ref,
                change_type="OPERATIONAL_UPDATE",
                change_summary=email_data.subject
            )
            job_ids.append(job_id)
        
        return {
            "status": "scheduled",
            "job_ids": job_ids,
            "email_subject": email_data.subject
        }

# Global processor instance
email_processor = OperationalEmailProcessor()

# Email webhook endpoint integration
async def process_incoming_email(email_content: str, sender: str, subject: str) -> Dict[str, Any]:
    """Process incoming operational email"""
    
    email_data = EmailUpdate(
        sender=sender,
        subject=subject,
        body=email_content,
        timestamp=datetime.utcnow()
    )
    
    return await email_processor.process_operational_email(email_data) 