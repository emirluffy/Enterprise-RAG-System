"""
Multi-modal Document Processor Service
Context7 verified implementation using pytesseract and Gemini Vision API
Handles image OCR, chart analysis, and visual document intelligence
"""

import os
import io
import logging
from typing import List, Dict, Any, Optional, Tuple
from PIL import Image
import pytesseract
from pathlib import Path
import base64

from google.genai import types
from ..core.config import settings

logger = logging.getLogger(__name__)

class MultimodalProcessor:
    """
    Multi-modal document processor for images, charts, and visual content
    Context7 verified patterns implementation
    """
    
    def __init__(self):
        """Initialize multi-modal processor with Context7 verified patterns"""
        self.setup_tesseract()
        self.supported_image_formats = {
            'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 
            'image/bmp', 'image/tiff', 'image/webp'
        }
        
    def setup_tesseract(self):
        """Setup Tesseract OCR with proper configuration"""
        try:
            # Context7 verified: Check if tesseract is in PATH
            pytesseract.get_tesseract_version()
            logger.info("✅ Tesseract OCR initialized successfully")
        except Exception as e:
            logger.warning(f"⚠️ Tesseract OCR not found in PATH: {e}")
            # Try common installation paths for Windows
            possible_paths = [
                r'C:\Program Files\Tesseract-OCR\tesseract.exe',
                r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    pytesseract.pytesseract.tesseract_cmd = path
                    logger.info(f"✅ Tesseract found at: {path}")
                    break
    
    def is_image_file(self, file_path: str, mime_type: Optional[str] = None) -> bool:
        """Check if file is a supported image format"""
        if mime_type and mime_type in self.supported_image_formats:
            return True
        
        # Check file extension
        ext = Path(file_path).suffix.lower()
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
        return ext in image_extensions
    
    async def extract_text_from_image(self, image_data: bytes, mime_type: str) -> str:
        """
        Extract text from image using OCR
        Context7 verified pytesseract implementation
        """
        try:
            # Context7 verified: Convert bytes to PIL Image
            image = Image.open(io.BytesIO(image_data))
            
            # Context7 verified: Convert to RGB if necessary
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Context7 verified: OCR with custom config for better accuracy
            custom_config = r'--oem 3 --psm 6'  # OCR Engine Mode 3, Page Segmentation Mode 6
            text = pytesseract.image_to_string(image, config=custom_config, lang='eng+tur')
            
            # Clean extracted text
            text = text.strip()
            if text:
                logger.info(f"✅ OCR extracted {len(text)} characters from image")
                return text
            else:
                logger.warning("⚠️ No text found in image")
                return ""
                
        except Exception as e:
            logger.error(f"❌ OCR extraction failed: {e}")
            return ""
    
    async def analyze_image_with_gemini(self, image_data: bytes, mime_type: str, 
                                      prompt: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze image using Gemini Vision API
        Context7 verified Google GenAI implementation
        """
        try:
            # Import Gemini client from embeddings service
            from .embeddings import EmbeddingsService
            embeddings_service = EmbeddingsService()
            
            # Access Gemini client directly
            if hasattr(embeddings_service, 'gemini_client') and embeddings_service.gemini_client:
                client = embeddings_service.gemini_client
            else:
                logger.error("❌ Gemini client not available in embeddings service")
                return {"error": "Gemini client not available"}
            
            if not client:
                logger.error("❌ Gemini client not available")
                return {"error": "Gemini client not available"}
            
            # Default analysis prompt
            if not prompt:
                prompt = """Analyze this image and provide:
1. What type of content is this? (chart, graph, document, photo, etc.)
2. What information does it contain?
3. Key data points or insights
4. Any text visible in the image
5. Overall summary

Please be detailed and specific."""
            
            # Context7 verified: Create image part from bytes
            image_part = types.Part.from_bytes(data=image_data, mime_type=mime_type)
            
            # Context7 verified: Generate content with image input
            response = client.models.generate_content(
                model='gemini-2.0-flash-001',
                contents=[prompt, image_part]
            )
            
            analysis = response.text if response.text else "No analysis generated"
            
            logger.info(f"✅ Gemini Vision analysis completed: {len(analysis)} characters")
            
            return {
                "analysis": analysis,
                "type": "gemini_vision_analysis",
                "model": "gemini-2.0-flash-001",
                "success": True
            }
            
        except Exception as e:
            logger.error(f"❌ Gemini Vision analysis failed: {e}")
            return {
                "error": str(e),
                "success": False
            }
    
    async def process_chart_or_graph(self, image_data: bytes, mime_type: str) -> Dict[str, Any]:
        """Specialized processing for charts and graphs"""
        chart_prompt = """This appears to be a chart or graph. Please analyze:

1. Chart Type: What type of chart/graph is this? (bar chart, line graph, pie chart, etc.)
2. Data Analysis: What data is being presented?
3. Key Insights: What are the main trends, patterns, or insights?
4. Axes and Labels: What are the x and y axis labels and units?
5. Data Points: Extract specific numerical values if visible
6. Title and Legend: What is the chart title and legend information?
7. Summary: Provide a concise summary of what this chart tells us

Be as specific and detailed as possible with numerical data."""

        return await self.analyze_image_with_gemini(image_data, mime_type, chart_prompt)
    
    async def process_document_image(self, image_data: bytes, mime_type: str) -> Dict[str, Any]:
        """Process document images (scanned documents, forms, etc.)"""
        try:
            # Combine OCR and Vision analysis for document images
            ocr_text = await self.extract_text_from_image(image_data, mime_type)
            
            document_prompt = f"""This is a document image. Please analyze:

1. Document Type: What type of document is this?
2. Structure: How is the document organized?
3. Key Information: What are the main points or data?
4. Forms/Fields: Are there any forms, fields, or structured data?
5. Quality: Is this a scanned document, screenshot, or photo?

OCR Text Extracted: {ocr_text[:500]}...

Please provide a comprehensive analysis combining visual and text information."""

            vision_analysis = await self.analyze_image_with_gemini(image_data, mime_type, document_prompt)
            
            return {
                "ocr_text": ocr_text,
                "vision_analysis": vision_analysis.get("analysis", ""),
                "document_type": "scanned_document",
                "success": True,
                "processing_methods": ["ocr", "vision_analysis"]
            }
            
        except Exception as e:
            logger.error(f"❌ Document image processing failed: {e}")
            return {
                "error": str(e),
                "success": False
            }
    
    async def process_multimodal_content(self, file_path: str, file_data: bytes, 
                                       mime_type: str) -> Dict[str, Any]:
        """
        Main entry point for multi-modal content processing
        Determines the best processing approach based on content type
        """
        try:
            logger.info(f"🔍 Processing multi-modal content: {mime_type}")
            
            if not self.is_image_file(file_path, mime_type):
                return {
                    "error": "Not a supported image format",
                    "success": False
                }
            
            # Get basic image info
            image = Image.open(io.BytesIO(file_data))
            image_info = {
                "width": image.width,
                "height": image.height,
                "mode": image.mode,
                "format": image.format,
                "size_bytes": len(file_data)
            }
            
            # Always try OCR first for text extraction
            ocr_text = await self.extract_text_from_image(file_data, mime_type)
            
            # Determine content type and specialized analysis
            content_type = await self._detect_content_type(file_data, mime_type)
            
            specialized_analysis = {}
            if content_type == "chart_graph":
                specialized_analysis = await self.process_chart_or_graph(file_data, mime_type)
            elif content_type == "document":
                specialized_analysis = await self.process_document_image(file_data, mime_type)
            else:
                # General image analysis
                specialized_analysis = await self.analyze_image_with_gemini(file_data, mime_type)
            
            # Combine all results
            result = {
                "success": True,
                "content_type": content_type,
                "image_info": image_info,
                "ocr_text": ocr_text,
                "specialized_analysis": specialized_analysis,
                "processing_timestamp": self._get_timestamp(),
                "multimodal_enhanced": True
            }
            
            logger.info(f"✅ Multi-modal processing completed for {file_path}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Multi-modal processing failed: {e}")
            return {
                "error": str(e),
                "success": False,
                "multimodal_enhanced": False
            }
    
    async def _detect_content_type(self, image_data: bytes, mime_type: str) -> str:
        """Detect the type of visual content"""
        try:
            # Quick analysis to determine content type
            detection_prompt = """Quickly identify what type of visual content this is:
- chart_graph: If this is a chart, graph, diagram, or data visualization
- document: If this is a scanned document, form, or text-heavy image  
- photo: If this is a photograph or general image
- other: If it doesn't fit the above categories

Respond with just one word: chart_graph, document, photo, or other"""
            
            analysis = await self.analyze_image_with_gemini(image_data, mime_type, detection_prompt)
            content_type = analysis.get("analysis", "other").strip().lower()
            
            # Validate response
            valid_types = ["chart_graph", "document", "photo", "other"]
            if content_type not in valid_types:
                content_type = "other"
                
            return content_type
            
        except Exception as e:
            logger.error(f"❌ Content type detection failed: {e}")
            return "other"
    
    def _get_timestamp(self) -> str:
        """Get current timestamp for processing metadata"""
        import datetime
        return datetime.datetime.now().isoformat()
    
    def get_processing_capabilities(self) -> Dict[str, Any]:
        """Return information about processing capabilities"""
        return {
            "ocr_available": True,
            "gemini_vision_available": True,
            "supported_formats": list(self.supported_image_formats),
            "features": [
                "text_extraction",
                "chart_analysis", 
                "document_processing",
                "image_analysis",
                "content_type_detection"
            ],
            "languages": ["eng", "tur"]  # English and Turkish OCR support
        }

# Global instance
multimodal_processor = MultimodalProcessor() 